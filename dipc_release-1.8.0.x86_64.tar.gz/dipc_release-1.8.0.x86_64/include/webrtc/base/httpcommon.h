/*
 *  Copyright 2004 The WebRTC Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_BASE_HTTPCOMMON_H__
#define WEBRTC_BASE_HTTPCOMMON_H__

#include <map>
#include <string>
#include <vector>
#include "webrtc/base/basictypes.h"
#include "webrtc/base/common.h"
#include "webrtc/base/scoped_ptr.h"
#include "webrtc/base/stringutils.h"
#include "webrtc/base/stream.h"

namespace rtc {

class CryptString;
class SocketAddress;

//////////////////////////////////////////////////////////////////////
// Constants
//////////////////////////////////////////////////////////////////////

enum HttpCode {
  HC_OK = 200,
  HC_NON_AUTHORITATIVE = 203,
  HC_NO_CONTENT = 204,
  HC_PARTIAL_CONTENT = 206,

  HC_MULTIPLE_CHOICES = 300,
  HC_MOVED_PERMANENTLY = 301,
  HC_FOUND = 302,
  HC_SEE_OTHER = 303,
  HC_NOT_MODIFIED = 304,
  HC_MOVED_TEMPORARILY = 307,

  HC_BAD_REQUEST = 400,
  HC_UNAUTHORIZED = 401,
  HC_FORBIDDEN = 403,
  HC_NOT_FOUND = 404,
  HC_PROXY_AUTHENTICATION_REQUIRED = 407,
  HC_GONE = 410,

  HC_INTERNAL_SERVER_ERROR = 500,
  HC_NOT_IMPLEMENTED = 501,
  HC_SERVICE_UNAVAILABLE = 503,
};

enum HttpVersion {
  HVER_1_0, HVER_1_1, HVER_UNKNOWN,
  HVER_LAST = HVER_UNKNOWN
};

enum HttpVerb {
  HV_GET, HV_POST, HV_PUT, HV_DELETE, HV_CONNECT, HV_HEAD,
  HV_LAST = HV_HEAD
};

enum HttpError {
  HE_NONE,
  HE_PROTOCOL,            // Received non-valid HTTP data
  HE_DISCONNECTED,        // Connection closed unexpectedly
  HE_OVERFLOW,            // Received too much data for internal buffers
  HE_CONNECT_FAILED,      // The socket failed to connect.
  HE_SOCKET_ERROR,        // An error occurred on a connected socket
  HE_SHUTDOWN,            // Http object is being destroyed
  HE_OPERATION_CANCELLED, // Connection aborted locally
  HE_AUTH,                // Proxy Authentication Required
  HE_CERTIFICATE_EXPIRED, // During SSL negotiation
  HE_STREAM,              // Problem reading or writing to the document
  HE_CACHE,               // Problem reading from cache
  HE_DEFAULT
};

enum HttpHeader {
  HH_AGE,
  HH_CACHE_CONTROL,
  HH_CONNECTION,
  HH_CONTENT_DISPOSITION,
  HH_CONTENT_LENGTH,
  HH_CONTENT_RANGE,
  HH_CONTENT_TYPE,
  HH_COOKIE,
  HH_DATE,
  HH_ETAG,
  HH_EXPIRES,
  HH_HOST,
  HH_IF_MODIFIED_SINCE,
  HH_IF_NONE_MATCH,
  HH_KEEP_ALIVE,
  HH_LAST_MODIFIED,
  HH_LOCATION,
  HH_PROXY_AUTHENTICATE,
  HH_PROXY_AUTHORIZATION,
  HH_PROXY_CONNECTION,
  HH_RANGE,
  HH_SET_COOKIE,
  HH_TE,
  HH_TRAILERS,
  HH_TRANSFER_ENCODING,
  HH_UPGRADE,
  HH_USER_AGENT,
  HH_WWW_AUTHENTICATE,
  HH_LAST = HH_WWW_AUTHENTICATE
};

const uint16_t HTTP_DEFAULT_PORT = 80;
const uint16_t HTTP_SECURE_PORT = 443;

//////////////////////////////////////////////////////////////////////
// Utility Functions
//////////////////////////////////////////////////////////////////////

inline HttpError mkerr(HttpError err, HttpError def_err = HE_DEFAULT) {
  return (err != HE_NONE) ? err : def_err;
}

WEBRTC_DLLEXPORT const char* ToString(HttpVersion version);
WEBRTC_DLLEXPORT bool FromString(HttpVersion& version, const rtc::rtcstring& str);

WEBRTC_DLLEXPORT const char* ToString(HttpVerb verb);
WEBRTC_DLLEXPORT bool FromString(HttpVerb& verb, const rtc::rtcstring& str);

WEBRTC_DLLEXPORT const char* ToString(HttpHeader header);
WEBRTC_DLLEXPORT bool FromString(HttpHeader& header, const rtc::rtcstring& str);

inline bool HttpCodeIsInformational(uint32_t code) {
  return ((code / 100) == 1);
}
inline bool HttpCodeIsSuccessful(uint32_t code) {
  return ((code / 100) == 2);
}
inline bool HttpCodeIsRedirection(uint32_t code) {
  return ((code / 100) == 3);
}
inline bool HttpCodeIsClientError(uint32_t code) {
  return ((code / 100) == 4);
}
inline bool HttpCodeIsServerError(uint32_t code) {
  return ((code / 100) == 5);
}

WEBRTC_DLLEXPORT bool HttpCodeHasBody(uint32_t code);
WEBRTC_DLLEXPORT bool HttpCodeIsCacheable(uint32_t code);
WEBRTC_DLLEXPORT bool HttpHeaderIsEndToEnd(HttpHeader header);
WEBRTC_DLLEXPORT bool HttpHeaderIsCollapsible(HttpHeader header);

struct HttpData;
WEBRTC_DLLEXPORT bool HttpShouldKeepAlive(const HttpData& data);

struct HttpAttribute
{
    rtcstring first;
    rtcstring second;
    HttpAttribute()
    {
    }
};

class HttpAttributeList
{
public:
    HttpAttributeList();
    HttpAttributeList (const HttpAttributeList& x);
    ~HttpAttributeList();
    HttpAttributeList& operator= (const HttpAttributeList& x);
    size_t size() const;
    void clear();
    void resize (size_t n, HttpAttribute val = HttpAttribute());
    size_t capacity() const;
    bool empty() const;
    void reserve (size_t n);
    HttpAttribute &operator[] (size_t n);
    const HttpAttribute &operator[] (size_t n) const;
    HttpAttribute &at (size_t n);
    const HttpAttribute &at (size_t n) const;

    HttpAttribute &front();
    const HttpAttribute &front() const;

    HttpAttribute &back();
    const HttpAttribute &back() const;

    HttpAttribute* data() noexcept;
    const HttpAttribute* data() const noexcept;

    void assign (size_t n, const HttpAttribute& val);

    void push_back (const HttpAttribute& val);
    void pop_back();
    const std::vector<HttpAttribute> &GetVector() const;
    std::vector<HttpAttribute> &GetVector();

private:
    std::vector<HttpAttribute> m_httpattr;
};

WEBRTC_DLLEXPORT void HttpComposeAttributes(const HttpAttributeList& attributes, char separator,
                           rtcstring* composed);
WEBRTC_DLLEXPORT void HttpParseAttributes(const char * data, size_t len,
                         HttpAttributeList& attributes);
WEBRTC_DLLEXPORT bool HttpHasAttribute(const HttpAttributeList& attributes,
                      const rtcstring& name,
                      rtcstring* value);
WEBRTC_DLLEXPORT bool HttpHasNthAttribute(HttpAttributeList& attributes,
                         size_t index,
                         rtcstring* name,
                         rtcstring* value);

// Convert RFC1123 date (DoW, DD Mon YYYY HH:MM:SS TZ) to unix timestamp
WEBRTC_DLLEXPORT bool HttpDateToSeconds(const rtc::rtcstring& date, time_t* seconds);

inline uint16_t HttpDefaultPort(bool secure) {
  return secure ? HTTP_SECURE_PORT : HTTP_DEFAULT_PORT;
}

// Returns the http server notation for a given address
WEBRTC_DLLEXPORT rtcstring HttpAddress(const SocketAddress& address, bool secure);

// functional for insensitive std::string compare
struct iless {
  bool operator()(const rtc::rtcstring& lhs, const rtc::rtcstring& rhs) const {
    return (::_stricmp(lhs.c_str(), rhs.c_str()) < 0);
  }
};

// put quotes around a string and escape any quotes inside it
rtcstring quote(const rtcstring& str);

//////////////////////////////////////////////////////////////////////
// Url
//////////////////////////////////////////////////////////////////////

template<class CTYPE>
class WEBRTC_DLLEXPORT Url {
public:
  typedef typename Traits<CTYPE>::string string;

  // TODO: Implement Encode/Decode
  static int Encode(const CTYPE* source, CTYPE* destination, size_t len);
  static int Encode(const rtcstring& source, rtcstring& destination);
  static int Decode(const CTYPE* source, CTYPE* destination, size_t len);
  static int Decode(const rtcstring& source, rtcstring& destination);

  Url(const rtcstring& url) { do_set_url(url.c_str(), url.size()); }
  Url(const rtcstring& path, const rtcstring& host, uint16_t port = HTTP_DEFAULT_PORT)
      : host_(host), port_(port), secure_(HTTP_SECURE_PORT == port) {
    set_full_path(path);
  }

  bool valid() const { return !host_.empty(); }
  void clear() {
    host_.clear();
    port_ = HTTP_DEFAULT_PORT;
    secure_ = false;
    path_.assign(1, static_cast<CTYPE>('/'));
    query_.clear();
  }

  void set_url(const rtcstring& val) {
    do_set_url(val.c_str(), val.size());
  }
  rtcstring url() const {
	  rtcstring val; do_get_url(&val); return val;
  }

  void set_address(const rtcstring& val) {
    do_set_address(val.c_str(), val.size());
  }
  rtcstring address() const {
	  rtcstring val; do_get_address(&val); return val;
  }

  void set_full_path(const rtcstring& val) {
    do_set_full_path(val.c_str(), val.size());
  }
  rtcstring full_path() const {
	  rtcstring val; do_get_full_path(&val); return val;
  }

  void set_host(const rtcstring& val) { host_ = val; }
  const rtcstring& host() const { return host_; }

  void set_port(uint16_t val) { port_ = val; }
  uint16_t port() const { return port_; }

  void set_secure(bool val) { secure_ = val; }
  bool secure() const { return secure_; }

  void set_path(const string& val) {
    if (val.empty()) {
      path_.assign(1, static_cast<CTYPE>('/'));
    } else {
      ASSERT(val[0] == static_cast<CTYPE>('/'));
      path_ = val;
    }
  }
  const rtcstring& path() const { return path_; }

  void set_query(const string& val) {
    ASSERT(val.empty() || (val[0] == static_cast<CTYPE>('?')));
    query_ = val;
  }
  const rtcstring& query() const { return query_; }

  bool get_attribute(const rtcstring& name, rtcstring* value) const;

private:
  void do_set_url(const CTYPE* val, size_t len);
  void do_set_address(const CTYPE* val, size_t len);
  void do_set_full_path(const CTYPE* val, size_t len);

  void do_get_url(rtcstring* val) const;
  void do_get_address(rtcstring* val) const;
  void do_get_full_path(rtcstring* val) const;

  rtcstring host_, path_, query_;
  uint16_t port_;
  bool secure_;
};

//////////////////////////////////////////////////////////////////////
// HttpData
//////////////////////////////////////////////////////////////////////

struct WEBRTC_DLLEXPORT HttpData {
  typedef std::multimap<rtcstring, rtcstring, iless> HeaderMap;
  typedef HeaderMap::const_iterator const_iterator;
  typedef HeaderMap::iterator iterator;

  HttpVersion version;
  scoped_ptr<StreamInterface> document;

  HttpData();

  enum HeaderCombine { HC_YES, HC_NO, HC_AUTO, HC_REPLACE, HC_NEW };
  void changeHeader(const rtcstring& name, const rtcstring& value,
                    HeaderCombine combine);
  inline void addHeader(const rtcstring& name, const rtcstring& value,
                        bool append = true) {
    changeHeader(name, value, append ? HC_AUTO : HC_NO);
  }
  inline void setHeader(const rtcstring& name, const rtcstring& value,
                        bool overwrite = true) {
    changeHeader(name, value, overwrite ? HC_REPLACE : HC_NEW);
  }
  // Returns count of erased headers
  size_t clearHeader(const rtcstring& name);
  // Returns iterator to next header
  iterator clearHeader(iterator header);

  // keep in mind, this may not do what you want in the face of multiple headers
  bool hasHeader(const rtcstring& name, rtcstring* value) const;

  inline const_iterator begin() const {
    return headers_.begin();
  }
  inline const_iterator end() const {
    return headers_.end();
  }
  inline iterator begin() {
    return headers_.begin();
  }
  inline iterator end() {
    return headers_.end();
  }
  inline const_iterator begin(const rtcstring& name) const {
    return headers_.lower_bound(name);
  }
  inline const_iterator end(const rtcstring& name) const {
    return headers_.upper_bound(name);
  }
  inline iterator begin(const rtcstring& name) {
    return headers_.lower_bound(name);
  }
  inline iterator end(const rtcstring& name) {
    return headers_.upper_bound(name);
  }

  // Convenience methods using HttpHeader
  inline void changeHeader(HttpHeader header, const rtcstring& value,
                           HeaderCombine combine) {
    changeHeader(ToString(header), value, combine);
  }
  inline void addHeader(HttpHeader header, const rtcstring& value,
                        bool append = true) {
    addHeader(ToString(header), value, append);
  }
  inline void setHeader(HttpHeader header, const rtcstring& value,
                        bool overwrite = true) {
    setHeader(ToString(header), value, overwrite);
  }
  inline void clearHeader(HttpHeader header) {
    clearHeader(ToString(header));
  }
  inline bool hasHeader(HttpHeader header, rtcstring* value) const {
    return hasHeader(ToString(header), value);
  }
  inline const_iterator begin(HttpHeader header) const {
    return headers_.lower_bound(ToString(header));
  }
  inline const_iterator end(HttpHeader header) const {
    return headers_.upper_bound(ToString(header));
  }
  inline iterator begin(HttpHeader header) {
    return headers_.lower_bound(ToString(header));
  }
  inline iterator end(HttpHeader header) {
    return headers_.upper_bound(ToString(header));
  }

  void setContent(const rtcstring& content_type, StreamInterface* document);
  void setDocumentAndLength(StreamInterface* document);

  virtual size_t formatLeader(char* buffer, size_t size) const = 0;
  virtual HttpError parseLeader(const char* line, size_t len) = 0;

protected:
 virtual ~HttpData();
  void clear(bool release_document);
  void copy(const HttpData& src);

private:
  HeaderMap headers_;
};

struct WEBRTC_DLLEXPORT HttpRequestData : public HttpData {
  HttpVerb verb;
  rtcstring path;

  HttpRequestData() : verb(HV_GET) { }

  void clear(bool release_document);
  void copy(const HttpRequestData& src);

  size_t formatLeader(char* buffer, size_t size) const override;
  HttpError parseLeader(const char* line, size_t len) override;

  bool getAbsoluteUri(rtcstring* uri) const;
  bool getRelativeUri(rtcstring* host, rtcstring* path) const;
};

struct WEBRTC_DLLEXPORT HttpResponseData : public HttpData {
  uint32_t scode;
  rtcstring message;

  HttpResponseData() : scode(HC_INTERNAL_SERVER_ERROR) { }
  void clear(bool release_document);
  void copy(const HttpResponseData& src);

  // Convenience methods
  void set_success(uint32_t scode = HC_OK);
  void set_success(const rtcstring& content_type,
                   StreamInterface* document,
                   uint32_t scode = HC_OK);
  void set_redirect(const rtcstring& location,
                    uint32_t scode = HC_MOVED_TEMPORARILY);
  void set_error(uint32_t scode);

  size_t formatLeader(char* buffer, size_t size) const override;
  HttpError parseLeader(const char* line, size_t len) override;
};

struct WEBRTC_DLLEXPORT HttpTransaction {
  HttpRequestData request;
  HttpResponseData response;
};

//////////////////////////////////////////////////////////////////////
// Http Authentication
//////////////////////////////////////////////////////////////////////

struct HttpAuthContext {
  rtcstring auth_method;
  HttpAuthContext(const rtcstring& auth) : auth_method(auth) { }
  virtual ~HttpAuthContext() { }
};

enum HttpAuthResult { HAR_RESPONSE, HAR_IGNORE, HAR_CREDENTIALS, HAR_ERROR };

// 'context' is used by this function to record information between calls.
// Start by passing a null pointer, then pass the same pointer each additional
// call.  When the authentication attempt is finished, delete the context.
WEBRTC_DLLEXPORT HttpAuthResult HttpAuthenticate(
  const char * challenge, size_t len,
  const SocketAddress& server,
  const rtcstring& method, const rtcstring& uri,
  const rtcstring& username, const CryptString& password,
  HttpAuthContext *& context, rtcstring& response, rtcstring& auth_method);

//////////////////////////////////////////////////////////////////////

} // namespace rtc

#endif // WEBRTC_BASE_HTTPCOMMON_H__
