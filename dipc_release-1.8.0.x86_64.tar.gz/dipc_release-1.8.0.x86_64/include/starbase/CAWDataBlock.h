/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/
#ifndef CAWDATABLOCK_H
#define CAWDATABLOCK_H

#include "CAWStdCpp.h"
#include "CAWReferenceControl.h"

class CAW_OS_EXPORT CAWDataBlock : public CAWReferenceControlMutilThread
{
public:
    // Malloc a buffer with <aSize> and copy <aData> into it.
    static CAWResult CreateInstance(CAWDataBlock *&aDb, size_t aSize, LPCSTR aData = NULL);

    // interface CAWReferenceControlMutilThread.
    virtual void OnReferenceDestory();

    LPSTR GetBasePtr() const 
    {
        return m_pData;
    }

    size_t GetLength() const 
    {
        return m_dwSize;
    }

    size_t GetCapacity() const 
    {
        return m_dwSize;
    }

private:
    size_t m_dwSize;
    LPSTR m_pData;

private:
    // = Prevent assignment and initialization.
    void operator = (const CAWDataBlock&);
    CAWDataBlock(const CAWDataBlock&);

    // Make constructor and Destructor functions private,
    // so that we will do our memery allocation.
    CAWDataBlock(size_t aSize, LPSTR aData = NULL);
    virtual ~CAWDataBlock();
};

#endif // !CAWDATABLOCK_H