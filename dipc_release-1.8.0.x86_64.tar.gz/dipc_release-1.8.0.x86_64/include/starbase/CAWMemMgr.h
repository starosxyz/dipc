/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef __CMD_MEMORY_MGR__
#define __CMD_MEMORY_MGR__

#include <stdlib.h>
#ifdef WIN32
#	include <malloc.h>
#endif

#ifndef __CAW_MEM_CHECK__

#define CAW_MALLOC	malloc
#define CAW_FREE(p)			\
	do					\
	{					\
		if((p))			\
		{				\
			free((p));	\
			(p) = NULL;	\
		}				\
	}					\
	while(0)			\

#else//__CAW_MEM_CHECK__

#include "CAWDefines.h"

#pragma  warning (disable :4291)

extern "C" 
{
	void* CAW_malloc(size_t len, BYTE* filename, long lineno); //it will set the memory to 0;
	void* CAW_calloc(size_t nmemb, size_t size, BYTE* filename, long lineno);
	void* CAW_realloc(void* ptr, size_t len, BYTE* filename, long lineno);
	void CAW_free(void* ptr);
	void CAW_memdump();
}

#define CAW_MALLOC(l)		CAW_malloc(l, __FILE__, __LINE__)
#define CAW_FREE(p)			CAW_free(p)
#define calloc(n, s)		CAW_calloc(n, s, __FILE__, __LINE__)
#define realloc(p, l)		CAW_realloc(p, l,__FILE__, __LINE__)

inline void* operator new(size_t size, BYTE* file, long lineno) throw ()
{
	return CAW_malloc(size, file, lineno);
}

inline void* operator new[] (size_t size, BYTE* file, long lineno)
{
	return CAW_malloc(size, file, lineno);
}

inline void operator delete(void *p)
{
	CAW_free(p);
}

inline void operator delete[](void* p)
{
	CAW_free(p);
}

#define new _MY_CRT_DEBUG_NEW
#define _MY_CRT_DEBUG_NEW new( __FILE__, __LINE__)

#endif //!__CAW_MEM_CHECK__

#endif

