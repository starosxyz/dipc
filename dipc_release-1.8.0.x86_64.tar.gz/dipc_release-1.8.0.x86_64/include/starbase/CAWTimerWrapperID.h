/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTIMERWRAPPERID_H
#define CAWTIMERWRAPPERID_H
#include "CAWDebug.h"
#include "CAWThreadInterface.h"

class CAWTimeValue;
class CAWTimerWrapperID;

class CAW_OS_EXPORT CAWTimerWrapperIDSink
{
public:
    virtual void OnTimer(CAWTimerWrapperID* aId) = 0;

protected:
    virtual ~CAWTimerWrapperIDSink();
};

class CAW_OS_EXPORT CAWTimerWrapperID : public IAWTimerHandler
{
public:
    CAWTimerWrapperID();
    virtual ~CAWTimerWrapperID();

    /// Schedule an timer that will expire after <aInterval> for <aCount> times. 
    /// if <aCount> is 0, schedule infinite times.
    CAWResult Schedule(
        CAWTimerWrapperIDSink* aSink,
        const CAWTimeValue &aInterval,
        DWORD aCount = 0);

    /// Cancel the timer.
    CAWResult Cancel();

protected:
    virtual void OnTimeout(const CAWTimeValue &aCurTime, LPVOID aArg);

private:
    BOOL m_bScheduled;
    IAWTimerQueue *m_pTimerQueue;
};

#endif // !CAWTIMERWRAPPERID_H

