/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWBASE64_H
#define CAWBASE64_H
#include "CAWStdCpp.h"
#include "CAWDefines.h"
#include "CAWError.h"
#include "CAWDebug.h"
#include "CAWReferenceControl.h"
#include "CAWMutex.h"
#include "CAWThreadManager.h"
#include "CAWThread.h"
#include "CAWUtilClasses.h"
#include "CAWTimeValue.h"

CAW_OS_EXPORT const char* CAW_strcaserstr(
    const char *big, 
    const char *little);

CAW_OS_EXPORT void CAW_Base64Decode(
    const char *bufcoded, 
    CAWString &strDest);

CAW_OS_EXPORT void CAW_Base64Encode(
    const unsigned char *bufin, 
    size_t nbytes, 
    CAWString &strDest);


#endif // !CAWBASE64_H

