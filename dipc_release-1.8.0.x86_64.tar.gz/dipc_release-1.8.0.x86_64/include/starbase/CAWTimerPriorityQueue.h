/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTIMERPRIORITYQUEUE_H
#define CAWTIMERPRIORITYQUEUE_H

#include "CAWTimerQueueBase.h"
#include "CAWPriorityQueueT.h"
#include <unordered_map>


class CAW_OS_EXPORT CAWTimerPriorityQueue : public CAWTimerQueueBase
{
public:
    struct TimeValueComp
    {
        bool operator()(const CNode &node1, const CNode &node2)
        {
            //assert((pMessage1 != nullptr) && (pMessage2 != nullptr));
            if ((node1.m_tvExpired<node2.m_tvExpired) == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    };
    CAWTimerPriorityQueue();
    virtual ~CAWTimerPriorityQueue ();
    virtual int CheckExpire(CAWTimeValue *aRemainTime = NULL);
    void Dump();
    void Dump(const CNode &node);
protected:
    virtual int PushNode_l(const CNode &aPushNode);
    virtual int EraseNode_l(IAWTimerHandler *aEh);
    virtual int RePushNode_l(const CNode &aPushNode);
    virtual int PopFirstNode_l(CNode &aPopNode);
    virtual int GetEarliestTime_l(CAWTimeValue &aEarliest) const;
private:
    typedef CAWPriorityQueueT<CNode, std::vector<CNode>, TimeValueComp> PriorityQueueType;
    PriorityQueueType m_queue;
    std::unordered_map<IAWTimerHandler*,CNode> m_Nodemap;
};


#endif//CAWTIMERPRIORITYQUEUE_H

