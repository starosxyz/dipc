/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTIMERQUEUEORDEREDLIST_H
#define CAWTIMERQUEUEORDEREDLIST_H

#include "CAWTimerQueueBase.h"
#include <list>

class CAW_OS_EXPORT CAWTimerQueueOrderedList : public CAWTimerQueueBase
{
public:
    CAWTimerQueueOrderedList(IAWObserver *aObserver);
    virtual ~CAWTimerQueueOrderedList();

protected:
    virtual int PushNode_l(const CNode &aPushNode);
    virtual int EraseNode_l(IAWTimerHandler *aEh);
    virtual int RePushNode_l(const CNode &aPushNode);
    virtual int PopFirstNode_l(CNode &aPopNode);
    virtual int GetEarliestTime_l(CAWTimeValue &aEarliest) const;

private:
    int EnsureSorted();
    typedef std::list<CNode> NodesType;
    NodesType m_Nodes;
};

#endif // !CAWTIMERQUEUEORDEREDLIST_H

