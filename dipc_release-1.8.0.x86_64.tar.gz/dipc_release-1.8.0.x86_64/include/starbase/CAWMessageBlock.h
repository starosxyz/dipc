/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWMESSAGEBLOCK_H
#define CAWMESSAGEBLOCK_H

#include "CAWStdCpp.h"
#include "CAWReferenceControl.h"
#include "CAWDebug.h"
#include "CAWDataBlock.h"

class CAW_OS_EXPORT CAWMessageBlock 
{
public:
    enum 
    {
        /// Don't delete the data on exit since we don't own it.
        DONT_DELETE = 1 << 0,

        /// Malloc and copy data internally
        MALLOC_AND_COPY = 1 << 1,

        /// Can't read/write.
        READ_LOCKED = 1 << 8,
        WRITE_LOCKED = 1 << 9,

        /// the following flags are only for internal purpose.
        INTERNAL_MASK = 0xFF00,
        DUPLICATED = 1 << 17,
    };
    typedef unsigned long MFlag;

    /**
        * Create an initialized message containing <aSize> bytes. 
        * AdvanceTopLevelWritePtr for <aAdvanceWritePtrSize> bytes.
        * If <aData> == 0 then we create and own the <aData>;
        * If <aData> != 0 
        *   If <aFlag> == DONT_DELETE, do nothing when destruction;
        *   Else delete it when destruction;
        */
    explicit CAWMessageBlock(
        size_t aSize, 
        LPCSTR aData = NULL, 
        MFlag aFlag = 0, 
        size_t aAdvanceWritePtrSize = 0);

    explicit CAWMessageBlock(CAWDataBlock *aDb, MFlag aFlag = 0);

    //~CAWMessageBlock();

    /// Read <aCount> bytes, advance it if <aAdvance> is TRUE,
    /// if <aDst> != NULL, copy data into it.
    CAWResult Read(LPVOID aDst, size_t aCount, size_t *aBytesRead = NULL, BOOL aAdvance = TRUE);

    /// Write and advance <aCount> bytes from <aSrc> to the top-level <CAWMessageBlock>
    CAWResult Write(LPCVOID aSrc, size_t aCount, size_t *aBytesWritten = NULL);

    /// Get the length of the <CAWMessageBlock>s, including chained <CAWMessageBlock>s.
    size_t GetChainedLength() const ;
    size_t GetChainedCapacity() const;

    /// Get the space of the <CAWMessageBlock>s, including chained <CAWMessageBlock>s.
    size_t GetChainedSpace() const ;

    // Don't export <CAWDataBlock> because it maybe realloc when AddReference(),
    // the Base() is not the same as previous one.
    //CAWDataBlock* GetDataBlock();

    // Append <aMb> to the end chain.
    void Append(CAWMessageBlock *aMb);

    // Get the next <CAWMessageBlock>
    CAWMessageBlock* GetNext();

    /// Advance <aCount> bytes for reading in chained <CAWMessageBlock>s.
    CAWResult AdvanceChainedReadPtr(size_t aCount, size_t *aBytesRead = NULL);

    /// Advance <aCount> bytes for writing in chained <CAWMessageBlock>s.
    /// <CAWMessageBlock> must never be read before, and could write continually.
    CAWResult AdvanceChainedWritePtr(size_t aCount, size_t *aBytesWritten = NULL);

    /// Return a "shallow" copy that not memcpy actual data buffer.
    /// Use DestroyChained() to delete the return <CAWMessageBlock>.
    CAWMessageBlock* DuplicateChained();

    /// Disjoint the chained <CAWMessageBlock>s at the start point <aStart>.
    /// return the new <CAWMessageBlock> that advanced <aStart> read bytes from the old.
    /// <aStart> must be less than ChainedLength.
    /// Use DestroyChained() to delete the return <CAWMessageBlock>.
    CAWMessageBlock* Disjoint(size_t aStart);

    void DestroyChained();

    /// Fill iovec to make socket read/write effectively.
    size_t FillIov(iovec aIov[], size_t aMax) const;
#if defined(CAW_WIN32)
    size_t FillWSABUF(WSABUF aIov[], size_t aMax) const;
#endif
    /// For enhanced checking, mainly for debug purpose.
    void LockReading();
    void LockWriting();

    /// Destory chained <CAWMessageBlock>s whose length is 0.
    /// return the number of destroyed <CAWMessageBlock>.
    CAWMessageBlock* ReclaimGarbage();

    /// Copy all chained data.
    CAWString FlattenChained();

public:
    /// Get <m_pReadPtr> of the top-level <CAWMessageBlock>
    LPCSTR GetTopLevelReadPtr() const ;
    /// Advance <aStep> bytes from <m_pReadPtr> of the top-level <CAWMessageBlock>
    CAWResult AdvanceTopLevelReadPtr(size_t aStep);

    /// Get <m_pWritePtr> of the top-level <CAWMessageBlock>
    LPSTR GetTopLevelWritePtr() const ;
    /// Advance <aStep> bytes from <m_pWritePtr> of the top-level <CAWMessageBlock>
    CAWResult AdvanceTopLevelWritePtr(size_t aStep);

    /// Message length is (<m_pWritePtr> - <m_pReadPtr>).
    /// Get the length in the top-level <CAWMessageBlock>.
    size_t GetTopLevelLength() const ;

    /// Get the number of bytes available after the <m_pWritePtr> in the top-level <CAWMessageBlock>.
    size_t GetTopLevelSpace() const ;

    /// Rewind <m_pReadPtr> of chained <CAWMessageBlock>s to their beginnings,
    /// It's not safe because it don't record first read ptr if it not equals <m_pBeginPtr>.
    void RewindChained();

    /// Return a "shallow" copy of the top-level <CAWMessageBlock>,
    /// if flag set DONT_DELETE, malloc and memcpy actual data,
    /// else just does CAWDataBlock::AddReference().
    CAWMessageBlock* DuplicateTopLevel() const ;

private:
    void Reset_i(CAWDataBlock *aDb);

private:
    CAWMessageBlock *m_pNext;
    CAWAutoPtr<CAWDataBlock> m_pDataBlock;
    LPCSTR m_pReadPtr;
    LPSTR m_pWritePtr;
    LPCSTR m_pBeginPtr;
    LPCSTR m_pEndPtr;
    MFlag m_Flag;

private:
    // = Prevent assignment and initialization.
    CAWMessageBlock(const CAWMessageBlock &);
    void operator = (const CAWMessageBlock&);
};


// inline functions.
inline void CAWMessageBlock::Reset_i(CAWDataBlock *aDb)
{
    m_pDataBlock = aDb;
    m_pBeginPtr = m_pDataBlock ? m_pDataBlock->GetBasePtr() : NULL;
    m_pReadPtr = m_pBeginPtr;
    m_pWritePtr = const_cast<LPSTR>(m_pBeginPtr);
    m_pEndPtr = m_pBeginPtr + (m_pDataBlock ? m_pDataBlock->GetLength() : (DWORD)0);
}

inline size_t CAWMessageBlock::GetTopLevelLength() const
{
    CAW_ASSERTE(m_pWritePtr >= m_pReadPtr);
    return m_pWritePtr - m_pReadPtr;
}

inline size_t CAWMessageBlock::GetTopLevelSpace() const 
{
    CAW_ASSERTE(m_pEndPtr >= m_pWritePtr);
    return m_pEndPtr - m_pWritePtr;
}

inline CAWMessageBlock* CAWMessageBlock::GetNext()
{
    return m_pNext;
}

inline LPCSTR CAWMessageBlock::GetTopLevelReadPtr() const 
{
    CAW_ASSERTE(CAW_BIT_DISABLED(m_Flag, READ_LOCKED));
    return m_pReadPtr;
}

inline LPSTR CAWMessageBlock::GetTopLevelWritePtr() const 
{
    CAW_ASSERTE(CAW_BIT_DISABLED(m_Flag, WRITE_LOCKED));
    return m_pWritePtr;
}

inline CAWResult CAWMessageBlock::AdvanceTopLevelWritePtr(size_t aStep)
{
    CAW_ASSERTE(CAW_BIT_DISABLED(m_Flag, WRITE_LOCKED));
    CAW_ASSERTE_RETURN(m_pWritePtr + aStep <= m_pEndPtr, CAW_ERROR_NOT_AVAILABLE);
    m_pWritePtr += aStep;
    return CAW_OK;
}

inline CAWResult CAWMessageBlock::AdvanceTopLevelReadPtr(size_t aStep)
{
    CAW_ASSERTE(CAW_BIT_DISABLED(m_Flag, READ_LOCKED));
    CAW_ASSERTE_RETURN(m_pWritePtr >= m_pReadPtr + aStep, CAW_ERROR_NOT_AVAILABLE);
    m_pReadPtr += aStep;
    return CAW_OK;
}

inline void CAWMessageBlock::LockReading()
{
    CAW_SET_BITS(m_Flag, READ_LOCKED);
}

inline void CAWMessageBlock::LockWriting()
{
    CAW_SET_BITS(m_Flag, WRITE_LOCKED);
}


#endif // !CAWMESSAGEBLOCK_H
