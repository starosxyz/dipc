/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTHREADREACTOR_H
#define CAWTHREADREACTOR_H

#include "CAWThreadInterface.h"
#include "CAWThread.h"

class IAWReactor;
class CAW_OS_EXPORT CAWThreadReactor : public CAWThread  
{
public:
    CAWThreadReactor();
    virtual ~CAWThreadReactor();
    CAWResult Init(IAWReactor *aReactor);
    // interface CAWThread
    virtual CAWResult Create(CAWThreadManager::TType aType, CAWThreadManager::TFlag aFlag = CAWThreadManager::TF_JOINABLE);
    virtual CAWResult Stop(CAWTimeValue* aTimeout = NULL);

    virtual void OnThreadInit();
    virtual void OnThreadRun();

    virtual IAWReactor* GetReactor();
    virtual IAWEventQueue* GetEventQueue();
    virtual IAWTimerQueue* GetTimerQueue();

 private:
    IAWReactor *m_pReactor;
};

/// used for netwok thread is the same as main thread.
class CAW_OS_EXPORT CAWThreadDummy : public CAWThread  
{
public:
    CAWThreadDummy();
    virtual ~CAWThreadDummy();

    CAWResult Init(CAWThread *aThread, CAWThreadManager::TType aType);

    // interface CAWThread
    virtual CAWResult Create(
    	CAWThreadManager::TType aType, 
    	CAWThreadManager::TFlag aFlag = CAWThreadManager::TF_JOINABLE);

    virtual CAWResult Stop(CAWTimeValue* aTimeout = NULL);

    virtual void OnThreadRun();

    virtual IAWReactor* GetReactor();
    virtual IAWEventQueue* GetEventQueue();
    virtual IAWTimerQueue* GetTimerQueue();

private:
    CAWThread *m_pActualThread;
};

#endif //CAWTHREADREACTOR_H

