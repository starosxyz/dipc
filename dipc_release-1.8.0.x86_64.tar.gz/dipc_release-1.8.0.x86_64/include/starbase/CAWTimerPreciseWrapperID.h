/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/

#ifndef CAWTIMERPRECISEWRAPPERID_H
#define CAWTIMERPRECISEWRAPPERID_H

#include "CAWReactorInterface.h"
#include "CAWThread.h"
class CAWTimerWrapperID;
class CAWTimerQueueCalendar;
class CAWTimerPreciseWrapperID;


class CAW_OS_EXPORT CAWTimerPreciseWrapperIDSink
{
public:
    virtual void OnTimer(CAWTimerPreciseWrapperID* aId) = 0;

protected:
    virtual ~CAWTimerPreciseWrapperIDSink(){};
};


class CAW_OS_EXPORT CAWTimerPreciseManager
                : public CAWThread
                , public CAWStopFlag
{
private:
    CAWTimerPreciseManager();

public:
    virtual ~CAWTimerPreciseManager();

    static CAWTimerPreciseManager* Instance();

    //Implement interface CAWThread.
    virtual void OnThreadInit();
    virtual void OnThreadRun();
    virtual CAWResult Stop(CAWTimeValue* aTimeout = NULL);

    CAWResult Schedule(
        CAWTimerPreciseWrapperID* aTimerId,
        CAWTimerPreciseWrapperIDSink* aSink,
        const CAWTimeValue &aInterval,
        DWORD aCount = 0);
    CAWResult Cancel(CAWTimerPreciseWrapperID* aTimerId);
    
private:

    CAWTimerQueueCalendar* m_pTimerQueue;
    WORD m_wTimerRes; //timer resolution
    WORD m_wTimerId;  //timer ID

    CAWMutexThread m_Mutex;
};

class CAW_OS_EXPORT CAWTimerPreciseWrapperID
    : public IAWTimerHandler
{
public:
    CAWTimerPreciseWrapperID();
    virtual ~CAWTimerPreciseWrapperID();

    CAWResult Schedule( CAWTimerPreciseWrapperIDSink* aSink,
            const CAWTimeValue &aInterval,
            DWORD aCount = 0,
            CAWThreadManager::TType aTType = CAWThreadManager::TT_MAIN);

    CAWResult Cancel();

    //Implement interface IAWTimerHandler
    virtual void OnTimeout(const CAWTimeValue &aCurTime, LPVOID aArg);

public:
    BOOL GetStatus(){ return m_bScheduled; }

private:
    BOOL m_bScheduled;
    CAWThreadManager::TType m_TType;
    CAWThread* m_pThread; //for OnTimeOut callback.
    IAWEventQueue* m_pEventQueue;
};


class CAW_OS_EXPORT CEventTimer : public IAWEvent
{
public:
    CEventTimer(CAWTimerPreciseWrapperIDSink *pSink,CAWTimerPreciseWrapperID* pTimerId);
    virtual ~CEventTimer();

    //Implement IAWEvent;
    virtual CAWResult OnEventFire();

private:
    CAWTimerPreciseWrapperIDSink* m_pSink;
    CAWTimerPreciseWrapperID* m_pTimerId;
};


#endif // !CAWTIMERPRECISEWRAPPERID_H