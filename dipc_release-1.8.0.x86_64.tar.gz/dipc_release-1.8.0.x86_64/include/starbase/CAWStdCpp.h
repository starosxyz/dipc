/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/

#ifndef CAWSTDCPP_H
#define CAWSTDCPP_H

//#define CAW_DISABLE_MSVCP_DLL 1

#if defined (_MSC_VER) && defined (_DLL) && defined (CAW_DISABLE_MSVCP_DLL)
//  #pragma warning(disable:4273)

  #undef _CRTIMP
  #define _CRTIMP

  #ifdef _DEBUG
    //#pragma comment(linker, "/NODEFAULTLIB:LIBCMTD")
    //#pragma comment(linker, "/NODEFAULTLIB:MSVCPRTD")
    #pragma comment(lib, "LIBCPMTD")
  #else
    //#pragma comment(linker, "/NODEFAULTLIB:LIBCMT")
    //#pragma comment(linker, "/NODEFAULTLIB:MSVCPRT")
    #pragma comment(lib, "LIBCPMT")
  #endif // _DEBUG

  // Don't include "use_ansi.h" of the VC include directory.
  #ifdef _USE_ANSI_CPP
    #error Error: please include this file before include STL head files such as <map>, etc.
  #endif // _USE_ANSI_CPP
  #define _USE_ANSI_CPP

#endif // _MSC_VER && _DLL && CAW_DISABLE_MSVCP_DLL

#include <memory>
#include <algorithm>
//#include <stdexcept>

#ifdef _MSC_VER
  #ifndef min
    #define min(a,b)                        (((a) < (b)) ? a : b)
  #endif
  #ifndef max
   #define max(a,b)                        (((a) > (b)) ? a : b)
  #endif
#endif // _MSC_VER

#if defined (_MSC_VER) && defined (_DLL) && defined (CAW_DISABLE_MSVCP_DLL)
  #include <xiosbase>
  #undef _DLL
  #include <fstream>
  #include <string>
  #include <locale>
  #define _DLL
//  #include <iostream>
#else
  #include <string>
  #include <string.h>
#endif // _MSC_VER && _DLL && CAW_DISABLE_MSVCP_DLL

#include <set> 
#include <map>
#include <vector>
#include <list>
#include <queue>
#include <stack>
#include <unordered_map>
#include <iostream> 
#include <fstream> 

#if defined (_MSC_VER) && defined (_DLL) && defined (CAW_DISABLE_MSVCP_DLL)
  #undef _CRTIMP
  #define _CRTIMP __declspec(dllimport)
#endif // _MSC_VER && _DLL && CAW_DISABLE_MSVCP_DLL

#endif // CAWSTDCPP_H

