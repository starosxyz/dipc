/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWEVENTQUEUEBASE_H
#define CAWEVENTQUEUEBASE_H

#include "CAWConditionVariable.h"
#include "CAWTimeValue.h"
#include <list>
#include "CAWThreadManager.h"

class CAWEventQueueBase;

class CAW_OS_EXPORT CAWEventSynchronous : public IAWEvent
{
public:
    CAWEventSynchronous(IAWEvent *aEventPost, CAWEventQueueBase *aEventQueue);
    virtual ~CAWEventSynchronous();

    // interface IAWEvent
    virtual CAWResult OnEventFire();
    virtual void OnDestorySelf();

    CAWResult WaitResultAndDeleteThis();

private:
    IAWEvent *m_pEventPost;
    CAWResult m_Result;
    CAWEventQueueBase *m_pEventQueue;
    BOOL m_bHasDestoryed;
    CAWEventThread m_SendEvent;
};

class CAW_OS_EXPORT CAWEventQueueBase : public IAWEventQueue
{
public:
    CAWEventQueueBase();
    virtual ~CAWEventQueueBase();

    // interface IAWEventQueue
    virtual CAWResult PostEvent(IAWEvent *aEvent, EPriority aPri = EPRIORITY_NORMAL);
    virtual CAWResult SendEvent(IAWEvent *aEvent);
    virtual DWORD GetPendingEventsCount();

    void Stop();

    void DestoryPendingEvents();

    void Reset2CurrentThreadId();

    enum { MAX_GET_ONCE = 100000 };
    typedef std::list<IAWEvent *> EventsType;

    // Don't make the following two functions static because we want trace size.
    CAWResult ProcessEvents(const EventsType &aEvents);
    CAWResult ProcessOneEvent(IAWEvent *aEvent);

    static CAWTimeValue s_tvReportInterval();

protected:
    CAWResult PopPendingEvents(
                    EventsType &aEvents, 
                    DWORD aMaxCount = MAX_GET_ONCE, 
                    DWORD *aRemainSize = NULL);

    CAWResult PopOnePendingEvent(
                    IAWEvent *&aEvent, 
                    DWORD *aRemainSize = NULL);

    EventsType m_Events;
    // we have to record the size of events list due to limition of std::list in Linux.
    DWORD m_dwSize;
    CAWTimeValue m_tvReportSize;

private:
    CAW_THREAD_ID m_Tid;
    BOOL m_bIsStopped;

    friend class CAWEventSynchronous;
};

class CAW_OS_EXPORT CAWEventQueueUsingMutex : public CAWEventQueueBase
{
public:
    CAWEventQueueUsingMutex();
    virtual ~CAWEventQueueUsingMutex();

    // interface IAWEventQueue
    virtual CAWResult PostEvent(IAWEvent *aEvent, EPriority aPri = EPRIORITY_NORMAL);

    // Pop <aMaxCount> pending events in the queue, 
    // if no events are pending, return at once.
    CAWResult PopPendingEventsWithoutWait(
        CAWEventQueueBase::EventsType &aEvents, 
        DWORD aMaxCount = MAX_GET_ONCE, 
        DWORD *aRemainSize = NULL);

    // Pop one pending events, and fill <aRemainSize> with remain size.
    // if no events are pending, return at once.
    CAWResult PopOnePendingEventWithoutWait(
        IAWEvent *&aEvent, 
        DWORD *aRemainSize = NULL);

    CAWResult PostEventWithOldSize(
        IAWEvent *aEvent, 
        EPriority aPri = EPRIORITY_NORMAL, 
        DWORD *aOldSize = NULL);

private:
    typedef CAWMutexThread MutexType;
    MutexType m_Mutex;
};


// inline functions
inline void CAWEventQueueBase::Reset2CurrentThreadId()
{
    m_Tid = CAWThreadManager::GetThreadSelfId();
}

inline void CAWEventQueueBase::Stop()
{
    m_bIsStopped = TRUE;
}


inline CAWEventQueueUsingMutex::CAWEventQueueUsingMutex()
{
}

inline CAWResult CAWEventQueueUsingMutex::PopPendingEventsWithoutWait(CAWEventQueueBase::EventsType &aEvents, 
    DWORD aMaxCount, DWORD *aRemainSize)
{
    CAWMutexGuardT<MutexType> theGuard(m_Mutex);
    return PopPendingEvents(aEvents, aMaxCount, aRemainSize);
}

inline CAWResult CAWEventQueueUsingMutex::PopOnePendingEventWithoutWait(IAWEvent *&aEvent, DWORD *aRemainSize)
{
    CAWMutexGuardT<MutexType> theGuard(m_Mutex);
    return PopOnePendingEvent(aEvent, aRemainSize);
}

#endif // !CAWEVENTQUEUEBASE_H