/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/
#ifndef CMACADDRESS_H
#define CMACADDRESS_H
#include "CAWDefines.h"
class CAW_OS_EXPORT CAWMacAddress
{
public:
    CAWMacAddress( const char  *inaddr = "");
    virtual ~CAWMacAddress();
    const char *ToString();
    void SetMacAddr(char macaddr[6]);
    unsigned int hashFunction() const;
    void ToOctet(char *buffer);
    bool ParseAddress( const char *inaddr);
    void FormatOutput();
    bool IsValid();
protected:
    char output_buffer[18];
    char address_buffer[6];
    bool valid_flag;
};

#endif

