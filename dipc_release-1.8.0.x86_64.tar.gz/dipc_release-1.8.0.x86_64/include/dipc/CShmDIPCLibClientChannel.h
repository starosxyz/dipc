/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef CDIPCLIBCLIENTCHANNEL_H
#define CDIPCLIBCLIENTCHANNEL_H
#include "CAWACEWrapper.h"
#include "CAWShmIPCStreamBase.h"
#include "CAWShmIPCInterface.h"
#include "DIPCPDUBase.h"
#include "dipc.h"
class CAW_OS_EXPORT CShmDIPCLibClientChannel : public CAWShmIPCStreamBase, public CAWTimerWrapperIDSink
{
public:
    CShmDIPCLibClientChannel();
    virtual ~CShmDIPCLibClientChannel();
    virtual CAWResult Init(IDIPCProcess *pprocess, 
                    uint16_t localjno,
                    uint16_t localserviceid,
                    uint16_t peerjno,
                    uint16_t peerserviceid);

    //IDIPCTransportSink
    virtual size_t HandleMessage(const char *msg, size_t msgsize);
    virtual void OnPeerDisconnect(CAWResult aReason);
    virtual void OnConnected(CAWResult aReason);
    virtual void OnRcvBufferOverFlow(WORD32 buffersize);
	virtual void OnClose();
	virtual void OnConnectFailure(CAWResult aReason);
    virtual void OnDIPCMessage(uint16_t type, 
        uint32_t xid, 
        const char *msg, 
        size_t msgsize) = 0;
    virtual CAWResult SendDIPCMessage(uint16_t type, uint32_t xid, const char *msg, size_t msgsize);
    virtual CAWResult SendDIPCMessage(uint16_t type, uint32_t xid, CAWMessageBlock &msg);
public:
    //CAWTimerWrapperIDSink
    virtual void OnTimer(CAWTimerWrapperID* aId);
protected:
    uint32_t m_nreconnect;
    bool m_isconnected;
    uint16_t m_localjno;
    uint16_t m_localserviceid;
    uint16_t m_peerjno;
    uint16_t m_peerserviceid;
    CAWTimerWrapperID m_timer;
};

#endif // !CMCONNECTORHTTPPROXYT_H

