/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef CDIPCLIBSERVERCHANNEL_H
#define CDIPCLIBSERVERCHANNEL_H
#include "CAWACEWrapper.h"

#include "CAWShmIPCStreamBase.h"
#include "DIPCPDUBase.h"

//template <class UpperLibType>
class CAW_OS_EXPORT CShmDIPCLibServerChannel :public CAWShmIPCStreamBase
{
public:
    CShmDIPCLibServerChannel(IAWShmIPCTransport *ptransport);
    virtual ~CShmDIPCLibServerChannel();

    //IDIPCTransportSink
    virtual size_t HandleMessage(const char *data, size_t datasize);
    virtual void OnPeerDisconnect(CAWResult aReason);
    virtual void OnConnected(CAWResult aReason);
    virtual void OnRcvBufferOverFlow(WORD32 buffersize);
	virtual void OnClose();
	virtual void OnConnectFailure(CAWResult aReason);
	
    virtual void OnDIPCMessage(uint16_t type, 
        uint32_t xid, 
        const char *msg, 
        size_t msgsize) = 0;
    virtual CAWResult SendDIPCMessage(uint16_t type, uint32_t xid, CAWMessageBlock &msg);
    virtual CAWResult SendDIPCMessage(uint16_t type, uint32_t xid, const char *msg, size_t msgsize);
private:
    //CAWAutoPtr<UpperLibType> m_mgr;
};

#endif // !CMCONNECTORHTTPPROXYT_H

