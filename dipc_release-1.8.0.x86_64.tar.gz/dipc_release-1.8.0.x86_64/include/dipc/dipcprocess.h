/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef DIPCPROCESS_H
#define DIPCPROCESS_H
#include "CAWACEWrapper.h"
#include "json/jsoncpp.h"

class CAW_OS_EXPORT CDIPCProcess
{
public:
    CDIPCProcess();
    ~CDIPCProcess();
    CDIPCProcess(const CDIPCProcess &right);
    CDIPCProcess& operator=(const CDIPCProcess& right);
    const CAWString &GetJsonParam() const;
    const CAWString &GetProcessName() const;
    const CAWString &GetProcessPath() const;
    int GetPid() const;
    uint32_t GetBootFlag() const;
    uint32_t GetSysbootflags() const;
    uint32_t GetRestartCount() const;

    const CAWString &GetProcessoperation() const;
    const CAWString &GetOperationstate() const;


    const CAWString &GetVersion() const;
    const CAWString &GetCategory() const;
    const CAWString &GetOrigin() const;
    const CAWString &GetTitle() const;
    const CAWString &GetDesc() const;
    const CAWString &GetURL() const;
    const CAWString &GetIsApp() const;
    void SetJsonParam(const CAWString &strjson);
    void SetProcessName(const CAWString &strname);
    void SetProcessPath(const CAWString &strpath);
    void SetPid(int pid);
    void SetBootFlag(uint32_t bootflag);
    void SetSysbootflags(uint32_t bootflag);
    void SetRestartCount(uint32_t restartcount);
    void SetProcessoperation(const CAWString &opera);
    void SetOperationstate(const CAWString &state);
    void SetIsApp(const CAWString &isapp);

    void SetVersion(const CAWString &strversion);
    void SetCategory(const CAWString &strcategory);
    void SetOrigin(const CAWString &strorigin);
    void SetTitle(const CAWString &strtitl);
    void SetDesc(const CAWString &strdesc);
    void SetURL(const CAWString &strurl);
    uint16_t GetPno() const;

    void FromJson(Json::Value &jsoninfo);
    void ToJson(Json::Value &jsoninfo);
private:
    CAWString m_processname;
    CAWString m_projectpath;
    CAWString m_procfullpath;

    int      m_pid;
    uint16_t     m_pno;
    uint32_t m_bootflag;
    uint32_t m_restartcount;
    uint32_t m_sysbootflags;
    CAWString m_processoperation;
    CAWString m_operationstate;
    CAWString m_autorestart;
    CAWString m_version;
    CAWString m_category;
    CAWString m_origin;
    CAWString m_title;
    CAWString m_desc;
    CAWString m_url;
    CAWString m_jsonparam;
    CAWString m_isapp;
};


#endif//DIPCPROCESS_H

