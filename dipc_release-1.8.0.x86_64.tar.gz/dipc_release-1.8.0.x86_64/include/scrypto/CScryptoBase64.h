/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef __CSCRYPTOBASE64_H__
#define __CSCRYPTOBASE64_H__
#include "CAWDebug.h"


class CAW_OS_EXPORT CScryptoBase64
{
public:
    static CAWResult Encode(const LPBYTE lpInData,
                    DWORD dwInLen,
                    LPBYTE& lpOutData,
                    DWORD& dwOutLen);

    static CAWResult Decode(const LPBYTE lpInData,
                    DWORD dwInLen,
                    LPBYTE& lpOutData,
                    DWORD& dwOutLen);

protected:
    static DWORD GetEncodeBufSize(DWORD dwDataLen);
    static DWORD GetDecodeBufSize(DWORD dwDataLen);
    static void InitDecodeTable();

protected:
    static const BYTE s_EncodeTable[];
    static BYTE s_DecodeTable[];
    static BOOL s_bDecodeTableInit;
};

#endif//!__CSCRYPTOBASE64_H__

