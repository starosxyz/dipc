/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWPTCPSTREAMBASE_H
#define CAWPTCPSTREAMBASE_H
#include "CAWACEWrapper.h"
#include "CAWInetAddr.h"
#include "IAWPseudoTCPManager.h"
#include "CAWUtilTemplates.h"
#include "CAWMessageBlock.h"

class CAWPTCPStreamBase : public IAWPseudoTCPTransportSink
{ 
public: 
    CAWPTCPStreamBase();
    virtual ~CAWPTCPStreamBase();

    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWPseudoTCPTransport *aTrptId,
        CAWPseudoTCPTransportParameter *aPara = NULL);

    virtual void OnSend(
        IAWPseudoTCPTransport *aTrptId,
        CAWPseudoTCPTransportParameter *aPara = NULL);

    virtual void OnDisconnect(
        CAWResult aReason,
        IAWPseudoTCPTransport *aTrptId);


    virtual CAWResult SendMessage(CAWMessageBlock &aData, CAWPseudoTCPTransportParameter *pparam=NULL);

    virtual WORD16 HandleMessage(CAWMessageBlock &aData) = 0;
    virtual void OnPeerDisconnect(CAWResult aReason) = 0;
    
    virtual CAWResult SetTransportHandle(CAWAutoPtr<IAWPseudoTCPTransport> &pTransport);

    virtual CAWResult Disconnect(CAWResult reason);

    void SetSendBufferSize(WORD32 bufferSize);
    void SetRcvBufferSize(WORD32 bufferSize);

    void GetPeerIP(CAWString &ip);
    
    void GetLocalIP(CAWString &ip);
    
    WORD16 GetPeerPort();
    
    WORD16 GetLocalPort();
    
    const CAWInetAddr &GetPeerAddr() const;
    const CAWInetAddr &GetLocalAddr() const;
    
protected:
    CAWAutoPtr<IAWPseudoTCPTransport> m_pTransport;
    CAWMessageBlock *           m_pBlocks;
    CAWMessageBlock *           m_pMbSendBuf;
    WORD32                      m_dwSendBufMaxLen;
    WORD32                      m_dwRcvBufMaxLen;
    CAWInetAddr                 m_addrPeer;
    CAWInetAddr                 m_addrLocal;
};


#endif /* CAWPTCPSTREAMBASE_H */

