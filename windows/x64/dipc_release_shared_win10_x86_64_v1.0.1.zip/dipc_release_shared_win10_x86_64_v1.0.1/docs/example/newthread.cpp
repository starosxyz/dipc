
#include "dipcutils/dipcmodule.h"
using namespace dipc::utils;
DIPC_MODINIT_FUNC DIPCModule_Init_newthread()
{
	printf("DIPCModule_Init_newthread\n");
}

DIPC_MODINIT_FUNC DIPCModule_Uninit_newthread()
{
	printf("DIPCModule_Uninit_newthread-app\n");
}