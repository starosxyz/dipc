
#include "xmlengine/IXmlElementModuleFun.h"
#include "CSLModuleCreateApp.h"
#include "CSLModuleSetEnv.h"
XML_MODINIT_FUNC xmlengine_dynamic_init_setenv()
{
	printf("xmlengine_dynamic_init_setenv\n");
	return new CSLModuleSetEnv();
}

XML_MODINIT_FUNC xmlengine_dynamic_init_createapp()
{
	printf("xmlengine_dynamic_init_create-app\n");
	return new CSLModuleCreateApp();
}