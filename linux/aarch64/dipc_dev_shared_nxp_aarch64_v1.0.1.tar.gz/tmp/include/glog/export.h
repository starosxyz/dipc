
#ifndef GOOGLE_GLOG_DLL_DECL_H
#define GOOGLE_GLOG_DLL_DECL_H

#ifdef _WIN32

#if defined (_LIB) || (GLOG_STATIC_DEFINE) 
#define GOOGLE_GLOG_DLL_DECL
#define GLOG_NO_EXPORT
#else 
#if defined (_USRDLL) || (GLOG_OS_BUILD_DLL)
#define GOOGLE_GLOG_DLL_DECL __declspec(dllexport)
#else 
#define GOOGLE_GLOG_DLL_DECL __declspec(dllimport)
#endif // _USRDLL || GLOG_OS_BUILD_DLL
#endif // _LIB || GLOG_STATIC_DEFINE
#else
#if defined (GLOG_OS_BUILD_DLL)
#if __GNUC__ >= 4
#define GOOGLE_GLOG_DLL_DECL __attribute__ ((visibility("default")))
#else
#define GOOGLE_GLOG_DLL_DECL
#endif
#else
#define GOOGLE_GLOG_DLL_DECL
#endif
#  ifndef GLOG_NO_EXPORT
#    define GLOG_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif // !_WIN32

#ifndef GLOG_DEPRECATED
#  define GLOG_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef GLOG_DEPRECATED_EXPORT
#  define GLOG_DEPRECATED_EXPORT GOOGLE_GLOG_DLL_DECL GLOG_DEPRECATED
#endif

#ifndef GLOG_DEPRECATED_NO_EXPORT
#  define GLOG_DEPRECATED_NO_EXPORT GLOG_NO_EXPORT GLOG_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GLOG_NO_DEPRECATED
#    define GLOG_NO_DEPRECATED
#  endif
#endif

#endif /* GOOGLE_GLOG_DLL_DECL_H */
