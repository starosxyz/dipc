/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECTORSOCKSPROXYT_H
#define CAWCONNECTORSOCKSPROXYT_H

#include "wface/CAWConnectorTcpT.h"
#include "wface/CAWTransportTcp.h"
#include "starbase/CAWHttpUtilClasses.h"
#include "starbase/CAWMessageBlock.h"
namespace wface
{
template <class UpperType, class UpTrptType, class UpSockType>
class CAW_OS_EXPORT CAWConnectorSocksProxyT 
    : public ACmConnectorInternal
    , public IAWTransportSink 
{
public:
    typedef CAWConnectorSocksProxyT SelfType;

	CAWConnectorSocksProxyT(
			IAWReactor *aReactor, 
			UpperType &aUpper, 
			CAWHttpProxyInfo* aProxyInfo = NULL)
		: m_pReactor(aReactor)
		, m_Upper(aUpper)
		, m_TcpConnector(aReactor, *this)
		, m_pTransport(NULL)
		, m_State(STATE_IDLE)
		, m_dwSvrIP(0)
		, m_wSvrPort(0)
	{
		if (aProxyInfo)
			SetProxyInfo(aProxyInfo);
	}
	
	virtual ~CAWConnectorSocksProxyT()
	{
		Close();
	}

	void SetProxyInfo(CAWHttpProxyInfo* aProxyInfo)
	{
		CAW_ASSERTE_RETURN_VOID(aProxyInfo);

		m_pProxyInfo = aProxyInfo;
		CAW_ASSERTE(
			m_pProxyInfo->GetProxyType() == CAWHttpProxyInfo::SOCK4_PROXY || 
			m_pProxyInfo->GetProxyType() == CAWHttpProxyInfo::SOCK5_PROXY);
	}

	// interface ACmConnectorInternal
	virtual int Connect(const CAWInetAddr &aAddr, CAWInetAddr *aAddrLocal = NULL)
	{
		CAW_ASSERTE(m_State == STATE_IDLE);
		CAW_ASSERTE_RETURN(!m_pTransport, -1);
		CAW_ASSERTE_RETURN(m_pProxyInfo, -1);

		m_dwSvrIP = (sockaddr_in *)aAddr.GetPtr()->sin_addr.s_addr;
		m_wSvrPort = (sockaddr_in *)aAddr.GetPtr()->sin_port;

		CAWInetAddr addrProxy(m_pProxyInfo->GetHostName().c_str(), m_pProxyInfo->GetPort());
		return m_TcpConnector.Connect(addrProxy);
	}

	virtual int Close()
	{
		m_TcpConnector.Close();
		if (m_pTransport) {
			m_pTransport = NULL;
		}
		m_pProxyInfo = NULL;
		m_State = STATE_IDLE;
		return 0;
	}

	int OnConnectIndication(
		CAWResult aReason, 
		UpTrptType *aTrpt,
		ACmConnectorInternal *aId)
	{
		CAW_ASSERTE(m_State == STATE_IDLE);
		CAW_ASSERTE(&m_TcpConnector == aId);
		m_pTransport = aTrpt;

		if (CAW_SUCCEEDED(aReason)) {
			CAW_ASSERTE(m_pTransport);
			aReason = m_pTransport->OpenWithSink(this);
			if (CAW_SUCCEEDED(aReason))
				aReason = StartNewRequest();
		}

		if (CAW_FAILED(aReason)) {
			Close();
			m_Upper.OnConnectIndication(aReason, NULL, this);
		}
		return 0;
	}

	CAWResult StartNewRequest()
	{
		char lpBuf[128];
		DWORD dwBufLen = 0;
		if (m_State == STATE_IDLE) {
			if (m_pProxyInfo->GetProxyType() == CAWHttpProxyInfo::SOCK4_PROXY) {
				lpBuf[0] = 0x04; // SOCKS version 4
				lpBuf[1] = 0x01; // CD command code -- 1 for connect
				::memcpy(lpBuf + 2, &m_wSvrPort, sizeof(m_wSvrPort));
				::memcpy(lpBuf + 4, &m_dwSvrIP, sizeof(m_dwSvrIP));
				::memcpy(lpBuf + 8, "wbx", 3);
				lpBuf[11] = 0x00;
				dwBufLen = 12;
				m_State = STATE_CONNECT_REMOTE;
			}
			else {
				lpBuf[0] = 0x05;// SOCKS version 5
				lpBuf[1] = 0x01; // number of auth procotols we recognize auth protocols
				lpBuf[2] = 0x00; //no authentication required;
				// compliant implementations MUST implement GSSAPI
				// and SHOULD implement username/password and MAY
				// implement CHAP
				// TODO: we don't implement these
				//lpBuf[3] = 0x01; // GSSAPI
				//lpBuf[4] = 0x02; // username/password
				//lpBuf[5] = 0x03; // CHAP
				dwBufLen = lpBuf[1] + 2;
				m_State = STATE_CONNECT_PROXY;
			}
		}
		else if (m_State == STATE_CONNECT_PROXY) {
			CAW_ASSERTE(m_pProxyInfo->GetProxyType() == CAWHttpProxyInfo::SOCK5_PROXY);
			lpBuf[0] = 0x05; // SOCKS version 5
			lpBuf[1] = 0x01; // CONNECT command
			lpBuf[2] = 0x00; // obligatory reserved field (perfect for MS tampering!)
			lpBuf[3] = 0x01; // encoding of destination address (1 == IPv4)
			memcpy(lpBuf + 4, &m_dwSvrIP,sizeof(m_dwSvrIP));
			memcpy(lpBuf + 8, &m_wSvrPort, sizeof(m_wSvrPort));
			dwBufLen = 10;
			m_State = STATE_CONNECT_REMOTE;
		}
		else {
			CAW_ERROR_TRACE("CAWConnectorSocksProxyT::StartNewRequest,"
				" wrong state=" << m_State);
			CAW_ASSERTE(FALSE);
			return CAW_ERROR_UNEXPECTED;
		}

		CAWMessageBlock mbSend(
			dwBufLen, 
			lpBuf, 
			CAWMessageBlock::DONT_DELETE, 
			dwBufLen);
		CAWResult rv = m_pTransport->SendData(mbSend);
		if (CAW_FAILED(rv)) {
			CAW_ERROR_TRACE("CAWConnectorSocksProxyT::StartNewRequest,"
				" SendData() failed! len=" << dwBufLen << 
				" rv=" << rv);
		}
		return rv;
	}

	virtual void OnReceive(
		CAWMessageBlock &aData,
		IAWTransport *aTrptId,
		CAWTransportParameter *aPara = NULL)
	{
		CAW_ASSERTE(!aData.GetNext());
		LPCSTR lpBuf = aData.GetTopLevelReadPtr();
		DWORD dwBufLen = aData.GetTopLevelLength();

		if (m_State == STATE_CONNECT_PROXY) {
			CAW_ASSERTE(m_pProxyInfo->GetProxyType() == CAWHttpProxyInfo::SOCK5_PROXY);
			if (dwBufLen >= 2 && (lpBuf[0] == 0x05 && lpBuf[1] == 0x00)) {
				CAWResult rv = StartNewRequest();
				if (CAW_FAILED(rv))
					goto fail;
				return;
			}
			else {
				CAW_ERROR_TRACE("CAWConnectorSocksProxyT::OnReceive, fail1,"
					" len=" << dwBufLen <<
					" buf[0]=" << lpBuf[0] <<
					" buf[1]=" << lpBuf[1]);
				goto fail;
			}
		}
		else if (m_State == STATE_CONNECT_REMOTE) {
			if (m_pProxyInfo->GetProxyType() == CAWHttpProxyInfo::SOCK4_PROXY) {
				if (dwBufLen >= 8 && (lpBuf[0] == 0x00 && lpBuf[1] == 0x5A))
					m_State = STATE_SUCCESS;
				else {
					CAW_ERROR_TRACE("CAWConnectorSocksProxyT::OnReceive, fail2,"
						" len=" << dwBufLen <<
						" buf[0]=" << lpBuf[0] <<
						" buf[1]=" << lpBuf[1]);
					goto fail;
				}
			}
			else {
				if (dwBufLen >= 10 && (lpBuf[0] == 0x05 && lpBuf[1] == 0x00))
					m_State = STATE_SUCCESS;
				else {
					CAW_ERROR_TRACE("CAWConnectorSocksProxyT::OnReceive, fail3,"
						" len=" << dwBufLen <<
						" buf[0]=" << lpBuf[0] <<
						" buf[1]=" << lpBuf[1]);
					goto fail;
				}
			}
		}

		CAW_ASSERTE(m_State == STATE_SUCCESS);
		m_Upper.OnConnectIndication(CAW_OK, m_pTransport.ParaIn(), this);
		m_pTransport = NULL;
		return;

fail:
		Close();
		m_Upper.OnConnectIndication(CAW_ERROR_NETWORK_SOCKET_ERROR, NULL, this);
		return;
	}

	virtual void OnSend(
		IAWTransport *aTrptId,
		CAWTransportParameter *aPara = NULL)
	{
		CAW_ASSERTE(!"CAWConnectorSocksProxyT::OnSend, it shouldn't be called!");
	}

    virtual void OnDisconnect(
    CAWResult aReason,
    IAWTransport *aTrptId)
    {
        //printf("CAWConnectorSocksProxyT::OnDisconnect,this=%p\n", this);
        Close();
        if (CAW_SUCCEEDED(aReason))
        	aReason = CAW_ERROR_NETWORK_SOCKET_ERROR;
        m_Upper.OnConnectIndication(aReason, NULL, this);
    }

private:
	enum SOCKS_STATE 
	{
		STATE_IDLE,
		STATE_CONNECT_PROXY,
		STATE_CONNECT_REMOTE,
		STATE_SUCCESS,
		STATE_FAILURE
	};
	
	IAWReactor *m_pReactor;
	UpperType &m_Upper;
	CAWConnectorTcpT<SelfType, UpTrptType, UpSockType> m_TcpConnector;
	CAWAutoPtr<UpTrptType> m_pTransport;
	SOCKS_STATE m_State;
	CAWAutoPtr<CAWHttpProxyInfo> m_pProxyInfo;

	// follows are in network octet order.
	DWORD m_dwSvrIP;
	WORD  m_wSvrPort;
};
}//namespace wface
#endif // !CMCONNECTORSOCKSPROXYT_H
