/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWTRANSPORTTHREADPROXY_H
#define CAWTRANSPORTTHREADPROXY_H

#include "wface/CAWConnectionInterface.h"
#include "wface/CAWACEWrapper.h"
#include <list>
namespace wface
{
class CAW_OS_EXPORT CAWTransportThreadProxy 
    : public IAWTransport
    , public IAWTransportSink
    , public CAWReferenceControlMutilThread
    , public CAWStopFlag
    , public CAWTimerWrapperIDSink
{
public:
    CAWTransportThreadProxy(
            IAWTransport *aActual, 
            CAWThread *aThreadNetwork,
            CAWThread *aThreadUser,
            CAWConnectionManager::CType aType);

    virtual ~CAWTransportThreadProxy();

    // interface IAWReferenceControl
    virtual DWORD AddReference();
    virtual DWORD ReleaseReference();
    DWORD GetRefCount();
    virtual void OnReferenceDestory();

    // interface IAWTransport
    virtual CAWResult OpenWithSink(IAWTransportSink *aSink);
    virtual IAWTransportSink* GetSink();
    virtual CAWResult SendData(CAWMessageBlock &aData, CAWTransportParameter *aPara = NULL);
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg);
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg);
    virtual CAWResult Disconnect(CAWResult aReason);
    virtual CAW_HANDLE GetTransportHandle() const;

    // interface IAWTransportSink
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL);

    virtual void OnSend(
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL);

    virtual void OnDisconnect(
        CAWResult aReason,
        IAWTransport *aTrptId);

    virtual void OnTimer(CAWTimerWrapperID* aId);


protected:
    CAWResult Send_i(
        CAWMessageBlock *aData, 
        CAWTransportParameter* aPara);
    CAWResult SendDataInternal(CAWMessageBlock &aData, CAWTransportParameter *aPara);
protected:
    CAWAutoPtr<IAWTransport> m_pTransportActual;
    IAWTransportSink *m_pSinkActual;
    CAWThread *m_pThreadUser;
    CAWThread *m_pThreadNetwork;
    IAWReactor* m_pReactorNetwork;
    CAWConnectionManager::CType m_Type;
    CAWTimerWrapperID m_TimerReference0;

    // for send buffer, we don't need mutex becase.
    // <m_SendBuffer> and <m_bIsBufferFull> are all modified in the network thread.
    // <m_bNeedOnSend> is modified in the user thread.
    BOOL m_bNeedOnSend;
    CAWMessageBlock *m_pMbSend;
    typedef CAWMutexThread MutexType;
    MutexType m_BufferMutex;
    CAWMessageBlock* m_pMbRcv;
    MutexType m_RecvMutex;
    friend class CEventSendData;
    friend class CEventDisconnect;
    friend class CEventOnReceive;
    friend class CEventOnSend;
    friend class CEventOnDisconnect;
    friend class CEventOpenWithSink;
};

class CEventSendData : public IAWEvent
{
public:
    CEventSendData(
        CAWTransportThreadProxy *aThreadProxy,
        CAWMessageBlock &aData, 
        CAWTransportParameter *aPara);

    virtual ~CEventSendData();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWTransportThreadProxy> m_pOwnerThreadProxy;
    CAWMessageBlock *m_pMessageBlock;
    CAWTransportParameter m_TransportParameter;
    CAWTransportParameter *m_pParaTransportParameter;
};

class CAW_OS_EXPORT CEventDisconnect : public IAWEvent
{
public:
    CEventDisconnect(
        CAWTransportThreadProxy *aThreadProxy,
        CAWResult aReason);

    virtual ~CEventDisconnect();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWTransportThreadProxy> m_pOwnerThreadProxy;
    CAWResult m_Reason;
};

class CAW_OS_EXPORT CEventOpenWithSink : public IAWEvent
{
public:
    CEventOpenWithSink(CAWTransportThreadProxy* aThreadProxy);

    virtual ~CEventOpenWithSink();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWTransportThreadProxy> m_pOwnerThreadProxy;
};

class CAW_OS_EXPORT CEventOnReceive : public IAWEvent
{
public:
    CEventOnReceive(
        CAWTransportThreadProxy *aThreadProxy,
        CAWMessageBlock &aData,
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara);

    virtual ~CEventOnReceive();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWTransportThreadProxy> m_pOwnerThreadProxy;
    CAWMessageBlock *m_pData;
    IAWTransport *m_pTrptId;
    CAWTransportParameter m_TransportParameter;
    CAWTransportParameter *m_pParaTransportParameter;
};

class CAW_OS_EXPORT CEventOnSend : public IAWEvent
{
public:
    CEventOnSend(
        CAWTransportThreadProxy *aThreadProxy,
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara);

    virtual ~CEventOnSend();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWTransportThreadProxy> m_pOwnerThreadProxy;
    IAWTransport *m_pTrptId;
    CAWTransportParameter m_TransportParameter;
    CAWTransportParameter *m_pParaTransportParameter;
};

class CAW_OS_EXPORT CEventOnDisconnect : public IAWEvent
{
public:
    CEventOnDisconnect(
        CAWTransportThreadProxy *aThreadProxy,
        CAWResult aReason,
        IAWTransport *aTrptId);

    virtual ~CEventOnDisconnect();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWTransportThreadProxy> m_pOwnerThreadProxy;
    CAWResult m_Reason;
    IAWTransport *m_pTrptId;
};
}//namespace wface
#endif // !CAWTRANSPORTTHREADPROXY_H

