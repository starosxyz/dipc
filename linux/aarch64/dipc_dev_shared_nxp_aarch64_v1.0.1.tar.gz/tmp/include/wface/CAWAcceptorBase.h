/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef CAWACCEPTORBASE_H
#define CAWACCEPTORBASE_H

#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWReactorInterface.h"
#include "wface/CAWConnectionInterface.h"

using namespace starbase;
namespace wface
{
class CAW_OS_EXPORT CAWAcceptorBase : public IAWAcceptor, public CAWReferenceControlSingleThread 
{
public:
    CAWAcceptorBase(CAWThread *pThreadNetwork);
    virtual ~CAWAcceptorBase();

    // interface IAWReferenceControl
    virtual DWORD AddReference();
    virtual DWORD ReleaseReference();

    // interface IAWAcceptorConnectorId
    virtual BOOL IsConnector();

protected:
    CAWThread *m_pThreadNetwork;
    IAWReactor *m_pReactor;
    IAWReactor *m_pReactorNetwork;
    IAWAcceptorConnectorSink *m_pSink;
    DWORD m_reactortype;
};
}//namespace wface
#endif // !CAWACCEPTORBASE_H

