/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWSESSIONMANAGER_H
#define CAWSESSIONMANAGER_H
#include "starbase/CAWDefines.h"
#include "starbase/CAWSocket.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWUtilClasses.h"
#include "starbase/CAWHashMapT.h"
#include "starbase/CAWUtilTemplates.h"
#include "wface/CAWConnectionInterface.h"
using namespace starbase;
namespace wface
{
class CAW_OS_EXPORT CAWPairInetAddr
{
public:
    CAWPairInetAddr()
    {
    }

    CAWPairInetAddr(const CAWInetAddr &aSrc, const CAWInetAddr &aDst)
            : m_src(aSrc)
            , m_dst(aDst)
    {
    }

    DWORD GetHashValue() const 
    {
        // this hash function is copied from linux kernel
        // source code whose flie name is "net/ipv4/Tcp_ipv4.c".
        int h = m_src.hash() ^ m_dst.hash();
        h ^= h>>16;
        h ^= h>>8;
        return h;

    }

    bool operator == (const CAWPairInetAddr &aRight) const 
    {
        return m_src == aRight.m_src && 
                m_dst == aRight.m_dst;

    }

public:
    CAWInetAddr m_src;
    CAWInetAddr m_dst;
};

struct InetAddrHash
{
    size_t operator()(const CAWPairInetAddr &addr) const
    {
        return addr.GetHashValue();
    }
};

typedef CAWHashMapT<CAWPairInetAddr, CAWAutoPtr<IAWTransport>,InetAddrHash> IPSessionsType;


class CAW_OS_EXPORT CAWIPSessionManager
{
public:
    CAWIPSessionManager();
    CAWIPSessionManager(size_t size);
    virtual ~CAWIPSessionManager();
    CAWResult RemoveTransport(const CAWInetAddr &peeripaddr, 
        const CAWInetAddr& localipaddr);
    CAWResult AddTransport(const CAWInetAddr& peeripaddr,
        const CAWInetAddr& localipaddr, IAWTransport*aTrpt);
    IAWTransport *FindTransport(const CAWInetAddr& peeripaddr,
        const CAWInetAddr& localipaddr);
    size_t GetSize();
    void GetAll(std::list< IAWTransport *>& sessionlist);
    void ClearByLocalAddr(const CAWInetAddr& m_AddrLocol);
protected:
    IPSessionsType m_sessions;
    CAWMutexThread m_mutext;
};
}//namespace wface
#endif // !CAWSESSIONMANAGER_H

