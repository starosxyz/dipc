/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECTORTCPT_H
#define CAWCONNECTORTCPT_H

#include "starbase/CAWReactorInterface.h"
#include "starbase/CAWSocket.h"
#include "starbase/CAWObserver.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWDnsManager.h"
#include "starbase/CAWTimeValue.h"
#ifdef CAW_WIN32
#include <WinSock2.h>
#include <MSWSock.h>
#endif
namespace wface
{
template <class UpperType, class UpTrptType, class UpSockType>
class CAW_OS_EXPORT CAWConnectorTcpT 
    : public IAWEventHandler
    , public ACmConnectorInternal
    , public IAWObserver 
{
public:
    CAWConnectorTcpT(IAWReactor *aReactor, UpperType &aUpper)
        : m_pReactor(aReactor)
        , m_Upper(aUpper)
        , m_bResolving(FALSE)
        , m_reactortype(aReactor->GetReactorType())
    {
        CAW_INFO_TRACE_THIS("CAWConnectorTcpT::CAWConnectorTcpT");
    }

    virtual ~CAWConnectorTcpT()
    {
        CAW_INFO_TRACE_THIS("CAWConnectorTcpT::~CAWConnectorTcpT");
        Close();
    }

    // interface ACmConnectorInternal
    virtual int Connect(const CAWInetAddr &aAddr, CAWInetAddr *aAddrLocal = NULL)
    {
        int nRet = 0;
        const CAWInetAddr *pAddrConnect = &aAddr;
        //printf("tcp connect=%s,%d\n",aAddr.GetIpDisplayName().c_str(),aAddr.GetPort());
        if (aAddrLocal)
            m_addrLocal = *aAddrLocal;
        CAW_INFO_TRACE_THIS("CAWConnectorTcpT::Connect");

#ifdef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
        if (!aAddr.IsResolved()) 
        {
            m_addrUnResolved = aAddr;
            pAddrConnect = &m_addrUnResolved;

            CAWAutoPtr<CAWDnsRecord> pRecord;
            CAWString strHostName = m_addrUnResolved.GetHostName();
            //printf("not IsResolved ,tcp strHostName=%s\n",strHostName.c_str());
            CAWResult rv = CAWDnsManager::Instance()->AsyncResolve(
                pRecord.ParaOut(),
                strHostName,
                this);
            if (CAW_SUCCEEDED(rv)) 
            {
                //printf("CAWConnectorTcpT 1\n");
                if (pRecord.Get()==NULL)
                {
                    CAW_ERROR_TRACE_THIS("CAWConnectorTcpT::Connect, pRecord");
                    return -1;
                }
                uint32_t port=m_addrUnResolved.GetPort();
				if (aAddrLocal == NULL)
				{
					pRecord->GetFirstIPAddr(m_addrUnResolved);
				}
				else
				{
					if (aAddrLocal->get_type() == AF_INET6)
					{
						pRecord->GetIPv6Address(m_addrUnResolved);
					}
					else
					{
						pRecord->GetIPv4Address(m_addrUnResolved);
					}
				}
                m_addrUnResolved.SetPort(port);

                //printf("CAWConnectorTcpT 1,aAddr=%s,port=%d\n",aAddr.GetIpDisplayName().c_str(),aAddr.GetPort());

                //printf("CAWConnectorTcpT 1,m_addrUnResolved=%s,port=%d\n",m_addrUnResolved.GetIpDisplayName().c_str(),m_addrUnResolved.GetPort());

                if (m_bResolving) 
                {
                    CAWDnsManager::Instance()->CancelResolve(this);
                    m_bResolving = FALSE;
                }
            }
            else if (rv == CAW_ERROR_WOULD_BLOCK)
            {
                //printf("CAWConnectorTcpT 2\n");
                m_bResolving = TRUE;
                return 0;
            }
            else
                return -1;
        }
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
        //printf("CAWConnectorTcpT 3\n");
        //printf("tcp connect22222=%s,%d\n",pAddrConnect->GetIpDisplayName().c_str(),pAddrConnect->GetPort());

        m_pTransport = new UpTrptType(m_pReactor);
        if (!m_pTransport.Get())
        {
            CAW_ERROR_TRACE_THIS("CAWConnectorTcpT::Connect create UpTrptType error");
            return -1;
        }

        nRet = Connect_i(m_pTransport.Get(), *pAddrConnect);
        if (nRet == 0) 
        {
            // it rarely happens. we have to OnConnectIndication(CAW_OK) to upper layer.
            CAW_WARNING_TRACE_THIS("CAWConnectorTcpT::Connect, connect return 0.");
            nRet = m_pReactor->NotifyHandler(this, IAWEventHandler::WRITE_MASK);
        }
        else if (nRet == 1)
            nRet = 0;
        return nRet;
        }

    virtual int Close()
    {
        CAW_INFO_TRACE_THIS("CAWConnectorTcpT::Close");

        if (m_pTransport.Get()) 
        {
            m_pReactor->RemoveHandler(this, IAWEventHandler::CONNECT_MASK);
            //delete m_pTransport;
            m_pTransport = NULL;
        }
#ifdef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
        if (m_bResolving) 
        {
            CAWDnsManager::Instance()->CancelResolve(this);
            m_bResolving = FALSE;
        }
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
        return 0;
    }

    /// interface IAWEventHandler
    virtual CAW_HANDLE GetHandle() const 
    {
        CAW_ASSERTE_RETURN(m_pTransport.Get(), CAW_INVALID_HANDLE);
        return m_pTransport->GetHandle();
    }

    /// OnOutput() indicating Connect successful,
    /// OnClose() indicating Connect failed.
    //  virtual int OnInput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
    virtual int OnOutput(CAW_HANDLE aFd = CAW_INVALID_HANDLE)
    {
        CAW_INFO_TRACE_THIS("CAWConnectorTcpT::OnOutput");
        //CAW_ASSERTE(m_pTransport.Get());
        //CAW_ASSERTE(aFd == m_pTransport->GetHandle());
        //printf("CAWConnectorTcpT::OnOutput\n");
#ifdef CAW_WIN32
        ::setsockopt((CAW_SOCKET)GetHandle(), SOL_SOCKET, SO_UPDATE_CONNECT_CONTEXT, NULL, 0);
#endif
#ifdef CAW_SUPPORT_QOS
        CAWTransportBase::SetQos2Socket(m_pTransport->GetHandle());
#endif // CAW_SUPPORT_QOS

        //UpTrptType* pTrans = m_pTransport;
        CAWAutoPtr<UpTrptType> pTrans = m_pTransport;
        CAW_INFO_TRACE_THIS("CAWConnectorTcpT::OnOutput RemoveHandler mask"<< IAWEventHandler::CONNECT_MASK);
        m_pReactor->RemoveHandler(this, IAWEventHandler::CONNECT_MASK);
        m_pTransport = NULL;

        m_Upper.OnConnectIndication(CAW_OK, pTrans.ParaIn(), this);
        //m_pTransport = NULL;
        
        return 0;
    }

    virtual int OnClose(CAW_HANDLE aFd, MASK aMask)
    {
        CAW_INFO_TRACE_THIS("CAWConnectorTcpT::OnClose");
        //CAW_ASSERTE(m_pTransport);
        //CAW_ASSERTE(aFd == m_pTransport->GetHandle());
        //CAW_ASSERTE(aMask == IAWEventHandler::CONNECT_MASK);

        Close();
        m_Upper.OnConnectIndication(CAW_ERROR_NETWORK_SOCKET_ERROR, NULL, this);
        return 0;
    }

    // interface IAWObserver
    virtual void OnObserve(LPCSTR aTopic, LPVOID aData = NULL)
    {
        CAW_ASSERTE(CAWThreadManager::IsEqualCurrentThread(CAWThreadManager::TT_NETWORK));
        CAW_ASSERTE(!strcmp(aTopic, "DnsManager"));

        //printf("OnObserve\n");

        int nErr = *static_cast<int*>(aData);
        if (nErr || Connect(m_addrUnResolved, &m_addrLocal) == -1) 
        {
            Close();
            m_Upper.OnConnectIndication(
                CAW_ERROR_NETWORK_DNS_FAILURE,
                NULL, 
                this);
        }
    }

private:
    int Connect_i(UpTrptType *aTrpt, const CAWInetAddr &aAddr)
    {
        int nRet=-1;
        UpSockType &sockPeer = aTrpt->GetPeer();
        CAW_ASSERTE(sockPeer.GetHandle() == CAW_INVALID_HANDLE);
        if (m_reactortype == IAWReactor::REACTOR_TYPE_WIN32_IOCP)
        {
#ifdef CAW_WIN32
            nRet = sockPeer.WSAOpen(FALSE, m_addrLocal);
#endif
        }
        else
        {
            if (m_addrLocal == CAWInetAddr::s_InetAddrAny())
                nRet = sockPeer.Open(FALSE);
            else
                nRet = sockPeer.Open(FALSE, m_addrLocal);
        }
        if (nRet == -1) 
        {
            CAW_FATAL_TRACE_THIS("CAWConnectorTcpT::Connect_i, Open() failed!"
            " laddr=" << m_addrLocal.GetIpDisplayName() <<
            " lport=" << m_addrLocal.GetPort() << 
            " err=" << errno);
            return -1;
        }
        if (sockPeer.Enable(CAWIPCBase::NON_BLOCK) == -1) 
        {
            CAW_WARNING_TRACE_THIS("CAWConnectorTcpT::Connect_i, Enable(NON_BLOCK) failed! err=" << errno);
            return -1;
        }

        CAW_INFO_TRACE_THIS("CAWConnectorTcpT::Connect_i,"
                    " addr=" << aAddr.GetIpDisplayName() << 
                    " port=" << aAddr.GetPort() << 
                    " laddr=" << m_addrLocal.GetIpDisplayName() <<
                    " lport=" << m_addrLocal.GetPort() << 
                    " fd=" << sockPeer.GetHandle() << 
                    " aTrpt=" << aTrpt);

        /// we regiester CONNECT_MASK prior to connect() to avoid lossing OnConnect()
        CAWResult rv = m_pReactor->RegisterHandler(this, IAWEventHandler::CONNECT_MASK);
        if (CAW_FAILED(rv))
            return -1;
        if (m_reactortype == IAWReactor::REACTOR_TYPE_WIN32_IOCP)
        {
#ifdef CAW_WIN32
            IOCP_IO_CONTEXT* pconnectIoContext = (IOCP_IO_CONTEXT*)this->GetInputOverlapped();
            if (pconnectIoContext->m_sock == (CAW_SOCKET)sockPeer.GetHandle())
            {
                pconnectIoContext->m_ioType = IOType::IOConnect;
                nRet = sockPeer.Connect(aAddr, &pconnectIoContext->m_ol);
                ::setsockopt(pconnectIoContext->m_sock, SOL_SOCKET, SO_UPDATE_CONNECT_CONTEXT, NULL, 0);
            }
#endif
        }
        else
        {
            nRet = sockPeer.Connect(aAddr);
        }
        CAW_INFO_TRACE_THIS("CAWConnectorTcp::Connect_i Connect nRet=" << nRet);
        if (nRet == 0)
        {
            /*ok*/
            CAW_INFO_TRACE_THIS("CAWConnectorTcp::Connect_i, connect() ok!"
                " addr=" << aAddr.GetIpDisplayName() <<
                " port=" << aAddr.GetPort() <<
                " err=" << errno <<
                " ewouldblock=" << EWOULDBLOCK);
        }
        else if (nRet == 1)
        {
            CAW_INFO_TRACE_THIS("CAWConnectorTcp::Connect_i, connect() EWOULDBLOCK!"
                " addr=" << aAddr.GetIpDisplayName() <<
                " port=" << aAddr.GetPort() <<
                " err=" << errno <<
                " ewouldblock=" << EWOULDBLOCK);
        }
#if 0
        else if (nRet == 2)
        {
            CAW_INFO_TRACE_THIS("CAWConnectorTcp::Connect_i, connect() try again!"
                " addr=" << aAddr.GetIpDisplayName() <<
                " port=" << aAddr.GetPort() <<
                " err=" << errno <<
                " ewouldblock=" << EWOULDBLOCK);
        }
#endif
        else
        {
            CAW_ERROR_TRACE_THIS("CAWConnectorTcp::Connect_i, connect() failed!"
                " addr=" << aAddr.GetIpDisplayName() <<
                " port=" << aAddr.GetPort() <<
                " err=" << errno <<
                " ewouldblock=" << EWOULDBLOCK);
            return -1;
        }
        return nRet;
    }

    IAWReactor *m_pReactor;
    UpperType &m_Upper;
    CAWAutoPtr<UpTrptType> m_pTransport;
    CAWInetAddr m_addrUnResolved;
    CAWInetAddr m_addrLocal;
    BOOL m_bResolving;
    DWORD m_reactortype;
};
}//namespace wface
#endif // !CAWCONNECTORTCPT_H

