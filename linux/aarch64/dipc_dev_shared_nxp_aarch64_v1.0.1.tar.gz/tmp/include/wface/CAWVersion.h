/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAW_VERSION_H
#define CAW_VERSION_H
#define CAW_MAJOR_VERSION 1
#define CAW_MINOR_VERSION 0
#define CAW_BETA_VERSION 1
#endif

