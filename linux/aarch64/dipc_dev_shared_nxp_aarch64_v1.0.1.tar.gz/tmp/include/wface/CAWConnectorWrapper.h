/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECTORWRAPPER_H
#define CAWCONNECTORWRAPPER_H

#include "wface/CAWConnectionInterface.h"
#include "starbase/CAWReactorInterface.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWTimeValue.h"
using namespace starbase;
namespace wface
{
class CAW_OS_EXPORT CAWConnectorWrapper 
    : public IAWConnector
    , public IAWTimerHandler
    , public CAWReferenceControlSingleThread
    {
public:
    CAWConnectorWrapper(CAWThread *pNetworkThread);
    virtual ~CAWConnectorWrapper();

    // interface IAWReferenceControl
    virtual DWORD AddReference();
    virtual DWORD ReleaseReference();

    virtual CAWResult Init(CAWConnectionManager::CType aType);

    virtual int OnConnectIndication(
            CAWResult aReason, 
            IAWTransport *aTrpt,
            ACmConnectorInternal *aId);

    // interface IAWAcceptorConnectorId
    virtual BOOL IsConnector();

    // interface IAWConnector
    virtual void AsycConnect(
            IAWAcceptorConnectorSink* aSink,
            const CAWInetAddr& aAddrPeer, 
            CAWTimeValue* aTimeout = NULL,
            CAWInetAddr *aAddrLocal = NULL);

    virtual void CancelConnect();

protected:
    // interface IAWTimerHandler
    virtual void OnTimeout(const CAWTimeValue &aCurTime, LPVOID aArg);

    void Close_i();

protected:
    IAWReactor *m_pReactor;
    IAWAcceptorConnectorSink *m_pSink;
    ACmConnectorInternal *m_pConnector;
    CAWTimeValue m_defaulttimeout;
    BOOL m_bClosed;
};
}//namespace wface
#endif // !CAWCONNECTORWRAPPER_H

