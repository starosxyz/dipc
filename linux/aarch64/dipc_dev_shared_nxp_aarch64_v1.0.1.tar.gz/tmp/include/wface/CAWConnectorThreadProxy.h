/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECORTHREADPROXY_H
#define CAWCONNECORTHREADPROXY_H

#include "wface/CAWConnectionInterface.h"
#include "starbase/CAWThreadManager.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWTimeValue.h"
#include "starbase/CAWUtilClasses.h"
#include "CAWAcceptorConnectorSinkThreadProxy.h"
namespace wface
{
class CAW_OS_EXPORT CAWConnectorThreadProxy 
	: public IAWConnector
	, public CAWAcceptorConnectorSinkThreadProxyT<CAWConnectorThreadProxy>
	, public CAWReferenceControlMutilThread
	, public CAWStopFlag
{
public:
	CAWConnectorThreadProxy(IConnectionInterface* pconnection,
		CAWConnectionManager::CType aType,
		CAWThread *aThreadNetwork = NULL,
		CAWThread *aThreadUser = NULL);
	
	virtual ~CAWConnectorThreadProxy();

	// interface IAWReferenceControl
	virtual DWORD AddReference();
	virtual DWORD ReleaseReference();
	virtual void OnReferenceDestory();

	// interface IAWAcceptorConnectorId
	virtual BOOL IsConnector();

	// interface IAWConnector
	virtual void AsycConnect(
		IAWAcceptorConnectorSink *aSink,
		const CAWInetAddr &aAddrPeer,
		CAWTimeValue *aTimeout = NULL,
		CAWInetAddr *aAddrLocal = NULL);

	virtual void CancelConnect();

	IAWAcceptorConnectorId* GetActualAcceptorConnectorId()
	{
		return m_pConActual.Get();
	}

	// we have to overlaod this function we want to ResetSink.
	void SetStopFlag();

private:
	IConnectionInterface* m_pconnection;
	CAWThread *m_pThreadUser;
	CAWThread *m_pThreadNetwork;
	IAWReactor* m_pReactorNetwork;
	CAWAutoPtr<IAWConnector> m_pConActual;
	CAWConnectionManager::CType m_Type;

	friend class CEventAsycConnect;
	friend class CEventCancelConnect;
	friend class CAWAcceptorConnectorSinkThreadProxyT<CAWConnectorThreadProxy>;
	friend class CEventOnConnectIndication<CAWConnectorThreadProxy>;
};

	class CEventAsycConnect : public IAWEvent
	{
	public:
		CEventAsycConnect(
			CAWConnectorThreadProxy *aConnectorThreadProxy,
			IAWAcceptorConnectorSink *aSink, 
			const CAWInetAddr &aAddrPeer, 
			CAWTimeValue *aTimeout,
			CAWInetAddr *aAddrLocal);

		virtual ~CEventAsycConnect();

		virtual CAWResult OnEventFire();

	private:
		CAWAutoPtr<CAWConnectorThreadProxy> m_pOwnerThreadProxy;
		IAWAcceptorConnectorSink *m_pSink;
		CAWInetAddr m_addrPeer;
		CAWTimeValue m_tvTimeout;
		CAWTimeValue *m_pParaTimeout;
		CAWInetAddr *m_pParaAddrLocal;
		CAWInetAddr m_addrLocal;
	};

	class CEventCancelConnect : public IAWEvent
	{
	public:
		CEventCancelConnect(CAWConnectorThreadProxy *aConnectorThreadProxy);

		virtual ~CEventCancelConnect();

		virtual CAWResult OnEventFire();

	private:
		CAWAutoPtr<CAWConnectorThreadProxy> m_pOwnerThreadProxy;
	};
}//namespace wface
#endif // !CAWCONNECORTHREADPROXY_H

