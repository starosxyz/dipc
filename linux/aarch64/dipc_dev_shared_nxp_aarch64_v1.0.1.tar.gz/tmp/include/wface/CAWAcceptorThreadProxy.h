/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWACCEPTORTHREADPROXY_H
#define CAWACCEPTORTHREADPROXY_H

#include "starbase/CAWReferenceControl.h"
#include "wface/CAWConnectionInterface.h"
#include "CAWAcceptorConnectorSinkThreadProxy.h"
namespace wface
{
class CAW_OS_EXPORT CAWAcceptorThreadProxy
    : public IAWAcceptor
    , public CAWReferenceControlMutilThread 
    , public CAWAcceptorConnectorSinkThreadProxyT<CAWAcceptorThreadProxy>
    , public CAWStopFlag
{
public:
    CAWAcceptorThreadProxy(IConnectionInterface *pconnection,
		CAWConnectionManager::CType aType,
		CAWThread *aThreadNetwork = NULL,
		CAWThread *aThreadUser = NULL);
    virtual ~CAWAcceptorThreadProxy();

    // interface IAWReferenceControl
    virtual DWORD AddReference();
    virtual DWORD ReleaseReference();
    virtual void OnReferenceDestory();

    // interface IAWAcceptorConnectorId
    virtual BOOL IsConnector();

    // interface IAWAcceptor
    virtual CAWResult StartListen(IAWAcceptorConnectorSink *aSink,
    const CAWInetAddr &aAddrListen,CAWTimeValue *aTimeDelay=NULL);

    virtual CAWResult StopListen(CAWResult aReason);

    IAWAcceptorConnectorId* GetActualAcceptorConnectorId()
    {
        return m_pAcceptorActual.Get();
    }

    // we have to overlaod this function because class 
    // CAWAcceptorConnectorSinkThreadProxyT<CAWAcceptorBase> will invoke it.
    void SetStopFlag() { }

private:
	IConnectionInterface *m_pconnection;
    CAWThread *m_pThreadUser;
    CAWThread *m_pThreadNetwork;
    IAWReactor* m_pReactorNetwork;
    CAWAutoPtr<IAWAcceptor> m_pAcceptorActual;
    CAWConnectionManager::CType m_Type;
    CAWTimeValue m_timeout;
    friend class CEventStartListen;
    friend class CEventStopListen;
    friend class CAWAcceptorConnectorSinkThreadProxyT<CAWAcceptorThreadProxy>;
    friend class CEventOnConnectIndication<CAWAcceptorThreadProxy>;
};

class CAW_OS_EXPORT CEventStartListen : public IAWEvent
{
public:
    CEventStartListen(CAWAcceptorThreadProxy *aThreadProxy, 
                            IAWAcceptorConnectorSink *aSink, 
                            const CAWInetAddr &aAddrListen,
                            CAWTimeValue &tvTimeout);
    virtual ~CEventStartListen();
    virtual CAWResult OnEventFire();
private:
    CAWAutoPtr<CAWAcceptorThreadProxy> m_pOwnerThreadProxy;
    IAWAcceptorConnectorSink *m_pSink;
    CAWInetAddr m_addrListen;
    CAWTimeValue m_aTimeDelay;
};

class CAW_OS_EXPORT CEventStopListen : public IAWEvent
{
public:
    CEventStopListen(CAWAcceptorThreadProxy *aConnectorThreadProxy,CAWResult aReason);
    virtual ~CEventStopListen();
    virtual CAWResult OnEventFire();
private:
    CAWAutoPtr<CAWAcceptorThreadProxy> m_pOwnerThreadProxy;
    CAWResult m_Reason;
};

}//namespace wface
#endif // !CAWACCEPTORTHREADPROXY_H

