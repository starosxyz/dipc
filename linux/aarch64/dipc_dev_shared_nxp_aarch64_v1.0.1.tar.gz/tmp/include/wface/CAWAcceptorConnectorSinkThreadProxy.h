/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWACCEPTORCONNECTORSINKTHREADPROXY_H
#define CAWACCEPTORCONNECTORSINKTHREADPROXY_H

#include "wface/CAWTransportThreadProxy.h"

namespace wface
{
#define CAW_DISABLE_EMBEDED_CLASS 1

template <class ThreadProxyType>
class CAW_OS_EXPORT CEventOnConnectIndication : public IAWEvent
{
public:
    CEventOnConnectIndication(ThreadProxyType *aConnectorThreadProxy,
        CAWResult aReason,
        IAWTransport *aTrpt,
        IAWAcceptorConnectorId *aRequestId)
        : m_pOwnerThreadProxy(aConnectorThreadProxy)
        , m_Reason(aReason)
        , m_pTrpt(aTrpt)
        , m_pRequestId(aRequestId)
    {
        CAW_ASSERTE(m_pOwnerThreadProxy);
        CAW_INFO_TRACE_THIS("CEventOnConnectIndication::CEventOnConnectIndication");
    }

    virtual ~CEventOnConnectIndication()
    {
        CAW_INFO_TRACE_THIS("CEventOnConnectIndication::~CEventOnConnectIndication");
    }

    virtual CAWResult OnEventFire()
    {
        CAW_INFO_TRACE_THIS("CEventOnConnectIndication::OnEventFire");
        CAW_ASSERTE(CAWThreadManager::IsEqualCurrentThread(m_pOwnerThreadProxy->m_pThreadUser->GetThreadId()));
        if (m_pOwnerThreadProxy->IsFlagStopped()) {
            CAW_WARNING_TRACE_THIS("CAWAcceptorConnectorSinkThreadProxyT::"
                "CEventOnConnectIndication::OnEventFire, stopped."
                " m_pOwnerThreadProxy=" << m_pOwnerThreadProxy.Get());
            if (m_pTrpt)
                m_pTrpt->Disconnect(CAW_ERROR_NOT_INITIALIZED);
            return CAW_OK;
        }

        // SetStopFlag() will ResetSink to NULL, store it before.
        IAWAcceptorConnectorSink* pSink = m_pOwnerThreadProxy->m_pSinkActual;
        CAW_ASSERTE(pSink);

        /// Stop connector to avoid it CannelConnect again.
        /// It should do nothing to the acceptor.
        m_pOwnerThreadProxy->SetStopFlag();

        if (pSink) {
            pSink->OnConnectIndication(
                        m_Reason, 
                        m_pTrpt.ParaIn(), 
                        m_pRequestId);
            return CAW_OK;
        }
        else
            return CAW_ERROR_NULL_POINTER;
    }

private:
    CAWAutoPtr<ThreadProxyType> m_pOwnerThreadProxy;
    CAWResult m_Reason;
    CAWAutoPtr<IAWTransport> m_pTrpt;
    IAWAcceptorConnectorId *m_pRequestId;
};

template <class ThreadProxyType>
class CAW_OS_EXPORT CAWAcceptorConnectorSinkThreadProxyT
    : public IAWAcceptorConnectorSink
{
public:
    CAWAcceptorConnectorSinkThreadProxyT(ThreadProxyType *pThreadProxy)
        : m_pSinkActual(NULL)
        , m_pThreadProxy(pThreadProxy)
    {
        CAW_ASSERTE(m_pThreadProxy);
        CAW_INFO_TRACE_THIS("CAWAcceptorConnectorSinkThreadProxyT::CAWAcceptorConnectorSinkThreadProxyT");
    }

    virtual ~CAWAcceptorConnectorSinkThreadProxyT()
    {
        CAW_INFO_TRACE_THIS("CAWAcceptorConnectorSinkThreadProxyT::~CAWAcceptorConnectorSinkThreadProxyT");
    }

    void ResetSink(IAWAcceptorConnectorSink *aSink)
    {
        CAW_ASSERTE(CAWThreadManager::IsEqualCurrentThread(m_pThreadProxy->m_pThreadUser->GetThreadId()));
        m_pSinkActual = aSink;
    }

    // interface IAWAcceptorConnectorSink
    virtual void OnConnectIndication(
                            CAWResult aReason,
                            IAWTransport *aTrpt,
                            IAWAcceptorConnectorId *aRequestId)
    {
        CAW_ASSERTE(aRequestId == m_pThreadProxy->GetActualAcceptorConnectorId());
        CAW_ASSERTE(CAWThreadManager::IsEqualCurrentThread(m_pThreadProxy->m_pThreadNetwork->GetThreadId()));
        CAW_INFO_TRACE_THIS("CAWAcceptorConnectorSinkThreadProxyT::OnConnectIndication");

        CAWTransportThreadProxy* pTransportThreadProxy = NULL;
        if (CAW_SUCCEEDED(aReason)) {
            pTransportThreadProxy = new CAWTransportThreadProxy(
                aTrpt,
                m_pThreadProxy->m_pThreadNetwork,
                m_pThreadProxy->m_pThreadUser,
                m_pThreadProxy->m_Type);
            if (!pTransportThreadProxy)
                aReason = CAW_ERROR_OUT_OF_MEMORY;
            else
                //aReason = CAW_OK;
                aReason = aTrpt->OpenWithSink(pTransportThreadProxy);

            if (CAW_FAILED(aReason)) {
                delete pTransportThreadProxy;
                pTransportThreadProxy = NULL;

                if (!m_pThreadProxy->IsConnector()) {
                    CAW_WARNING_TRACE("CAWAcceptorConnectorSinkThreadProxyT::OnConnectIndication,"
                        " It's acceptor, don't callback.");
                    return;
                }
            }
        }

        CEventOnConnectIndication<ThreadProxyType> *pEvent = new CEventOnConnectIndication<ThreadProxyType>(
                                                                                m_pThreadProxy, 
                                                                                aReason, 
                                                                                pTransportThreadProxy, 
                                                                                m_pThreadProxy);
        if (pEvent)
        {
            m_pThreadProxy->m_pThreadUser->GetEventQueue()->PostEvent(pEvent);
        }
    }

protected:
    IAWAcceptorConnectorSink *m_pSinkActual;
    ThreadProxyType *m_pThreadProxy;
};
}//namespace wface
#endif // !CAWACCEPTORCONNECTORSINKTHREADPROXY_H

