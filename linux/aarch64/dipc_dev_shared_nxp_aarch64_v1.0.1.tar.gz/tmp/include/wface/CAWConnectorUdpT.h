/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECTORUDPT_H
#define CAWCONNECTORUDPT_H

#include "starbase/CAWReactorInterface.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWObserver.h"
#include "starbase/CAWDnsManager.h"
#include "starbase/CAWTimeValue.h"
using namespace starbase;
namespace wface
{
template <class UpperType, class UpTrptType, class UpSockType>
class CAW_OS_EXPORT CAWConnectorUdpT 
	: public IAWEventHandler
	, public ACmConnectorInternal
	, public IAWTimerHandler
	, public IAWObserver 
{
public:
	CAWConnectorUdpT(IAWReactor *aReactor, UpperType &aUpper)
		: m_pReactor(aReactor)
		, m_Upper(aUpper)
		, m_pTransport(NULL)
		, m_bResolving(FALSE)
		, m_reactortype(aReactor->GetReactorType())
	{
	}
	
	virtual ~CAWConnectorUdpT()
	{
		Close();
	}

	// interface ACmConnectorInternal
	virtual int Connect(const CAWInetAddr &aAddr, CAWInetAddr *aAddrLocal = NULL)
	{
		const CAWInetAddr *pAddrConnect = &aAddr;
		if (aAddrLocal && aAddrLocal != &m_addrLocal)
			m_addrLocal = *aAddrLocal;

#ifdef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
		if (!aAddr.IsResolved()) {
			m_addrUnResolved = aAddr;
			pAddrConnect = &m_addrUnResolved;

			CAWAutoPtr<CAWDnsRecord> pRecord;
			CAWString strHostName = m_addrUnResolved.GetHostName();
			CAWResult rv = CAWDnsManager::Instance()->AsyncResolve(
				pRecord.ParaOut(),
				strHostName,
				this);
			if (CAW_SUCCEEDED(rv)) {
                uint32_t port=m_addrUnResolved.GetPort();
				if (aAddrLocal == NULL)
				{
					pRecord->GetFirstIPAddr(m_addrUnResolved);
				}
				else
				{
					if (aAddrLocal->get_type() == AF_INET6)
					{
						pRecord->GetIPv6Address(m_addrUnResolved);
					}
					else
					{
						pRecord->GetIPv4Address(m_addrUnResolved);
					}
				}
                m_addrUnResolved.SetPort(port);

				if (m_bResolving) {
					CAWDnsManager::Instance()->CancelResolve(this);
					m_bResolving = FALSE;
				}
			}
			else if (rv == CAW_ERROR_WOULD_BLOCK) {
				m_bResolving = TRUE;
				return 0;
			}
			else
				return -1;
		}
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME

		int nRet = 0;
		CAW_ASSERTE_RETURN(!m_pTransport, -1);
		m_pTransport = new UpTrptType(m_pReactor,*pAddrConnect);
		if (!m_pTransport) 
			return -1;

		UpSockType &sockPeer = m_pTransport->GetPeer();
		CAW_ASSERTE(sockPeer.GetHandle() == CAW_INVALID_HANDLE);
		if (m_reactortype == IAWReactor::REACTOR_TYPE_WIN32_IOCP)
		{
#ifdef CAW_WIN32
			nRet = sockPeer.WSAOpen(m_addrLocal);
#endif
		}
		else
		{
			nRet = sockPeer.Open(m_addrLocal);
		}
		if (nRet == -1) {
			CAW_ERROR_TRACE("CAWConnectorUdpT::Connect, m_Socket.Open() failed!"
				" addr=" << m_addrLocal.GetIpDisplayName() <<
				" port=" << m_addrLocal.GetPort() <<
				"err=" << errno);
			return -1;
		}
        DWORD dwRcv = 65535, dwSnd = 65535;
        int nOption;

        nOption = sockPeer.SetOption(SOL_SOCKET, SO_SNDBUF,  &dwSnd, sizeof(DWORD));
        CAW_ASSERTE(nOption == 0);
        nOption = sockPeer.SetOption(SOL_SOCKET, SO_RCVBUF,  &dwRcv, sizeof(DWORD));
        CAW_ASSERTE(nOption == 0);

		nRet = ::connect(
			(CAW_SOCKET)sockPeer.GetHandle(), 
			reinterpret_cast<const struct sockaddr *>(pAddrConnect->GetPtr()), 
			pAddrConnect->GetSize());
		if (nRet == -1) {
			CAW_WARNING_TRACE("CAWConnectorUdpT::Connect, connect() failed!"
				" addr=" << pAddrConnect->GetIpDisplayName() <<
				" port=" << pAddrConnect->GetPort() <<
				" err=" << errno);
			return -1;
		}
		else {
			CAW_INFO_TRACE("CAWConnectorUdpT::Connect, connect() successful."
				" addr=" << pAddrConnect->GetIpDisplayName() <<
				" port=" << pAddrConnect->GetPort() <<
				" fd=" << sockPeer.GetHandle());

#ifdef CAW_SUPPORT_QOS
			CAWTransportBase::SetQos2Socket(sockPeer.GetHandle());
#endif // CAW_SUPPORT_QOS

			// can't use NotifyHandler(WRITE_MASK) due to not RegiesterHandler.
#ifdef CAW_DEBUG
			CAWResult rv = 
#endif // CAW_DEBUG
				m_pReactor->ScheduleTimer(this, NULL, CAWTimeValue::s_tvZero(), 1);
			CAW_ASSERTE(CAW_SUCCEEDED(rv));
			return 0;
		}
	}

	virtual int Close()
	{
		if (m_pReactor)
			m_pReactor->CancelTimer(this);
		if (m_pTransport) {
			delete m_pTransport;
			m_pTransport = NULL;
		}
#ifdef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
		if (m_bResolving) {
			CAWDnsManager::Instance()->CancelResolve(this);
			m_bResolving = FALSE;
		}
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
		return 0;
	}

    /// interface IAWEventHandler
    virtual CAW_HANDLE GetHandle() const 
    {
        CAW_ASSERTE_RETURN(m_pTransport, CAW_INVALID_HANDLE);
        return m_pTransport->GetHandle();
    }

    virtual int OnClose(CAW_HANDLE aFd, MASK aMask)
    {
        CAW_ERROR_TRACE("CAWConnectorUdpT::OnClose, it's impossible!"
            " aFd=" << aFd <<
            " aMask=" << aMask);
        return 0;
    }

    void OnTimeout(const CAWTimeValue &aCurTime, LPVOID aArg)
    {
        CAW_UNUSED_ARG(aCurTime);
        CAW_UNUSED_ARG(aArg);
        CAWAutoPtr<UpTrptType> pTrans = m_pTransport;
        m_pTransport = NULL;
        m_Upper.OnConnectIndication(CAW_OK, pTrans.ParaIn(), this);
    }

    void OnObserve(LPCSTR aTopic, LPVOID aData)
    {
        CAW_ASSERTE(CAWThreadManager::IsEqualCurrentThread(CAWThreadManager::TT_NETWORK));
        CAW_ASSERTE(!strcmp(aTopic, "DnsManager"));

        int nErr = *static_cast<int*>(aData);
        if (nErr || Connect(m_addrUnResolved, &m_addrLocal) == -1) {
            Close();
            m_Upper.OnConnectIndication(
                CAW_ERROR_NETWORK_DNS_FAILURE,
                NULL, 
                this);
        }
    }

private:
    IAWReactor *m_pReactor;
    UpperType &m_Upper;
    UpTrptType *m_pTransport;
    CAWInetAddr m_addrUnResolved;
    CAWInetAddr m_addrLocal;
    BOOL m_bResolving;
	DWORD m_reactortype;
};
}//namespace wface
#endif // !CAWCONNECTORUDPT_H
