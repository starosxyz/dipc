/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAW_DETECT_CONNECTOR_H
#define CAW_DETECT_CONNECTOR_H

#include "wface/CAWConnectionInterface.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWTimeValue.h"
#include <list>
namespace wface
{
#define TOP_PRIORITY					1
#define CONNECTOR_STATUS_UNCONNECTED	0x0001
#define CONNECTOR_STATUS_CONNECTED		0x0002

///////////////////////////////////////////
//class CAWDetectionConnector
///////////////////////////////////////////
class CAW_OS_EXPORT CAWDetectionConnector : 
	public IAWDetectionConnector, 
	public CAWReferenceControlSingleThreadTimerDelete
{
	class CConnectorItem;
	friend class CConnectorItem;
	typedef std::list<CAWAutoPtr<CConnectorItem> >::iterator iter_type;
public:
	/// add connection one by one, and the prior has high priority.
	virtual CAWResult AddConnection(
		CAWConnectionManager::CType Type, 
		const CAWInetAddr &aAddrPeer,
		CAWTimeValue *aTimeDelay);
	
	/// Start connecting at the same time in <aTimeout>,
	/// If low priority connection connected, wait high priority connection in <aTimeDelay>.
	virtual void StartDetectionConnect(
		IAWAcceptorConnectorSink *aSink,
		CAWTimeValue *aTimeout = NULL);
//		CAWTimeValue *aTimeDelay = NULL);
	
	virtual void AsycConnect(
		IAWAcceptorConnectorSink *aSink,
		const CAWInetAddr &aAddrPeer, 
		CAWTimeValue *aTimeout = NULL,
		CAWInetAddr *aAddrLocal = NULL);
	
	virtual void CancelConnect();

	virtual BOOL IsConnector();
protected:
	// Cancel all Connect except pExclude.
	virtual void CancelConnect(CConnectorItem* pExclude);
public:
	CAWDetectionConnector();
	virtual ~CAWDetectionConnector();
public:	
	virtual DWORD AddReference()
	{
		return CAWReferenceControlSingleThreadTimerDelete::AddReference();
	};
	
	virtual DWORD ReleaseReference()
	{
		return CAWReferenceControlSingleThreadTimerDelete::ReleaseReference();
	};
private:
	
	//Inner class, items of m_conn_list
	class CConnectorItem : 
		public IAWAcceptorConnectorSink, 
		public CAWReferenceControlSingleThread,
		public CAWTimerWrapperIDSink
	{
		friend class CAWDetectionConnector;
	public:
		CConnectorItem(
			IAWConnector *pIAWConnector,
			CAWConnectionManager::CType aType, 
			WORD wPriority, 
			CAWInetAddr aAddrPeer, 
			CAWDetectionConnector* pOuterClass,
			CAWTimeValue* aTimeDelay);

		~CConnectorItem();

		void AsycConnect(CAWTimeValue *aTimeout = NULL);
	public:
		void IsAllFailed(CAWResult aReason);

		virtual void OnConnectIndication(
			CAWResult aReason,
			IAWTransport *aTrpt,
			IAWAcceptorConnectorId *aRequestId);
		
		void OnTimer(CAWTimerWrapperID* aId);
	public:	
		virtual DWORD AddReference()
		{
			return CAWReferenceControlSingleThread::AddReference();
		};
		
		virtual DWORD ReleaseReference()
		{
			return CAWReferenceControlSingleThread::ReleaseReference();
		};
		
		WORD GetStatus()
		{
			return m_wStatus;
		}

		void SetStatus(WORD wStatus)
		{
			m_wStatus = wStatus;
		}

		void SetAddrPeer(const CAWInetAddr &aAddr)
		{
			m_aAddrPeer = aAddr;
		}

	private:
		CAWAutoPtr<IAWConnector> m_pConnector;
		CAWResult m_aReason;									//Reason from TP Layer
		CAWAutoPtr<IAWTransport> m_pITransport;			//Transport from TP layer
		CAWConnectionManager::CType m_aType;
		WORD m_wPriority;
		CAWInetAddr m_aAddrPeer;
		CAWDetectionConnector* m_pOuterClass;
		
		CAWTimerWrapperID m_Timer;	

		WORD m_wStatus;
		
		CAWTimeValue* m_TimeDelay;
	};

public:
//	void SetTimeDelay(const CAWTimeValue &aTime)
//	{
//		m_TimeDelay = aTime;
//	}
		
private:
	WORD m_wPriority;
	BOOL m_bGetHighestPriority;								//Get the highest priority connection
	std::list<CAWAutoPtr<CConnectorItem> > m_conn_list;
	IAWAcceptorConnectorSink *m_aSink;						//Connector Sink from Upper layer
//	CAWTimeValue m_TimeDelay;

	CAWAutoPtr<IAWConnector> m_pChampionConnector;		//Final champion connector
	size_t m_dwConnFailedCnt;								//How many conneciton failed
	size_t m_dwConnAddCnt;									//how many connection added
};
}//namespace wface
#endif	//CAW_DETECT_CONNECTOR_H
