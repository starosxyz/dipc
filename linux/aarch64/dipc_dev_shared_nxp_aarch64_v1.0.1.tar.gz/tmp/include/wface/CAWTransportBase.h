/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWTRANSPORTBASE_H
#define CAWTRANSPORTBASE_H

#include "starbase/CAWReactorInterface.h"
#include "wface/CAWConnectionInterface.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWTimerWrapperID.h"
#include "starbase/CAWTimeValue.h"
#include "starbase/CAWUtilTemplates.h"
namespace wface
{
class CAW_OS_EXPORT CAWTransportBase 
    : public IAWEventHandler
    , public IAWTransport
    , public CAWReferenceControlSingleThreadTimerDelete
{
public:
    CAWTransportBase(IAWReactor *pReactor);
    virtual ~CAWTransportBase();

    // interface IAWReferenceControl
    virtual DWORD AddReference();
    virtual DWORD ReleaseReference();

    // interface IAWTransport
    virtual CAWResult OpenWithSink(IAWTransportSink *aSink);
    virtual IAWTransportSink* GetSink();
    virtual CAWResult Disconnect(CAWResult aReason);

    // interface IAWEventHandler
    virtual int OnClose(CAW_HANDLE aFd, MASK aMask);

#ifdef CAW_SUPPORT_QOS
    CAWResult SetQos2Socket(CAW_HANDLE aSocket);
#endif // CAW_SUPPORT_QOS

    CAWResult SetTos2Socket(CAWSocketBase &aSocket, LPVOID aArg);

protected:
    // template method for open() and close()
    virtual CAWResult Open_t() = 0;
    virtual CAWResult Close_t(CAWResult aReason) = 0;
    virtual CAWResult Disconnect_t(CAWResult aReason) = 0;
    IAWTransportSink *m_pSink;
    IAWReactor *m_pReactor;
};
}//namespace wface
#endif // !CAWTRANSPORTBASE_H
