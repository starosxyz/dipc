/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWSESSIONMANAGERT_H
#define CAWSESSIONMANAGERT_H
#include "wface/CAWIPSessionManager.h"
using namespace starbase;
namespace wface
{
template <class SessionType>
class CAW_OS_EXPORT CAWIPSessionManagerT
{
public:
	typedef CAWHashMapT<CAWPairInetAddr, CAWAutoPtr<SessionType>, InetAddrHash> IPHashMap;
	CAWIPSessionManagerT()
	{
	}
	CAWIPSessionManagerT(size_t size)
		:m_sessions(size)
	{
	}
    virtual ~CAWIPSessionManagerT()
	{

	}
    CAWResult RemoveTransport(const CAWInetAddr &peeripaddr, 
        const CAWInetAddr& localipaddr)
	{
		CAWMutexGuardT<CAWMutexThread> cs(m_mutext);
		CAWPairInetAddr addrPair(peeripaddr, localipaddr);
		typename IPHashMap::iterator iter;
		iter = m_sessions.find(addrPair);
		if (iter == m_sessions.end()) {
			return CAW_ERROR_FAILURE;
		}
		m_sessions.erase(addrPair);
		return CAW_OK;
	}
    CAWResult AddTransport(const CAWInetAddr& peeripaddr,
        const CAWInetAddr& localipaddr, SessionType* aTrpt)
	{
		CAWMutexGuardT<CAWMutexThread> cs(m_mutext);
		CAWPairInetAddr addrPair(peeripaddr, localipaddr);
		CAWAutoPtr<SessionType> temp(aTrpt);
		typename IPHashMap::value_type nodeNew(addrPair, temp);
		m_sessions.insert(nodeNew);
		return CAW_OK;
	}
    SessionType *FindTransport(const CAWInetAddr& peeripaddr,
        const CAWInetAddr& localipaddr)
	{
		CAWMutexGuardT<CAWMutexThread> cs(m_mutext);
		CAWPairInetAddr addrPair(peeripaddr, localipaddr);
		typename IPHashMap::iterator iter = m_sessions.find(addrPair);
		if (iter == m_sessions.end()) {
			return NULL;
		}
		else {
			return (*iter).second.Get();
		}
	}
    size_t GetSize()
	{
		CAWMutexGuardT<CAWMutexThread> cs(m_mutext);
		return m_sessions.size();
	}
    void GetAll(std::list< SessionType *>& sessionlist)
	{
		CAWMutexGuardT<CAWMutexThread> cs(m_mutext);
		typename IPHashMap::iterator iter = m_sessions.begin();
		while (iter != m_sessions.end()) {
			sessionlist.push_back((*iter).second.Get());
			iter++;
		}
	}
    void ClearByLocalAddr(const CAWInetAddr& m_AddrLocol)
	{
		CAWMutexGuardT<CAWMutexThread> cs(m_mutext);
		typename IPHashMap::iterator iter = m_sessions.begin();
		while (iter != m_sessions.end()) {
			const CAWPairInetAddr& pairAddr = (*iter).first;
			if (pairAddr.m_dst == m_AddrLocol) {
				iter = m_sessions.erase(iter);
			}
			else
			{
				iter++;
			}
		}
	}
protected:
	IPHashMap m_sessions;
    CAWMutexThread m_mutext;
};
}//namespace wface
#endif // !CAWSESSIONMANAGERT_H

