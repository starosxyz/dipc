/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECTORTCP_H
#define CAWCONNECTORTCP_H

#include "starbase/CAWReactorInterface.h"
#include "starbase/CAWSocket.h"
#include "starbase/CAWObserver.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWDnsManager.h"
#include "starbase/CAWTimeValue.h"
#include "wface/CAWConnectorBase.h"
#ifdef CAW_WIN32
#include <WinSock2.h>
#include <MSWSock.h>
#endif
namespace wface
{

class CAW_OS_EXPORT CAWConnectorTcp : public CAWConnectorBase
{
public:
    CAWConnectorTcp(CAWThread* pThreadNetwork);
    virtual ~CAWConnectorTcp();

    // iterface IAWEventHandler
    virtual CAW_HANDLE GetHandle() const;
    virtual int OnOutput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
public:
    virtual int Connect_i(const CAWInetAddr& aAddr);
    virtual int Close_i();
    virtual void SetSocketHandler(CAW_HANDLE aFd);
    virtual void OnCreateTransport(IAWTransport*& pnewtransport);
    virtual void OnConnectedTransport(IAWTransport* pnewtransport);
protected:
    CAWSocketTcp m_Socket;
    CAWInetAddr m_aAddrListen;
};
}//namespace wface
#endif // !CAWCONNECTORTCP_H

