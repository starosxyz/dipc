/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef CAWWFACE_H
#define CAWWFACE_H
#include "starbase/CAWStarBase.h"
#include "wface/CAWConnectionInterface.h"
#include "wface/CAWErrorNetwork.h"
#endif//CAWWFACE_H