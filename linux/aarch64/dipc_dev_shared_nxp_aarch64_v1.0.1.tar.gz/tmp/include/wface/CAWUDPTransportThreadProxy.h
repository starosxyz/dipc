/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWUDPTRANSPORTTHREADPROXY_H
#define CAWUDPTRANSPORTTHREADPROXY_H

#include "wface/CAWConnectionInterface.h"
#include "wface/CAWACEWrapper.h"
#include "starbase/CAWSocket.h"
#include <list>
namespace wface
{
class CAW_OS_EXPORT CAWUDPTransportThreadProxy 
    : public IAWUDPTransport
    , public IAWUDPTransportSink
    , public CAWReferenceControlMutilThread
{
public:
	CAWUDPTransportThreadProxy(IAWUDPTransportSink *aActual, 
            CAWThread *aThreadNetwork,
            CAWThread *aThreadUser);

    virtual ~CAWUDPTransportThreadProxy();
	virtual CAWResult Open(const CAWInetAddr &localaddr);
	virtual CAWResult Close();
    // interface IAWReferenceControl
    virtual DWORD AddReference();
    virtual DWORD ReleaseReference();

	virtual CAWResult SendData(CAWMessageBlock &aData, const CAWInetAddr &aAddrPeer);
    virtual CAWResult SendData(const char* pkt, size_t pktsize, const CAWInetAddr& aAddrPeer);
	virtual void OnReceive(CAWMessageBlock &aData, const CAWInetAddr &aAddrPeer);

	virtual CAWSocketUdp* GetSocket();
private:

    CAWAutoPtr<IAWUDPTransport> m_pTransportActual;
    IAWUDPTransportSink *m_pSinkActual;
    CAWThread *m_pThreadUser;
    CAWThread *m_pThreadNetwork;
	CAWInetAddr m_peeraddr;
    friend class CUDPEventSendData;
    friend class CUDPEventOnReceive;
    friend class CUDPEventOpen;
};

class CAW_OS_EXPORT CUDPEventSendData : public IAWEvent
{
public:
	CUDPEventSendData(
        CAWUDPTransportThreadProxy *aThreadProxy,
        CAWMessageBlock &aData, 
        const CAWInetAddr &peeraddr);

    virtual ~CUDPEventSendData();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWUDPTransportThreadProxy> m_pOwnerThreadProxy;
    CAWMessageBlock *m_pMessageBlock;
	CAWInetAddr m_peeraddr;
};
class CAW_OS_EXPORT CUDPEventOpen : public IAWEvent
{
public:
    CUDPEventOpen(
        CAWUDPTransportThreadProxy* aThreadProxy,
        const CAWInetAddr& peeraddr);

    virtual ~CUDPEventOpen();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWUDPTransportThreadProxy> m_pOwnerThreadProxy;
    CAWInetAddr m_peeraddr;
};
class CAW_OS_EXPORT CUDPEventOnReceive : public IAWEvent
{
public:
	CUDPEventOnReceive(
        CAWUDPTransportThreadProxy *aThreadProxy,
        CAWMessageBlock &aData,
		const CAWInetAddr &peeraddr);

    virtual ~CUDPEventOnReceive();

    virtual CAWResult OnEventFire();

private:
    CAWAutoPtr<CAWUDPTransportThreadProxy> m_pOwnerThreadProxy;
    CAWMessageBlock *m_pData;
	CAWInetAddr m_peeraddr;
};
}//namespace wface
#endif // !CAWUDPTRANSPORTTHREADPROXY_H

