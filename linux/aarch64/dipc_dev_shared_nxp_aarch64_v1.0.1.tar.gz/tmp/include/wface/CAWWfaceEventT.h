#ifndef CAWWFAEEVENT_T_H
#define CAWWFAEEVENT_T_H
#include "wface/CAWConnectionInterface.h"
namespace wface
{
template <class ThreadProxyType>
class CAW_OS_EXPORT CProxyOpenWithSinkEvent : public IAWEvent
{
public:
    CProxyOpenWithSinkEvent(ThreadProxyType* aThreadProxy)
		:m_pOwnerThreadProxy(aThreadProxy)
	{
	}

    virtual ~CProxyOpenWithSinkEvent(){}

    virtual CAWResult OnEventFire()
	{
		CAWResult rv = CAW_OK;
		CAW_INFO_TRACE_THIS("CProxyOpenWithSinkEvent");
		CAW_ASSERTE(CAWThreadManager::IsEqualCurrentThread(m_pOwnerThreadProxy->m_pThreadNetwork->GetThreadId()));
		if (m_pOwnerThreadProxy->m_pTransportActual) {
			rv = m_pOwnerThreadProxy->m_pTransportActual->OpenWithSink(m_pOwnerThreadProxy.Get());
		}
		return rv;
	}

private:
    CAWAutoPtr<ThreadProxyType> m_pOwnerThreadProxy;
};
}//namespace wface
#endif//CAWWFAEEVENT_T_H
