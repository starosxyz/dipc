/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWACCEPTORUDP_H
#define CAWACCEPTORUDP_H

#include "wface/CAWAcceptorBase.h"
#include "starbase/CAWSocket.h"
#include "starbase/CAWInetAddr.h"
#include "wface/CAWTransportUdp.h"
#include "starbase/CAWUtilClasses.h"
#ifdef CAW_WIN32
#include "starbase/CAWIOCPInterface.h"
#endif
#include "wface/CAWIPSessionManager.h"
namespace wface
{

typedef CAWIPSessionManager UdpTransportsType;


class CAW_OS_EXPORT CAWAcceptorUdp 
    : public CAWAcceptorBase
    , public IAWEventHandler 
    , public CAWStopFlag
{
public:
    CAWAcceptorUdp(CAWThread *pNetworkThread);
    virtual ~CAWAcceptorUdp();

    // interface IAWAcceptor
    virtual CAWResult StartListen(IAWAcceptorConnectorSink *aSink,const CAWInetAddr &aAddrListen,CAWTimeValue *aTimeDelay=NULL);
    virtual CAWResult StopListen(CAWResult aReason);

    // iterface IAWEventHandler
    virtual CAW_HANDLE GetHandle() const ;
    virtual int OnInput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
    virtual int OnOutput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
    virtual int OnClose(CAW_HANDLE aFd, MASK aMask);
    int OnEpollInput(CAW_HANDLE fd);
    int OnKEventInput(CAW_HANDLE fd);
    CAWResult RemoveTransport(const CAWInetAddr &aAddr, CAWTransportUdp *aTrpt);
    CAWResult AddTransport(const CAWInetAddr &aAddr, CAWTransportUdp *aTrpt);
    CAWTransportUdp *FindTransport(const CAWInetAddr &addrRecv);
#ifdef CAW_WIN32
    bool PostRecvFrom(IOCP_IO_CONTEXT* pIoContext);
    int OnIOCPInput(CAW_HANDLE fd);
#endif
protected:
    CAWSocketUdp m_Socket;
    CAWInetAddr m_AddrLocol;
};
}//namespace wface
#endif // !CAWACCEPTORUDP_H

