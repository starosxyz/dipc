/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECTORBASE_H
#define CAWCONNECTORBASE_H

#include "starbase/CAWReactorInterface.h"
#include "starbase/CAWSocket.h"
#include "starbase/CAWObserver.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWDnsManager.h"
#include "starbase/CAWTimeValue.h"
#ifdef CAW_WIN32
#include <WinSock2.h>
#include <MSWSock.h>
#endif
namespace wface
{
class CAW_OS_EXPORT CAWConnectorBase
    : public IAWConnector
    , public CAWReferenceControlSingleThread
    , public IAWObserver
    , public IAWTimerHandler
    , public IAWEventHandler
{
public:
    CAWConnectorBase(CAWThread* pThreadNetwork);
    virtual ~CAWConnectorBase();
    virtual DWORD AddReference();
    virtual DWORD ReleaseReference();
    virtual void AsycConnect(
        IAWAcceptorConnectorSink* aSink,
        const CAWInetAddr& aAddrPeer,
        CAWTimeValue* aTimeout = NULL,
        CAWInetAddr* aAddrLocal = NULL);

    virtual void CancelConnect();
    // interface IAWAcceptorConnectorId
    virtual BOOL IsConnector();
    virtual int OnClose(CAW_HANDLE aFd, MASK aMask);
    void CancelTimer();
private:
    virtual int Connect_i(const CAWInetAddr& aAddr) = 0;
    virtual int Close_i() = 0;
    virtual void SetSocketHandler(CAW_HANDLE aFd) = 0;
    virtual void OnCreateTransport(IAWTransport*& pnewtransport) = 0;
    virtual void OnConnectedTransport(IAWTransport* pnewtransport) = 0;
public:
    virtual void OnObserve(LPCSTR aTopic, LPVOID aData = NULL);
    /*timerout*/
    virtual void OnTimeout(const CAWTimeValue& aCurTime, LPVOID aArg);
protected:
    int Connect(const CAWInetAddr& aAddr, CAWInetAddr* aAddrLocal = NULL);
    CAWResult ConnectedSignal();
    CAWResult DisConnectedSignal();
protected:
    CAWThread* m_pThreadNetwork;
    IAWReactor* m_pReactor;
    IAWReactor* m_pReactorNetwork;
    IAWAcceptorConnectorSink* m_pSink;
    CAWInetAddr m_addrUnResolved;
    CAWInetAddr m_addrLocal;
    CAWInetAddr m_aPeerAddr;
    BOOL m_bResolving;
    DWORD m_reactortype;
    CAWTimeValue m_defaulttimeout;
    CAWAutoPtr<IAWTransport> m_pTrans;
};
}//namespace wface
#endif // !CAWCONNECTORBASE_H

