/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWTRANSPORTTCP_H
#define CAWTRANSPORTTCP_H
#include "wface/CAWACEWrapper.h"
#include "starbase/CAWSocket.h"
#include "wface/CAWTransportBase.h"
#include "starbase/CAWAtomic32.h"
#ifdef CAW_WIN32
#include "starbase/CAWIOCPInterface.h"
#include <WinSock2.h>
#include <MSWSock.h>
#endif
namespace wface
{
class CAW_OS_EXPORT CAWTransportTcp : public CAWTransportBase, public CAWTimerWrapperIDSink
{
public:
    CAWTransportTcp(IAWReactor *pReactor);
    virtual ~CAWTransportTcp();

    // interface IAWEventHandler
    virtual CAW_HANDLE GetHandle() const ;
    virtual int OnInput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
    virtual int OnOutput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);

    // interface IAWTransport
    virtual CAWResult SendData(CAWMessageBlock &aData, CAWTransportParameter *aPara = NULL);

    CAWResult SendDataHight(CAWMessageBlock &aData, CAWTransportParameter *aPara);

    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg);
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg);
    int OnEpollInput(CAW_HANDLE afd);
    int OnKeventInput(CAW_HANDLE afd);
    CAWSocketTcp& GetPeer();
    virtual CAW_HANDLE GetTransportHandle() const;

protected:
    virtual CAWResult Open_t();
    virtual CAWResult Close_t(CAWResult aReason);
    virtual CAWResult Disconnect_t(CAWResult aReason);

    int Recv_i(LPSTR aBuf, DWORD aLen, BOOL aNeedTimerRereceive = TRUE);
    int Send_i(LPCSTR aBuf, DWORD aLen);

    virtual void OnTimer(CAWTimerWrapperID *aId);
#ifdef CAW_WIN32
    int OnIOCPInput(CAW_HANDLE aFd);
    bool PostRecv(IOCP_IO_CONTEXT* pIoContext);
    CAWResult IOCPSendData(CAWMessageBlock& aData, CAWTransportParameter* aPara);
    bool IsConnected(CAW_HANDLE aFd);
#endif
protected:
    typedef CAWMutexThread MutexType;
    //MutexType m_mutex;
    CAWSocketTcp m_SocketTcp;
    CAWTimerWrapperID m_TimerRereceive;
    CAWAtomic32 m_bNeedOnSend;
    CAWInetAddr m_LocalAddr;
    CAWInetAddr m_RemoteAddr;
    DWORD m_reactortype;
};
}//namespace wface
#endif // !CAWTRANSPORTTCP_H

