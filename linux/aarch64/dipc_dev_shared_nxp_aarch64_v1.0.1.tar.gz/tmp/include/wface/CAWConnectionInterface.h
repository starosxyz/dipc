/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECTIONINTERFACE_H
#define CAWCONNECTIONINTERFACE_H

#include "starbase/CAWDefines.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWUtilTemplates.h"
#include "starbase/CAWMutex.h"
#include "starbase/CAWSocket.h"
#include "starbase/CAWMessageBlock.h"
using namespace starbase;
namespace wface
{
class IAWAcceptorConnectorSink;
class IAWTransportSink;
  class IAWTransport;
  class IAWRawTransport;
  class IAWAcceptorConnectorId;
    class IAWConnector;
      class IAWDetectionConnector;
    class IAWAcceptor;

class IAWUDPTransportSink;
class IAWUDPTransport;

typedef struct NetworkThreadPoolParam_
{
    DWORD reactortype;
    uint32_t reactorcount;
    uint32_t reactorperthreads;
} NetworkThreadPoolParam;

class CAW_OS_EXPORT IConnectionInterface
{
public:
    typedef DWORD CType;
    enum { 
        // connection type
        CTYPE_NONE = 0,
        CTYPE_TCP = (1 << 0),
        CTYPE_UDP = (1 << 1),
        CTYPE_TYPE_MASK = 0xFFFF
    };

    enum CPriority
    {
        CPRIORITY_HIGH,
        CPRIORITY_ABOVE_NORMAL,
        CPRIORITY_NORMAL,
        CPRIORITY_BELOW_NORMAL,
        CPRIORITY_LOW,
    };

    enum 
    {
        UDP_SEND_MAX_LEN = 16 * 1024,
        UDP_ONE_PACKET_MAX_LEN = 1514-14-20-8,
    };

    virtual ~IConnectionInterface(){}
    virtual CAWResult GetNetworkThreadPoolDefaultParam(NetworkThreadPoolParam* param) = 0;
    virtual CAWResult Init(NetworkThreadPoolParam* param)=0;
    virtual CAWResult CreateConnectionClient(CType aType, 
                        IAWConnector *&aConClient) = 0;

    virtual CAWResult CreateConnectionServer(CType aType,
        IAWAcceptor *&aAcceptor) = 0;

    virtual CAWResult CreateConnectionClientWithThread(CType aType, 
                        IAWConnector *&aConClient, 
                        CAWThread *pNetworkThread) = 0;
    
    virtual CAWResult CreateConnectionServerWithThread(CType aType,
                    IAWAcceptor *&aAcceptor, 
                    CAWThread *pNetworkThread) = 0;
    virtual int GetReactorType() = 0;
    virtual CAWThread* GetNetworkThread() = 0;
public:
    virtual CAWResult CreateTCPClient(CAWAutoPtr<IAWConnector>& aConClient) = 0;

    virtual CAWResult CreateTCPServer(CAWAutoPtr < IAWAcceptor>& aAcceptor) = 0;

    virtual CAWResult CreateTCPClientWithThread(CAWAutoPtr<IAWConnector>& aConClient,
        CAWThread* pNetworkThread) = 0;

    virtual CAWResult CreateTCPServerWithThread(CAWAutoPtr < IAWAcceptor>& aAcceptor,
        CAWThread* pNetworkThread) = 0;

public:
    virtual CAWResult CreateUDPClient(CAWAutoPtr<IAWConnector>& aConClient) = 0;

    virtual CAWResult CreateUDPServer(CAWAutoPtr < IAWAcceptor>& aAcceptor) = 0;

    virtual CAWResult CreateUDPClientWithThread(CAWAutoPtr<IAWConnector>& aConClient,
        CAWThread* pNetworkThread) = 0;

    virtual CAWResult CreateUDPServerWithThread(CAWAutoPtr < IAWAcceptor>& aAcceptor,
        CAWThread* pNetworkThread) = 0;
};

class CAW_OS_EXPORT CAWConnectionManager : public IConnectionInterface
{
public:
    static CAWConnectionManager* Instance();
    virtual ~CAWConnectionManager(){}
    virtual CAWResult CreateUDPTransport(IAWUDPTransportSink *psink, 
		IAWUDPTransport *&transport) = 0;
};

class CAW_OS_EXPORT CAWTransportParameter
{
public:
    CAWTransportParameter(CAWConnectionManager::CPriority aPriority = CAWConnectionManager::CPRIORITY_NORMAL)
        : m_dwHaveSent(0)
        , m_Priority(aPriority)
    {
    }

    size_t m_dwHaveSent;
    CAWConnectionManager::CPriority m_Priority;
};

class CAW_OS_EXPORT IAWAcceptorConnectorSink 
{
public:
    virtual void OnConnectIndication(
        CAWResult aReason,
        IAWTransport *aTrpt,
        IAWAcceptorConnectorId *aRequestId) = 0;

protected:
    virtual ~IAWAcceptorConnectorSink() {}
};
class CAW_OS_EXPORT IAWUDPTransportSink 
{
public:
    virtual void OnReceive(CAWMessageBlock &aData,const CAWInetAddr &aAddrPeer) = 0;
protected:
    virtual ~IAWUDPTransportSink() {}
};
class CAW_OS_EXPORT IAWUDPTransport : public IAWReferenceControl
{
public:
	virtual CAWResult Open(const CAWInetAddr &localaddr) = 0;
	virtual CAWResult Close() = 0;
    virtual CAWResult SendData(CAWMessageBlock &aData,const CAWInetAddr &aAddrPeer) = 0;
    virtual CAWResult SendData(const char* pkt, size_t pktsize, const CAWInetAddr& aAddrPeer) = 0;
	virtual CAWSocketUdp* GetSocket() = 0;
protected:
    virtual ~IAWUDPTransport() {}
};

class CAW_OS_EXPORT IAWTransportSink 
{
public:
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL) = 0;

    virtual void OnSend(
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL) = 0;

    virtual void OnDisconnect(
    CAWResult aReason,
    IAWTransport *aTrptId) = 0;

protected:
    virtual ~IAWTransportSink() {}
};

class CAW_OS_EXPORT IAWTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWTransportSink *aSink) = 0;

    virtual IAWTransportSink* GetSink() = 0;
    virtual CAWResult SendData(CAWMessageBlock &aData, CAWTransportParameter *aPara = NULL) = 0;
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult Disconnect(CAWResult aReason) = 0;
    virtual CAW_HANDLE GetTransportHandle() const = 0;
protected:
    virtual ~IAWTransport() {}
};

class CAW_OS_EXPORT IAWRawTransportSink 
{
public:
    virtual void OnReceive(const char *data, size_t size) = 0;

   protected:
       virtual ~IAWRawTransportSink() {}
};

class CAW_OS_EXPORT IAWRawTransport : public IAWReferenceControl
{

public:
    virtual CAWResult Open(WORD16 type, IAWRawTransportSink *aSink) = 0;

    virtual IAWRawTransportSink* GetSink() = 0;

    virtual CAWResult Bind(CAWInetAddr &aAddrLocal,CAWInetAddr &aAddrPeer) = 0;

    virtual CAWResult SendData(const char *data, size_t size) = 0;

    virtual CAWResult Close(CAWResult aReason) = 0;
protected:
    virtual ~IAWRawTransport() {}
};


class CAW_OS_EXPORT IAWAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWConnector : public IAWAcceptorConnectorId
{
public:
    virtual void AsycConnect(
        IAWAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrPeer, 
        CAWTimeValue *aTimeout = NULL,
        CAWInetAddr *aAddrLocal = NULL) = 0;

    virtual void CancelConnect() = 0;

protected:
    virtual ~IAWConnector() {}
};

class CAW_OS_EXPORT IAWDetectionConnector : public IAWConnector
{
public:
    virtual CAWResult AddConnection(
        CAWConnectionManager::CType Type, 
        const CAWInetAddr &aAddrPeer,
        CAWTimeValue *aTimeDelay = NULL) = 0;
    virtual void StartDetectionConnect(IAWAcceptorConnectorSink *aSink,CAWTimeValue *aTimeout = NULL ) =0;

protected:
    virtual ~IAWDetectionConnector() {}
};

class CAW_OS_EXPORT IAWAcceptor : public IAWAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IAWAcceptorConnectorSink *aSink,
            const CAWInetAddr &aAddrListen,
            CAWTimeValue *aTimeDelay = NULL) = 0;
    virtual CAWResult StopListen(CAWResult aReason) = 0;
protected:
    virtual ~IAWAcceptor() {}
};
}//namespace wface
#endif // CAWCONNECTIONINTERFACE_H

