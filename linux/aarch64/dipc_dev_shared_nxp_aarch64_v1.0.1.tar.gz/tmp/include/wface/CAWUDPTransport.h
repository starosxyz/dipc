/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWUDPTRANSPORT_H
#define CAWUDPTRANSPORT_H
#include "wface/CAWACEWrapper.h"
#include "starbase/CAWReactorInterface.h"
#include "wface/CAWConnectionInterface.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWTimerWrapperID.h"
#include "starbase/CAWTimeValue.h"
#include "starbase/CAWUtilTemplates.h"
#include "starbase/CAWSocket.h"
#ifdef CAW_WIN32
#include "starbase/CAWIOCPInterface.h"
#endif
namespace wface
{
class CAW_OS_EXPORT CAWUDPTransport
	: public IAWUDPTransport
	, public IAWEventHandler
	, public CAWReferenceControlMutilThreadTimerDelete
{
public:
	CAWUDPTransport(IAWUDPTransportSink *psink, CAWThread *pThreadNetwork);
	virtual ~CAWUDPTransport();
	virtual DWORD AddReference();
	virtual DWORD ReleaseReference();
	// interface IAWAcceptor
	virtual CAWResult Open(const CAWInetAddr &localaddr);
	virtual CAWResult Close();
	virtual CAWResult SendData(CAWMessageBlock &aData, const CAWInetAddr &aAddrPeer);
	virtual CAWResult SendData(const char* pkt, size_t pktsize, const CAWInetAddr& aAddrPeer);
	// iterface IAWEventHandler
	virtual CAW_HANDLE GetHandle() const;
	virtual CAWSocketUdp *GetSocket();
	virtual int OnInput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
	virtual int OnClose(CAW_HANDLE aFd, MASK aMask);
	virtual int OnOutput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
	int OnEpollInput(CAW_HANDLE aFd);
	int OnKEventInput(CAW_HANDLE aFd);
protected:
#ifdef CAW_WIN32
	int OnIOCPInput(CAW_HANDLE aFd);
	bool PostRecvFrom(IOCP_IO_CONTEXT* pIoContext);
	CAWResult SendIOCPData(CAWMessageBlock& aData, const CAWInetAddr& aAddrPeer);
#endif
private:
	CAWSocketUdp m_Socket;
	CAWInetAddr m_aAddrListen;
	IAWUDPTransportSink *m_psink;
	CAWThread *m_pThreadNetwork;
	IAWReactor* m_pReactorNetwork;
	DWORD m_ReactorType;
};
}//namespace wface
#endif // !CAWUDPTRANSPORT_H
