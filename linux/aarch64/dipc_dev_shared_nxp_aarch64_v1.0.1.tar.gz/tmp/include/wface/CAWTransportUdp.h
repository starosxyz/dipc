/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWTRANSPORTUDP_H
#define CAWTRANSPORTUDP_H

#include "wface/CAWTransportBase.h"
#include "starbase/CAWSocket.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWMessageBlock.h"
#include "starbase/CAWReferenceControl.h"
#ifdef CAW_WIN32
#include "starbase/CAWIOCPInterface.h"
#include <WinSock2.h>
#include <MSWSock.h>
#endif
namespace wface
{
class CAWAcceptorUdp;

class CAW_OS_EXPORT CAWTransportUdp : public CAWTransportBase  
{
public:
    CAWTransportUdp(IAWReactor *pReactor, const CAWInetAddr &aAddrSend, CAWAcceptorUdp *pAcceptor = NULL);
    virtual ~CAWTransportUdp();
    virtual CAWResult OpenWithSink(IAWTransportSink* aSink);
    // interface IAWEventHandler
    virtual CAW_HANDLE GetHandle() const ;
    virtual int OnInput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
    virtual int OnOutput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
    // interface IAWTransport
    virtual CAWResult SendData(CAWMessageBlock &aData, CAWTransportParameter *aPara = NULL);
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg);
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg);

    CAWSocketUdp& GetPeer();

    void OnReceiveCallback(LPSTR aData, DWORD aLen);
    void OnReceiveCallback(CAWMessageBlock& msg);
    virtual CAW_HANDLE GetTransportHandle() const;
#ifdef CAW_WIN32
    CAWResult SendIOCPData(CAWMessageBlock& aData, CAWTransportParameter* aPara);
    bool PostRecvFrom(IOCP_IO_CONTEXT* pIoContext);
    int OnIOCPInput(CAW_HANDLE aFd);
#endif
protected:
    virtual CAWResult Open_t();
    virtual CAWResult Close_t(CAWResult aReason);
    virtual CAWResult Disconnect_t(CAWResult aReason);
    int OnEpollInput(CAW_HANDLE aFd);
    int OnKEventInput(CAW_HANDLE aFd);
protected:
    CAWSocketUdp m_SocketUdp;
    CAWAutoPtr<CAWAcceptorUdp> m_pAcceptor;
    CAWInetAddr m_AddrSend;
    DWORD m_reactortype;
    BOOL m_bNeedOnSend;
    typedef CAWMutexThread MutexType;
    //MutexType m_BufferMutex;
    std::list<CAWMessageBlock*> m_bufferlist;
};
}//namespace wface
#endif // !CAWTRANSPORTUDP_H

