/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWCONNECTORUDP_H
#define CAWCONNECTORUDP_H
#include "wface/CAWConnectorBase.h"
#include "starbase/CAWReactorInterface.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWObserver.h"
#include "starbase/CAWDnsManager.h"
#include "starbase/CAWTimeValue.h"
using namespace starbase;
namespace wface
{
    class CAW_OS_EXPORT CAWConnectorUdp:public CAWConnectorBase
    {
    public:
        CAWConnectorUdp(CAWThread* pThreadNetwork);
        virtual ~CAWConnectorUdp();

        // iterface IAWEventHandler
        virtual CAW_HANDLE GetHandle() const;
        virtual int OnOutput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
    public:
        virtual int Connect_i(const CAWInetAddr& aAddr);
        virtual int Close_i();
        virtual void SetSocketHandler(CAW_HANDLE aFd);
        virtual void OnCreateTransport(IAWTransport*& pnewtransport);
        virtual void OnConnectedTransport(IAWTransport* pnewtransport);
    protected:
        CAWSocketUdp m_Socket;
    };
}//namespace wface
#endif // !CAWCONNECTORUDP_H
