/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAWACCEPTORTCP_H
#define CAWACCEPTORTCP_H

#include "wface/CAWAcceptorBase.h"
#include "starbase/CAWSocket.h"
#ifdef CAW_WIN32
#include "starbase/CAWIOCPInterface.h"
#endif
namespace wface
{
class CAW_OS_EXPORT CAWAcceptorTcp 
        : public CAWAcceptorBase
        , public IAWEventHandler
{
public:
    CAWAcceptorTcp(CAWThread *pThreadNetwork);
    virtual ~CAWAcceptorTcp();

    // interface IAWAcceptor
    virtual CAWResult StartListen(IAWAcceptorConnectorSink *aSink,
            const CAWInetAddr &aAddrListen,
            CAWTimeValue *aTimeDelay = NULL);
    virtual CAWResult StopListen(CAWResult aReason);

    // iterface IAWEventHandler
    virtual CAW_HANDLE GetHandle() const ;
    virtual int OnInput(CAW_HANDLE aFd = CAW_INVALID_HANDLE);
    virtual int OnClose(CAW_HANDLE aFd, MASK aMask);
protected:
    int OnEpollInput(CAW_HANDLE aFd);
#ifdef CAW_WIN32
    int OnIOCPAcceptor(CAW_HANDLE aFd);
    bool PostAcceptEx(SOCKET socListen, IOCP_IO_CONTEXT* pAcceptIoContext);
#endif
protected:
    CAWSocketTcp m_Socket;
    CAWInetAddr m_aAddrListen;
};
}//namespace wface
#endif // !CAWACCEPTORTCP_H

