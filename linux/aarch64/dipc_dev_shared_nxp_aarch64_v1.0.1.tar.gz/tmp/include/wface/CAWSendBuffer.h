/***********************************************************************
 * Copyright (C) 2013-2014, Nanjing WFN Technology Co., Ltd  
**********************************************************************/
#ifndef CAWSENDBUFFER_H
#define CAWSENDBUFFER_H
#include "starbase/CAWInetAddr.h"
#include "starbase/CAWSocket.h"
#include "starbase/CAWByteSwap.h"
namespace wface
{
struct CAWSendItem
{
    CAWSendItem(CAWMessageBlock* aMb, const CAWInetAddr& peerip)
        :m_pMbSend(aMb), m_peerip(peerip)
    {

    }
    ~CAWSendItem()
    {
        if (m_pMbSend)
            m_pMbSend->DestroyChained();
    }
    CAWMessageBlock* m_pMbSend;
    CAWInetAddr m_peerip;
};
typedef std::list<CAWSendItem> SendBufferType;

}/*namespace wface*/
#endif // CAWSENDBUFFER_H

