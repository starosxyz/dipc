/***********************************************************************
 * Copyright (C) 2016-2018, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef __IIPSTACK_H__
#define __IIPSTACK_H__
#include "starbase/CAWDefines.h"
#include "starbase/CAWUtilTemplates.h"
#include "starbase/CAWMutex.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWString.h"
#include <stdint.h>
using namespace starbase;
namespace ipstack
{
class CAW_OS_EXPORT IIPStackLowLevel
{
public:
    virtual ~IIPStackLowLevel(){}
    virtual CAWResult IPStackLowLevelOutput(const char *pkt, size_t pktsize, uint8_t portid)=0;
};

class CAW_OS_EXPORT IIPStack:public IAWReferenceControl
{
public:
    virtual ~IIPStack(){}
    virtual CAWResult OpenWithLowLevel(IIPStackLowLevel *plowlevel)=0;
    virtual void IPStackInput(const char *pkt, size_t pktsize)=0;
    virtual CAWResult SetIPAddress(const CAWString &ipaddr,
                                    const CAWString &ipmask,
                                    const CAWString &gateway)=0;

    virtual CAWResult RemoveIPAddress()=0;

    
    virtual CAWResult SetIP(const CAWString &ipaddr)=0;
    virtual CAWResult SetIPNetMask(const CAWString &ipnetmask)=0;
    virtual CAWResult SetGateway(const CAWString &ipgw)=0;

    virtual CAWResult GetIPAddress(CAWString &ipaddr,
                                    CAWString &ipmask,
                                    CAWString &gateway)=0;

    virtual CAWResult RemoveIPv6Addr(int8_t addr_idx, const CAWInetAddr &ipv6addr)=0;    
    virtual CAWResult AddIPv6Addr(int8_t addr_idx, const CAWInetAddr &ipv6addr)=0;  
    virtual CAWResult SetMacAddress(char mac[6])=0;
    virtual CAWResult GetMacAddress(char mac[6])=0;
    virtual CAWResult Up()=0;
    virtual CAWResult Down()=0;
    virtual uint32_t GetPortId()=0;
    virtual CAWString GetPortName()=0;
    virtual void StartDHCP()=0;
    virtual void StopDHCP()=0;
    virtual CAWResult SetDefaultNet()=0;
    virtual uint32_t GetTXCount()=0;
    virtual uint32_t GetRXCount()=0;
    virtual void EnablePromiscuous()=0;
    virtual void DisablePromiscuous()=0;
};

class CAW_OS_EXPORT IIPStackManager
{
public:
    static IIPStackManager* Instance();
    virtual ~IIPStackManager() {}
    virtual CAWResult Init() = 0;
    virtual void InitNetworkConnect() = 0;
    virtual BOOL IsInit() = 0;
    virtual IIPStack* CreateIPStack(const CAWString& strifname) = 0;
    virtual IIPStack* CreateIPStack(const CAWString& ifname,
        const CAWString& ipaddr,
        const CAWString& ipmask,
        const CAWString& gateway,
        char macaddr[6]) = 0;
    virtual void DestroyIPStack(IIPStack* pstack) = 0;
    virtual IIPStack* GetIPStack(const CAWString& strifname) = 0;

protected:
};

extern IIPStack CAW_OS_EXPORT *CreateIPStack(IIPStackLowLevel *psend, 
                            const CAWString &ifname,
                            const CAWString &ipaddr,
                            const CAWString &ipmask,
                            const CAWString &gateway,
                            char macaddr[6]);
extern void CAW_OS_EXPORT DestroyIPStack(IIPStack *pif);

}/*namespace ipstack*/

#endif//__IIPSTACK_H__

