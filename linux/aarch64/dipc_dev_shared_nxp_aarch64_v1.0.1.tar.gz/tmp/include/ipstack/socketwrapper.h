#ifndef __SOCKETWARPPER_H__
#define __SOCKETWARPPER_H__

#include <stdint.h>

#ifdef __cplusplus 
extern "C" {
#endif
#ifdef CAW_WIN32
#if defined (_LIB) || (CAW_OS_BUILD_LIB) 
#define PS_OS_EXPORT
#else 
#if defined (_USRDLL) || (CAW_OS_BUILD_DLL)
#define PS_OS_EXPORT __declspec(dllexport)
#else 
#define PS_OS_EXPORT __declspec(dllimport)
#endif // _USRDLL || CAW_OS_BUILD_DLL
#endif // _LIB || CAW_OS_BUILD_LIB
#else
#if defined (CAW_OS_BUILD_DLL)
#if __GNUC__ >= 4
#define PS_OS_EXPORT __attribute__ ((visibility("default")))
#else
#define PS_OS_EXPORT
#endif
#else
#define PS_OS_EXPORT
#endif
#endif // !CAW_WIN32

#define PS_POLLIN     0x1
#define PS_POLLOUT    0x2
#define PS_POLLERR    0x4
#define PS_POLLNVAL   0x8

#if !defined(ssize_t)
#if !defined(CAW_MACOS)
#ifndef CAW_LINUX
typedef int ssize_t;
#endif
#endif
#endif

struct ps_sockaddr {
  uint8_t     sa_len;
  uint8_t     sa_family;
  char        sa_data[14];
};

struct ps_fdsets
{
    int readfdset[1024];
    uint32_t readfdsize;
    int writefdset[1024];
    uint32_t writefdsize;
    int errdfset[1024];
    uint32_t errfdsize;
};

struct ps_iovec {
    void* iov_base;
    size_t iov_len;
};

struct ps_msghdr {
    void* msg_name;
    socklen_t     msg_namelen;
    struct ps_iovec* msg_iov;
    int           msg_iovlen;
    void* msg_control;
    socklen_t     msg_controllen;
    int           msg_flags;
};
struct ps_pollfd
{
    int fd;
    short events;
    short revents;
};

PS_OS_EXPORT ssize_t ps_readv(int s, const struct ps_iovec* iov, int iovcnt);
PS_OS_EXPORT ssize_t ps_recvmsg(int s, struct ps_msghdr* message, int flags);
PS_OS_EXPORT ssize_t ps_sendmsg(int s, const struct ps_msghdr* message, int flags);
PS_OS_EXPORT ssize_t ps_writev(int s, const struct ps_iovec* iov, int iovcnt);
PS_OS_EXPORT int ps_nodelay(int s, int enable);

PS_OS_EXPORT int ps_poll(struct ps_pollfd* fds, uint32_t nfds, int timeout);
PS_OS_EXPORT const char* ps_inet_ntop(int af, const void* src, char* dst, socklen_t size);
PS_OS_EXPORT int ps_inet_pton(int af, const char* src, void* dst);
PS_OS_EXPORT int ps_accept(int s, struct ps_sockaddr *addr, socklen_t *addrlen);
PS_OS_EXPORT int ps_bind(int s, const struct ps_sockaddr *name, socklen_t namelen);
PS_OS_EXPORT int ps_shutdown(int s, int how);
PS_OS_EXPORT int ps_getpeername (int s, struct ps_sockaddr *name, socklen_t *namelen);
PS_OS_EXPORT int ps_getsockname (int s, struct ps_sockaddr *name, socklen_t *namelen);
PS_OS_EXPORT int ps_getsockopt (int s, int level, int optname, void *optval, socklen_t *optlen);
PS_OS_EXPORT int ps_setsockopt (int s, int level, int optname, const void *optval, socklen_t optlen);
PS_OS_EXPORT int ps_close(int s);
PS_OS_EXPORT int ps_connect(int s, const struct ps_sockaddr *name, socklen_t namelen);
PS_OS_EXPORT int ps_listen(int s, int backlog);
PS_OS_EXPORT int ps_recv(int s, void *mem, size_t len, int flags);
PS_OS_EXPORT int ps_read(int s, void *mem, size_t len);
PS_OS_EXPORT int ps_recvfrom(int s, void *mem, size_t len, int flags,struct ps_sockaddr *from, socklen_t *fromlen);
PS_OS_EXPORT int ps_send(int s, const void *dataptr, size_t size, int flags);
PS_OS_EXPORT int ps_sendto(int s, const void *dataptr, size_t size, int flags,const struct ps_sockaddr *to, socklen_t tolen);
PS_OS_EXPORT int ps_socket(int domain, int type, int protocol);
PS_OS_EXPORT int ps_write(int s, const void *dataptr, size_t size);
PS_OS_EXPORT int ps_select(int maxfdp1, 
    struct ps_fdsets *pset,
    struct ps_fdsets *poutset,
    struct timeval *timeout);
PS_OS_EXPORT int ps_ioctl(int s, long cmd, void *argp);
PS_OS_EXPORT int ps_fcntl(int s, int cmd, int val);
PS_OS_EXPORT int ps_socket_nonblock(int s);
PS_OS_EXPORT int get_pserrno();

PS_OS_EXPORT void ps_set_snd_rcv_buffer(int s,uint32_t sndbuffer, uint32_t rcvbuffer);

PS_OS_EXPORT int ps_is_socket_errno(int s);
#ifdef __cplusplus 
}
#endif
#endif