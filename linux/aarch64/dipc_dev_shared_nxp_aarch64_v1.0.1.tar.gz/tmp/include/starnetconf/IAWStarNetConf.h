/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IAWSTARNETCONF_H
#define IAWSTARNETCONF_H
#include "starbase/CAWStarBase.h"
#include "wface/CAWACEWrapper.h"
using namespace starbase;
using namespace wface;

namespace starnetconf
{

class IAWNetConfTransport;
class IAWNetConfConnector;
class IAWNetConfAcceptor;
class IAWNetConfAcceptorCallHome;
class IAWNetConfConnectorCallHome;
class IAWNetConfAcceptorConnectorSink;

class CAW_OS_EXPORT IAWStarNetConf
{
public:
    static IAWStarNetConf* Instance();
    virtual CAWResult CreateNetConfClient(CAWAutoPtr<IAWNetConfConnector> &aClient) = 0;
    virtual CAWResult CreateNetConfCallHomeAcceptor(CAWAutoPtr<IAWNetConfAcceptorCallHome> &aAcceptor) = 0;
    virtual CAWResult CreateNetConfServer(CAWAutoPtr<IAWNetConfAcceptor> &aServer) = 0;
    virtual CAWResult CreateNetConfCallHomeConnector(CAWAutoPtr<IAWNetConfConnectorCallHome> &aConnector) = 0;
protected:
    virtual ~IAWStarNetConf() {}
};
class CAW_OS_EXPORT IAWNetConfAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWNetConfAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWNetConfConnector : public IAWNetConfAcceptorConnectorId
{
public:
    virtual void AsycNetConfConnect(
        IAWNetConfAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const CAWString &username,
        const CAWString &password,
        const CAWString &privKeyFile,
        const bool keepAlives=true,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;
    virtual void CancelNetConfConnect() = 0;
protected:
    virtual ~IAWNetConfConnector() { }
};

class CAW_OS_EXPORT IAWNetConfAcceptorCallHome : public IAWNetConfAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(
        IAWNetConfAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const CAWString &username,
        const CAWString &password,
        const CAWString &privKeyFile,
        const bool keepAlives=true,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

protected:
    virtual ~IAWNetConfAcceptorCallHome() {}
};

class CAW_OS_EXPORT IAWNetConfAcceptor : public IAWNetConfAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(
       IAWNetConfAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;
    virtual CAWResult SendAuthResult(CAWResult rv,
                    const CAWString &method,
                    const CAWString &submethod,
                    const CAWInetAddr& hostip) = 0;

protected:
    virtual ~IAWNetConfAcceptor() { }
};

class CAW_OS_EXPORT IAWNetConfConnectorCallHome : public IAWNetConfAcceptorConnectorId
{
public:
    virtual void AsycNetConfConnect(
            IAWNetConfAcceptorConnectorSink *aSink,
            const CAWInetAddr &aAddrListen,
            const char *configfile=NULL,
            CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult CancelNetConfConnect(CAWResult aReason) = 0;
    virtual CAWResult SendAuthResult(CAWResult rv,
                    const CAWString &method,
                    const CAWString &submethod,
                    const CAWInetAddr& hostip) = 0;

protected:
    virtual ~IAWNetConfConnectorCallHome() { }
};


class CAW_OS_EXPORT IAWNetConfAcceptorConnectorSink
{
public:
    virtual void OnNetConfConnectIndication(CAWResult aReason,
        IAWNetConfTransport *aTrpt,
        IAWNetConfAcceptorConnectorId *aRequestId) = 0;
    virtual void OnNetConfAuthenticateRequest(const CAWString &username, 
        const CAWString &password, 
        const CAWString &method,
        const CAWString &submethod,
        const CAWInetAddr& hostip) = 0;
    virtual void OnNetConfAuthFailure(const CAWString& authlist,
        const CAWString& username,
        const CAWString& password,
        const CAWInetAddr &hostip) = 0;
protected:
    virtual ~IAWNetConfAcceptorConnectorSink() { }
};


class CAW_OS_EXPORT IAWNetConfTransportSink 
{
public:
    virtual void OnNetConfDataReceive(
        const CAWString &aData,
        IAWNetConfTransport *aTrptId) = 0;
    virtual void OnNetConfPeerDisconnect(
                CAWResult aReason,
                IAWNetConfTransport *aTrptId) = 0;
protected:
    virtual ~IAWNetConfTransportSink() {}
};


class CAW_OS_EXPORT IAWNetConfTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWNetConfTransportSink *psink) = 0;
    virtual CAWResult NetConfDisconnect(CAWResult aReason) = 0;
	virtual CAWResult SendNetConfData(const CAWString &strnetconf) =0;
protected:
    virtual ~IAWNetConfTransport() {}
};
}//namespace starnetconf

#endif // IAWSTARNETCONF_H
