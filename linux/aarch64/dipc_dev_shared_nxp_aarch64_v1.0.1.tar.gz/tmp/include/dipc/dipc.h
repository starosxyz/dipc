﻿/***********************************************************************
 Copyright (C) 2017-2018 南京北星极网络科技有限公司
**********************************************************************/

#ifndef IDIPC_H
#define IDIPC_H
#include <starbase/CAWACEInclude.h>
#include <starbase/CAWStarBase.h>
#include <wface/CAWACEWrapper.h>
#include <dipc/dipcjno.h>
#include <dipcutils/CDIPCProcess.h>
#include <dipcutils/CDIPCNode.h>
#include <dipcutils/DIPCPdu.h>
#include <functional>
#include <fipc/CAWIPCInterface.h>
#include <dipcutils/CDIPCAddress.h>
#include <dipcutils/CDIPCListenNode.h>
#include <dipcutils/CDIPCShareMemory.h>

#include <dipc/IDIPCCli.h>
#include <dipc/IDIPCConfiguration.h>
#include <dipc/IDIPCIPStack.h>
#include <dipc/IDIPCNetconfClient.h>
#include <dipc/IDIPCNetconfServer.h>
#include <dipc/IDIPCStarLang.h>
#include <dipc/IDIPCSYSDB.h>
#include <dipc/IDIPCSYSLOG.h>
#include <dipc/IDIPCWebClient.h>
#include <dipc/IDIPCWebServer.h>

using namespace starbase;
using namespace wface;
using namespace fipc;
using namespace dipc::utils;
namespace dipc {
	/**
	* @mainpage StarOS DIPC Library API Reference
	*
	* <dl>
	* <dt>Abstract Base Classes<dd>
	*        IDIPCProcess, IDIPCProcessSink, IDIPCAcceptorConnectorSink, CDIPCTransportParameter, IDIPCTransportSink,
	*        IDIPCTransport, IDIPCAcceptorConnectorId, IDIPCConnector, IDIPCAcceptor
	* 分布式进程通信平台
	*###适用范围
	** 服务器端多进程软件
	** 数通领域多进程软件
	** DPDK集成软件
	* </dl>
	*/

	class IDIPCTransportSink;
	class IDIPCTransport;
	class IDIPCShareMemory;
	class IDIPCAcceptorConnectorId;
	class IDIPCConnector;
	class IDIPCAcceptor;
	//////////////////////////////////////////////////////////////////////////////////

	typedef std::function<void(CAWResult result)> ResponseHandler;
	typedef std::function<void(const CDIPCProcess& process)> DumpProcessCallBack;
	typedef std::function<void(const CDIPCNode& process)> DumpPeerNodeCallBack;

	typedef enum {
		DIPC_CLUSTER_STATE_NONE,
		DIPC_CLUSTER_STATE_FOLLOWER,
		DIPC_CLUSTER_STATE_CANDIDATE,
		DIPC_CLUSTER_STATE_LEADER
	} dipc_cluster_state_e;


	/** \brief The main object of DIPC Process。
	 */
	class CAW_OS_EXPORT IDIPCProcess
	{
	public:
		/** \brief 创建共享内存
	   * @param sharemm  生成的共享内存
	   * @param shdpath  共享内存路径
	   * @param mmsize  内存大小
	   * @return  CAWResult--	CAW_OK is success
	   */
		virtual CAWResult CreateMemory(CAWAutoPtr<CDIPCShareMemory>& sharemm, const CAWString& shdpath, uint32_t mmsize) = 0;

		/** \brief 创建IPC客户端
		* @param aConClient      生成的客户端
		* @return   CAWResult--	  CAW_OK is success
		*/
		virtual CAWResult CreateIPCClient(CAWAutoPtr<IAWIPCConnector>& aConClient) = 0;

		/** \brief 创建IPC服务端
		* @param aAcceptor     生成的服务端
		* @return   CAWResult--	  CAW_OK is success
		*/
		virtual CAWResult CreateIPCServer(CAWAutoPtr<IAWIPCAcceptor>& aAcceptor) = 0;

		/** \brief 杀死进程
		* @param otherProcessName     dipc进程名
		* @param handler     响应回调
		* @return   CAWResult--	  CAW_OK is success
		*/
		virtual CAWResult KillProcess(const CAWString& otherProcessName, ResponseHandler handler = NULL) = 0;

		/** \brief 开始进程
		* @param otherProcessName     dipc进程名
		* @param handler     响应回调
		* @return   CAWResult--	  CAW_OK is success
		*/
		virtual CAWResult StartProcess(const CAWString& otherProcessName, ResponseHandler handler = NULL) = 0;

		/** \brief 重启进程
		* @param otherProcessName     dipc进程名
		* @param handler     响应回调
		* @return   CAWResult--	  CAW_OK is success
		*/
		virtual CAWResult RestartProcess(const CAWString& otherProcessName, ResponseHandler handler = NULL) = 0;

		/** \brief 获取String类型参数
		* @param paramName     参数
		* @param aDefault     输出的参数
		* @return   CAWString--	  输出的参数
		*/
		virtual CAWString GetDIPCStringParam(const CAWString& paramName, CAWString  aDefault = CAWString()) = 0;

		/** \brief 获取int类型参数
		* @param paramName     参数名
		* @param aDefault     输出的参数
		* @return   int--	  输出的参数
		*/
		virtual int GetDIPCIntParam(const CAWString& paramName, int aDefault = 0) = 0;

		/** \brief 获取bool类型参数
		* @param paramName     参数名
		* @param aDefault     输出的参数
		* @return   bool--	  输出的参数
		*/
		virtual bool GetDIPCBoolParam(const CAWString& paramName, bool aDefault = false) = 0;

		/** \brief 程序启动完成通知
		* @return   CAWResult--	  CAW_OK is success
		*/
		virtual CAWResult ProcessRunFinishNotify() = 0;

		/** \brief 获取进程列表
		* @param list    输出包含进程信息的列表
		*/
		virtual void DumpProcessList(DumpProcessCallBack callback) = 0;
		virtual void GetProcessList(std::list< CDIPCProcess>& processlist) = 0;
		/** \brief 获取进程列表
		* @param list    输出包含进程信息的列表
		*/
		/** \brief Get 进程数量
		* @return	size_t--	进程数量
		*/
		virtual size_t GetProcessSize() = 0;
		/** \brief 根据pno获取进程名
		* @param pno     dipc pno
		* @param processname     进程名
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual CAWResult GetProcessNameByPno(uint16_t pno, CAWString& processname) = 0;

		/** \brief 根据进程名获取pno
		* @param strProcessName     进程名
		* @param pno     dipc pno
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual CAWResult GetPnoByProcessName(const CAWString& strProcessName, uint16_t& pno) = 0;

		/** \brief 获取对端节点
		* @param callback     返回的节点信息
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual void DumpPeerNodes(DumpPeerNodeCallBack callback) = 0;
		virtual void GetPeerNodes(std::list<CDIPCNode> &nodelist) = 0;
		/** \brief 获取对端节点数量
		* @return  size_t--   对端节点数量
		*/
		virtual size_t GetPeerNodesSize() = 0;

		/** \brief 添加对端节点
		* @param nodeid     对端节点id
		* @param port       端口号
		* @param clusterid		集群id
		* @param datacenterid		数据中心id
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual CAWResult AddPeerNode(const CAWString& peerip,
			uint16_t peerport,
			uint32_t peerclusterid,
			uint32_t peerdatacenterid,
			uint32_t peernodeid,
			const CAWString& password,
			const CAWString& type,
			uint16_t sctpport) = 0;

		/** \brief 移除对端节点
		* @param nodeid     对端节点id
		* @param port       端口号
		* @param clusterid		集群id
		* @param datacenterid		数据中心id
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual CAWResult RemovePeerNode(const CAWString& peerip,
			uint16_t peerport,
			uint32_t peerclusterid,
			uint32_t peerdatacenterid,
			uint32_t peernodeid) = 0;


		/** \brief 发包给另一个进程
		* @param msg     发包信息
		* @param tojno       端口号
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual CAWResult SendPacket(CAWMessageBlock& msg, const CDIPCAddress& peeraddr) = 0;

		/** \brief 发包给集群对端
		* @param msg     发包信息
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual CAWResult SendPacketToPeerNode(CAWMessageBlock& msg,uint32_t peernodeid) = 0;

		/** \brief 停止自动发现
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual CAWResult StopDiscovery() = 0;

		/** \brief 开始自动发现
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual CAWResult StartDiscovery() = 0;

		virtual CAWString GetSettings() = 0;
		/** \brief , 获取集群状态
		* @return  CAWResult--   CAW_OK is success
		*/
		virtual dipc_cluster_state_e GetState() = 0;

		/** \brief , 获取本地DIPC地址
		* @param dipcaddr
		*/
		virtual void GetLocalDIPCAddr(CDIPCAddress& dipcaddr) = 0;
		/** \brief 获取持久数据
		* @param urlpath  数据路径
		* @return  CAWString 数据
		*/
		virtual CAWString GetPersistentData(const CAWString& urlpath) = 0;
		/** \brief 存储持久数据
		* @param urlpath  数据路径
		* @param strdata  数据
		* @return  void
		*/
		virtual CAWResult SetPersistentData(const CAWString& urlpath, const CAWString& strdata) = 0;
		/** \brief 存储持久数据
		* @param urlpath  数据路径
		* @param strdata  数据
		* @return  void
		*/
		virtual CAWResult UpdatePersistentData(const CAWString& urlpath, const CAWString& strdata) = 0;


		virtual uint16_t AllocServiceId() = 0;
		virtual void FreeServiceId(uint16_t serviceid) = 0;
		virtual uint16_t GetLocalJno() = 0;
		virtual uint32_t GetClusterId() = 0;
		virtual uint32_t GetDataCenterId() = 0;
		virtual uint32_t GetNodeId() = 0;

		virtual IOAMManager* GetOAMManager() = 0;
		virtual IDIPCConfiguration* GetConfig() = 0;
		virtual INetconfClient* GetNetconfigClient() = 0;
		virtual INetconfServer* GetNetconfigServer() = 0;
		virtual IDIPCStarLang* GetStarLang() = 0;
		virtual ISYSDB* GetDB() = 0;
		virtual ISYSLog* GetLog() = 0;
		virtual IWebClient* GetWebClient() = 0;
		virtual IWebServer* GetWebServer() = 0;

		virtual void* GetCookie() = 0;
		virtual void SetCookie(void* cookie) = 0;
	protected:
		virtual ~IDIPCProcess() {}
	};

	/** \brief dipc进程主要的回调函数
	 */
	class CAW_OS_EXPORT IDIPCProcessSink
	{
	public:
		/** \brief 进程信息更新回调
		* @param updateprocess 更新信息
		* @return  void
		*/
		virtual void OnProcessUpdateState(const CDIPCProcess& updateprocess) = 0;
		/** \brief 所以进程关闭回调
		* @return  void
		*/
		virtual void OnProcessShutdown() = 0;

		/** \brief 所以进程启动结束后回调
		* @return  void
		*/
		virtual void OnBootOK() = 0;

		/** \brief 当当前进程启动结束后，回调
		* @param argc  参数个数
		* @param argv  参数
		* @param dipcProcess  指向DIPCProcess的指针
		* @return  void
		*/

		virtual void OnProcessRun(int argc, char** argv, IDIPCProcess* dipcProcess) = 0;

		/** \brief when peer process is connected to the cluster.
		* 			同步规则1)在同一个集群内的节点，互相可以同步数据。也就是clusterid相等。
		* 			同步规则2)在同一个集群内的节点，datacenterid值大向小的方向同步数据。
		* 			同步规则2)在同一个集群内的节点，datacenterid值相等的时候，互相同步数据。
		* @param nPeerClusterId  peer cluster id
		* @param nPeerDataCenterId  peer datacenter id
		* @param transport  pointer the the transport
		* @return  void
		*/

		/** \brief when peer process is connected to the cluster.
		* 	集群连接时回调函数
		* @param CDIPCAddress peeraddr  dipc地址
		* @return  void
		*/
		virtual void OnNodeConnected(const CDIPCNode& node) = 0;
		virtual void OnPeerConnected(const CDIPCAddress& peeraddr) = 0;
		/** \brief when peer process is connected to the cluster.
		* 	集群断开时回调函数
		* @param CDIPCAddress peeraddr  dipc地址
		* @return  void
		*/
		virtual void OnNodeDisconnect(const CDIPCNode& node) = 0;
		virtual void OnPeerDisconnect(const CDIPCAddress& peeraddr) = 0;

		/** \brief 当另一个进程传过来的数据
		* @param msg  数据结构
		* @param fromjno  进程jno
		* @return  void
		*/
		virtual void OnPacketRcv(CAWMessageBlock& msg, const CDIPCAddress& fromaddr) = 0;

		virtual void OnPacketRcvFromPeerNode(CAWMessageBlock& msg, const CDIPCAddress& fromaddr) = 0;
	protected:
		virtual ~IDIPCProcessSink() {}
	};

	class CAW_OS_EXPORT IDIPCShareMemory : public IAWReferenceControl
	{
	public:
		virtual void* MemLock() = 0;
		virtual void MemUnlock() = 0;
	protected:
		virtual ~IDIPCShareMemory() {}
	};
}//namespace dipc

#endif // IDICP_H

