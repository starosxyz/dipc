/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCNETCONFCLIENT_H
#define IDIPCNETCONFCLIENT_H
#include <starbase/CAWACEInclude.h>
#include <wface/CAWACEWrapper.h>
#include <starbase/CAWString.h>
using namespace starbase;
using namespace wface;
namespace dipc {
class CAW_OS_EXPORT INetconfClientLibSink
{
public:
    virtual CAWResult OnNetconfClientData(const CAWString &data) = 0;
    virtual CAWResult OnNetconfClientConnectResult(CAWResult result) = 0;
    virtual CAWResult OnNetconfClientDisconnect(CAWResult result) = 0;
protected:
    virtual ~INetconfClientLibSink(){}
};

class CAW_OS_EXPORT INetconfClient
{
public:
    virtual CAWResult AddSink(INetconfClientLibSink *psink) = 0;
    virtual CAWResult RemoveSink(INetconfClientLibSink *psink) = 0;
    virtual CAWResult StartConnect() = 0;
    virtual CAWResult Disconnect() = 0;
    virtual CAWResult SendNetconfData(const CAWString &data) =0;

protected:
    virtual ~INetconfClient(){}
};
}//namespace dipc

#endif//IDIPCNETCONFCLIENT_H

