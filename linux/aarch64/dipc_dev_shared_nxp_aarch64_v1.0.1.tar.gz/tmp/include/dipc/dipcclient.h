﻿/***********************************************************************
 Copyright (C) 2017-2018 南京北星极网络科技有限公司
**********************************************************************/

#ifndef IDIPCCLIENT_H
#define IDIPCCLIENT_H
#include <dipc/dipc.h>

namespace dipc {
namespace dipcclient {
/***********************************************************************************/
CAW_OS_EXPORT CAWResult DIPCProcessInit(int argc, char** argv);
CAW_OS_EXPORT CAWResult DIPCPollProcessInit(int argc, char** argv);
CAW_OS_EXPORT CAWResult DIPCProcessInitWithThreadPool(int argc, char** argv);

CAW_OS_EXPORT CAWResult DIPCProcessLoop(IDIPCProcessSink* psink, uint16_t jno);
CAW_OS_EXPORT CAWResult DIPCProcessDetachRun(IDIPCProcessSink* psink, uint16_t jno);
CAW_OS_EXPORT CAWResult DIPCProcessConnect(IDIPCProcessSink* psink, uint16_t jno);
/*On in one start*/
CAW_OS_EXPORT CAWResult DIPCProcessRun(int argc, char** argv, IDIPCProcessSink* psink, uint16_t jno);

/*On in one detach start*/
CAW_OS_EXPORT CAWResult DIPCInit(int argc, char** argv, IDIPCProcessSink* psink, uint16_t jno);

CAW_OS_EXPORT CAWResult DIPCPollWithoutWait();

}//namespace dipcclient
}//namespace dipc
#endif // IDIPCCLIENT_H

