/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCOAM_H
#define IDIPCOAM_H
#include <starbase/CAWACEInclude.h>
#include <starbase/CAWStarBase.h>
#include <wface/CAWACEWrapper.h>
using namespace starbase;
using namespace wface;
namespace dipc {
class CAW_OS_EXPORT ICommand : public IAWReferenceControl
{
public:
    virtual void CLIPrint(const CAWString &strdisplay) = 0;
    virtual void CLIPrintf(const char* msg, ...)=0;
    virtual void CLIPrintEnd() = 0;
    virtual void EndMode(int mode, const char *modestring) = 0;
    virtual CAWString GetCommandName() = 0;
    virtual void UnRegisterHandler() =0;
protected:
    virtual ~ICommand(){}
};
class CAW_OS_EXPORT ICommandHandler
{
public:
    virtual void OnCreateCommand(CAWAutoPtr<ICommand> &command) = 0;
    virtual void OnExecCommand(char *argv[], int argc) = 0;
protected:
    virtual ~ICommandHandler(){}
};

class CAW_OS_EXPORT IOAMManagerSink
{
public:
    virtual void OnConfigChange(const CAWString &strcmd, const CAWString &oldvalue, const CAWString &newvalue) = 0;
    virtual void OnDefaultConfigInit(const CAWString &strcmd, const CAWString &value) = 0;
    virtual void OnCommit() = 0;
    virtual void OnShowCommond(const CAWString &strcmd, ICommand *pcmd) = 0;
protected:
    virtual ~IOAMManagerSink(){}
};

class CAW_OS_EXPORT IOAMManager
{
public:
    virtual CAWResult AddSink(IOAMManagerSink *psink) = 0;
    virtual CAWResult RemoveSink(IOAMManagerSink *psink) = 0;
    virtual void CreateCommand(ICommandHandler *phandler,
                                const CAWString &parentname,
                                const CAWString &commandname,
                                int mode, 
                                const CAWString &help) = 0;

    virtual void CreateProcessModeCommand(ICommandHandler *phandler,
                                const CAWString &parentname,
                                const CAWString &commandname,
                                const CAWString &help) = 0;
    
    virtual void CreateShowCommand(ICommandHandler *phandler,
                                const CAWString &parentname,
                                const CAWString &commandname,
                                const CAWString &help) = 0;
    
    virtual void CreateConfigModeCommand(ICommandHandler *phandler,
                                const CAWString &parentname,
                                const CAWString &commandname,
                                const CAWString &help) = 0;
protected:
    virtual ~IOAMManager(){}
};
}//namespace dipc

#endif//IDIPCOAM_H


