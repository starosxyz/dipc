/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCWEBCLIENT_H
#define IDIPCWEBCLIENT_H
#include <starbase/CAWACEInclude.h>
#include <starbase/CAWString.h>
using namespace starbase;
namespace dipc {
class CAW_OS_EXPORT IWebClientLibSink
{
public:
    virtual void OnWebSocketData(const CAWString &data, uint32_t transportid) = 0;
    virtual void OnWebClientDisconnect(uint32_t transportid) = 0;
    virtual void OnWebClientWebSocketDisconnect(uint32_t transportid) = 0;
    virtual void OnWebClientWebSocketOpen(uint32_t transportid) = 0;

    virtual void OnHttpResponse(uint32_t transportid, 
                                    const CAWString &status, 
                                    const CAWString& strconent)=0;
    virtual void OnWebClientConnected(CAWResult reason,uint32_t transportid, const CAWString &url) = 0;

protected:
    virtual ~IWebClientLibSink(){}
};

class CAW_OS_EXPORT IWebClient
{
public:
    virtual CAWResult AddSink(IWebClientLibSink *psink) = 0;
    virtual CAWResult RemoveSink(IWebClientLibSink *psink) = 0;
    virtual CAWResult ConnectWebServer(const CAWString &url,const CAWString &username, const CAWString &password) = 0;
    virtual CAWResult UpgradeWebSocket(uint32_t transportid, const CAWString &url) = 0;
    virtual CAWResult SendHttpRequest(uint32_t transportid,
                                    const CAWString &method,
                                    const CAWString &requesturl, 
                                    const CAWString &strconent) = 0;
    virtual CAWResult SendWebSocket(uint32_t transportid, 
                                    const CAWString &strconent) = 0;
    virtual CAWResult WebClientDisconnect(uint32_t transportid) = 0;

protected:
    virtual ~IWebClient(){}
};
}//namespace dipc

#endif//IWEBSERVER_H

