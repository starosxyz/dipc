/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCNETCONFSERVER_H
#define IDIPCNETCONFSERVER_H
#include <starbase/CAWACEInclude.h>
#include <wface/CAWACEWrapper.h>
#include <starbase/CAWString.h>
using namespace starbase;
using namespace wface;
namespace dipc {
class CAW_OS_EXPORT INetconfServerLibSink
{
public:
    virtual CAWResult OnNetconfServerData(const CAWString &data, uint32_t transportid) = 0;
    virtual CAWResult OnNetconfServerAuthRequest(const CAWString &username, 
                                                const CAWString &password, 
                                                const CAWString &method,
                                                const CAWString &submethod,
                                                uint32_t channelid) = 0;
    virtual CAWResult OnNetconfServerConnected(uint32_t transportid) = 0;
    virtual CAWResult OnNetconfServerDisconnected(uint32_t transportid) = 0;

protected:
    virtual ~INetconfServerLibSink(){}
};

class CAW_OS_EXPORT INetconfServer
{
public:
    virtual CAWResult AddSink(INetconfServerLibSink *psink) = 0;
    virtual CAWResult RemoveSink(INetconfServerLibSink *psink) = 0;
    virtual CAWResult SendNetconfData(const CAWString &data, uint32_t transporid) =0;
    virtual CAWResult SendAuthResponse(CAWResult result,
                                                const CAWString &method,
                                                const CAWString &submethod,
                                                uint32_t channelid) =0;
    virtual CAWResult StartServer() = 0;
    virtual CAWResult StopServer() = 0;
    virtual CAWResult Disconnect(uint32_t transportid) = 0;
protected:
    virtual ~INetconfServer(){}
};
}//namespace dipc

#endif//IDIPCNETCONFSERVER_H

