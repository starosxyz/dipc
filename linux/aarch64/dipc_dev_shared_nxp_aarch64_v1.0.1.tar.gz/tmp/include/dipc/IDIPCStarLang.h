/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCSTARLANG_H
#define IDIPCSTARLANG_H
#include <starbase/CAWACEInclude.h>
#include <xmlengine/IXmlEngine.h>
using namespace starbase;
using namespace xmlengine;
namespace dipc {

class CAW_OS_EXPORT IDIPCStarLangSink
{
public:
    virtual void OnCreateApp(uint64_t sessionid, const CAWString &strpage) = 0;
    virtual void OnEvent(uint64_t sessionid, 
                                uint64_t objectid,
                                const CAWString & method,
                                XMLParams &params,
                                CAWMessageBlock &pmsgblock)=0;
protected:
    virtual ~IDIPCStarLangSink(){}
};

class CAW_OS_EXPORT IDIPCStarLang
{
public:
    virtual CAWResult AddSink(IDIPCStarLangSink *psink) = 0;
    virtual CAWResult RemoveSink(IDIPCStarLangSink *psink) = 0;
    virtual CAWResult CreateStarLangAPP(const CAWString &strDefPage, 
                                            XMLParams &params) = 0;
    virtual CAWResult DestroyStarLangAPP(uint64_t sessionid)=0;
    virtual CAWResult RegistEvent(const CAWString & method) = 0;
    virtual CAWResult PostEvent(uint64_t sessionid, 
                                uint64_t objectid,
                                const CAWString & eventname, 
                                XMLParams &params,
                                CAWMessageBlock &pmsgblock) = 0;
    virtual CAWResult AddIncludePath(const CAWString &strpath) = 0;

protected:
    virtual ~IDIPCStarLang(){}
};

}//namespace dipc
#endif//IDIPCSTARLANG_H

