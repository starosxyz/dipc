/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef DIPC_JNO_H
#define DIPC_JNO_H
#include <stdint.h>
/////////////////////////////////////////////////////////////////////
#define DIPCJNO_INVALID						(uint16_t)(0x0000)
#define DIPCJNO_START						(uint16_t)(0x0001)
#define DIPCJNO_END							(uint16_t)(0xffff)
#define DIPCJNO_DIPCSERVICE					(uint16_t)(0)
#define DIPCJNO_SYSTEMD					    (uint16_t)(DIPCJNO_START+0)
#define DIPCJNO_PLATFORM_START				(uint16_t)(DIPCJNO_START+100)
#define DIPCJNO_PLATFORM_END				(uint16_t)(DIPCJNO_START+200)
#define DIPCJNO_USER_BASE					(uint16_t)(DIPCJNO_START+201)

#define DIPCJNO_APP1						(uint16_t)(DIPCJNO_PLATFORM_START+1)
#define DIPCJNO_APP2						(uint16_t)(DIPCJNO_PLATFORM_START+2)
#define DIPCJNO_TEST_SSL_SERVER				(uint16_t)(DIPCJNO_PLATFORM_START+3)
#define DIPCJNO_TEST_SSL_CLIENT				(uint16_t)(DIPCJNO_PLATFORM_START+4)
#define DIPCJNO_TEST_SSL_SERVER_UDP			(uint16_t)(DIPCJNO_PLATFORM_START+5)
#define DIPCJNO_TEST_SSL_CLIENT_UDP			(uint16_t)(DIPCJNO_PLATFORM_START+6)
#define DIPCJNO_TEST_SENDPKT				(uint16_t)(DIPCJNO_PLATFORM_START+7)
#define DIPCJNO_TEST_RCVPKT					(uint16_t)(DIPCJNO_PLATFORM_START+8)
#define DIPCJNO_TEST_CREATE_DIPC_SERVER		(uint16_t)(DIPCJNO_PLATFORM_START+9)
#define DIPCJNO_TEST_CREATE_DIPC_CLIENT		(uint16_t)(DIPCJNO_PLATFORM_START+10)
#define DIPCJNO_TEST_SENDPKT2_PEERNODE		(uint16_t)(DIPCJNO_PLATFORM_START+11)
#define DIPCJNO_TEST_DB1					(uint16_t)(DIPCJNO_PLATFORM_START+12)
#define DIPCJNO_TEST_DB2					(uint16_t)(DIPCJNO_PLATFORM_START+13)
#define DIPCJNO_TEST_OTHERTEST				(uint16_t)(DIPCJNO_PLATFORM_START+14)
#define DIPCJNO_TEST_WEBCLIENT				(uint16_t)(DIPCJNO_PLATFORM_START+15)
#define DIPCJNO_TEST_NETCONFCLIENT			(uint16_t)(DIPCJNO_PLATFORM_START+16)
#define DIPCJNO_TEST_NETCONFSERVER			(uint16_t)(DIPCJNO_PLATFORM_START+17)
#define DIPCJNO_TEST_SYSDB					(uint16_t)(DIPCJNO_PLATFORM_START+18)
#define DIPCJNO_TEST_SYSLOG					(uint16_t)(DIPCJNO_PLATFORM_START+20)
#define DIPCJNO_TEST_SENDPKTDELAY			(uint16_t)(DIPCJNO_PLATFORM_START+21)
#define DIPCJNO_TEST_RCVPKTDELAY			(uint16_t)(DIPCJNO_PLATFORM_START+22)

#endif