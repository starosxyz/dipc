/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCSYSLOG_H
#define IDIPCSYSLOG_H
#include <starbase/CAWACEInclude.h>
#include <string>
#include <stdint.h>
#include <starbase/CAWDebug.h>
#include <wface/CAWACEWrapper.h>
using namespace starbase;
using namespace wface;
namespace dipc {
class IDIPCProcess;
#define LOG_DISABLE         (uint32_t)(0)
#define LOG_ERROR           (uint32_t)(1)
#define LOG_WARNING         (uint32_t)(2)
#define LOG_INFO            (uint32_t)(3)
#define LOG_FATAL           (uint32_t)(4)
#define LOG_BUFFER_SIZE     (uint32_t)(1024*4)

CAW_OS_EXPORT IDIPCProcess *GetCurrentDIPC();

typedef enum SYSLOGOrdix
{
    syslog_formator_hex     = 0,
    syslog_formator_decimal = 1
} SYSLOGOrdix;

class CAW_OS_EXPORT SYSLOG_Text_Formator
{
public :
    SYSLOG_Text_Formator(char* lpszBuf, unsigned long dwBufSize);
    virtual ~SYSLOG_Text_Formator();
public :
    void reset();
    SYSLOG_Text_Formator& operator << (char ch);
    SYSLOG_Text_Formator& operator << (unsigned char ch);
    SYSLOG_Text_Formator& operator << (short s);
    SYSLOG_Text_Formator& operator << (unsigned short s);
    SYSLOG_Text_Formator& operator << (int i);
    SYSLOG_Text_Formator& operator << (unsigned int i);
    SYSLOG_Text_Formator& operator << (long l);
    SYSLOG_Text_Formator& operator << (long long l);
    SYSLOG_Text_Formator& operator << (unsigned long long l);
    SYSLOG_Text_Formator& operator << (unsigned long l);
    SYSLOG_Text_Formator& operator << (float f);
    SYSLOG_Text_Formator& operator << (double d);
    SYSLOG_Text_Formator& operator << (const char* lpsz);
    SYSLOG_Text_Formator& operator << (void* lpv);
    SYSLOG_Text_Formator& operator << (SYSLOGOrdix ordix);
    SYSLOG_Text_Formator& operator << (const CAWString& str);
    SYSLOG_Text_Formator& operator << (const std::string& str);
    operator char*();
private :
    void set_hex_flag(unsigned char bValue);
    unsigned char get_hex_flag();
    void advance(const char* lpsz);
private :
    char*  m_lpszBuf;
    unsigned long  m_dwSize;
    unsigned long  m_dwPos;
    unsigned char m_bHex;
};

class CAW_OS_EXPORT ISYSLog
{
public:
    virtual bool CanTrace(int level) = 0;
    virtual void TraceText(int level,char *text) = 0;
protected:
    virtual ~ISYSLog() {}
};



#define SYSLOG_NOT_GLOG(level,str)\
do {    \
	if (GetCurrentDIPC())\
	{\
    if (GetCurrentDIPC()->GetLog()->CanTrace(level)) \
    {\
        char buf_xxx[LOG_BUFFER_SIZE];\
        SYSLOG_Text_Formator formator(buf_xxx, LOG_BUFFER_SIZE); \
        GetCurrentDIPC()->GetLog()->TraceText(level,formator << str); \
    }\
    else \
        (void)0; \
	}\
} while(false)

#define SYSLOG_ERROR_X(str)           SYSLOG_NOT_GLOG(LOG_ERROR, str)
#define SYSLOG_WARNING_X(str)         SYSLOG_NOT_GLOG(LOG_WARNING, str)
#define SYSLOG_INFO_X(str)            SYSLOG_NOT_GLOG(LOG_INFO, str)
#define SYSLOG_FATAL_X(str)           SYSLOG_NOT_GLOG(LOG_FATAL,str)
#define SYSLOG_ERROR_THIS(str)      SYSLOG_ERROR_X(str << " this=" << this)
#define SYSLOG_WARNING_THIS(str)    SYSLOG_WARNING_X(str << " this=" << this)
#define SYSLOG_INFO_THIS(str)       SYSLOG_INFO_X(str << " this=" << this)
#define SYSLOG_FATAL_THIS(str)      SYSLOG_FATAL_X(str<< " this=" <<this)
}//namespace dipc
#endif // ISYSLOG_H
