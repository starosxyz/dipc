/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCSYSDB_H
#define IDIPCSYSDB_H
#include <starbase/CAWACEInclude.h>
#include <wface/CAWACEWrapper.h>
#include <functional>
#include <starbase/CAWString.h>
using namespace starbase;
using namespace wface;
namespace dipc {
typedef std::function<void(const char *aKey, 
                    const size_t aKeySize, 
                    const char *aValue,
                    const size_t aValueSize)> SYSDBCallback;

class CAW_OS_EXPORT ISYSDB
{
public:
    virtual ~ISYSDB(){}
    virtual CAWResult DBLookup(const char *aKey, 
                            size_t aKeySize,
                            SYSDBCallback callback) = 0;
    virtual void DBDump() = 0;

    virtual CAWResult DBInsert(const char *aKey, 
                        size_t aKeySize, 
                        const char *aValue,
                        size_t aValueSize) = 0;
    virtual CAWResult DBUpdate(const char *aKey, 
                        size_t aKeySize, 
                        const char *aValue,
                        size_t aValueSize) = 0;

    virtual CAWResult DBRemove(const char *aKey, 
                        size_t aKeySize) = 0;

};
}//namespace dipc

#endif//ISYSDB_H

