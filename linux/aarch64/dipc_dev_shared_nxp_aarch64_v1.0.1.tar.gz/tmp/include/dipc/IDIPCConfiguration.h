/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCCONFIGURATION_H
#define IDIPCCONFIGURATION_H
#include <starbase/CAWACEInclude.h>
#include <starbase/CAWStarBase.h>
#include <wface/CAWACEWrapper.h>
#include <dipcutils/CDIPCConfigItem.h>
using namespace dipc::utils;
using namespace starbase;
using namespace wface;
namespace dipc {

class CAW_OS_EXPORT IDIPCConfigurationSink
{
public:
    virtual ~IDIPCConfigurationSink(){}
    virtual void OnAddConfig(const CAWString &key, const CAWString &value) = 0;
    virtual void OnRemoveConfig(const CAWString &key, const CAWString &value) = 0;
    virtual void OnUpdateConfig(const CAWString &key, const CAWString &value) = 0;
};


class CAW_OS_EXPORT IDIPCConfiguration
{
public:
    virtual ~IDIPCConfiguration(){}
    virtual CAWResult AddSink(IDIPCConfigurationSink *psink) = 0;
    virtual CAWResult RemoveSink(IDIPCConfigurationSink *psink) = 0;
    virtual CAWResult AddConfig(const CAWString &key, const CAWString &value) = 0;
    virtual CAWResult RemoveConfig(const CAWString &key) = 0;
    virtual CAWResult UpdateConfig(const CAWString &key, const CAWString &value) = 0;
    virtual CAWResult LookupConfig(const CAWString &key, CAWString &value) = 0;
    virtual void GetAll(std::list<CDIPCConfigItem>& configlist) = 0;
};

}//namespace dipc
#endif//IDIPCCONFIGURATION_H

