/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCWEBSERVER_H
#define IDIPCWEBSERVER_H
#include <starbase/CAWACEInclude.h>
#include <starbase/CAWString.h>
#include <wface/CAWACEWrapper.h>
using namespace starbase;
using namespace wface;
namespace dipc {
class CAW_OS_EXPORT IWebServerLibSink
{
public:
    virtual CAWResult OnWebSocketData(const CAWString &data, uint32_t transportid, CAWString &result) = 0;
    virtual CAWResult OnAPIRequest(const CAWString &url,
                                    uint32_t transportid, 
                                    const CAWString &strmethod, 
                                    const CAWString& strconent, 
                                    std::vector<CAWString> &param1, 
                                    std::unordered_map<CAWString,CAWString, CAWStringHash> &param2,
                                    CAWString &result)=0;
protected:
    virtual ~IWebServerLibSink(){}
};

class CAW_OS_EXPORT IWebServer
{
public:
    typedef int APIType;
    enum { 
        // connection type
        APITYPE_CORE = 0,
        APITYPE_APPS = 1,
        APITYPE_OTHER = 2
    };
    //virtual CAWResult AddSink(IWebServerLibSink* psink) = 0;
    //virtual CAWResult RemoveSink(IWebServerLibSink* psink) = 0;
    virtual CAWResult RegisterAPI(IWebServerLibSink* psink,const CAWString &url) = 0;
    virtual CAWResult UnRegisterAPI(IWebServerLibSink* psink, const CAWString& url) = 0;

    virtual CAWResult RegisterWebSocket(IWebServerLibSink* psink, const CAWString& url) = 0;
    virtual CAWResult UnRegisterWebSocket(IWebServerLibSink* psink, const CAWString& url) = 0;


    virtual CAWResult SendAPIResponse(uint32_t transporid, const CAWString &strconent) = 0;
    virtual CAWResult AddAPIDocsTag(APIType type,const CAWString &tagname, const CAWString &strdesc) = 0;
    virtual CAWResult RemoveAPIDocsTag(APIType type,const CAWString &tagname, const CAWString &strdesc) = 0;  

    virtual CAWResult AddAPIDocsPath(APIType type,const CAWString &name, const CAWString &contentpath) = 0;
    virtual CAWResult RemoveAPIDocsPath(APIType type,const CAWString &name) = 0; 

    virtual CAWResult AddAPIDocsDefinition(APIType type,const CAWString &name, const CAWString &contentpath) = 0;
    virtual CAWResult RemoveAPIDocsDefinition(APIType type,const CAWString &name) = 0; 

    virtual CAWResult SendWebSocket(const CAWString &strjson, uint32_t transporid) =0;

    virtual CAWResult RemoveHttpSession(uint32_t transporid) = 0;

protected:
    virtual ~IWebServer(){}
};

}//namespace dipc
#endif//IWEBSERVER_H

