/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPCSERVICE_H
#define IDIPCSERVICE_H
#include <dipc/dipc.h>
namespace dipc {
namespace dipcservice {
class CAW_OS_EXPORT IDIPCService
{
public:
	static IDIPCService *Instance();
    virtual CAWResult Init(IDIPCProcessSink *psink
		,bool isstandlone) = 0;
protected:
    virtual ~IDIPCService(){}
};
}//namespace dipcservice
}//namespace dipc
#endif//IDIPCSERVICE_H

