#ifndef __XMLSOAPMSG_H__
#define __XMLSOAPMSG_H__

#include <iostream>
#include <string>

#include "starbase/CAWDefines.h"
#include "starbase/CAWAtomicOperationT.h"
#include "starbase/CAWUtils.h"
#include "starbase/CAWError.h"

using namespace std;
using namespace starbase;
class SoapSerializer;
class SoapDeSerializer;

class CAW_OS_EXPORT XmlSoapMsg
{
public:
	XmlSoapMsg();
	~XmlSoapMsg();

	void Reset(void);
	const char* GetSoapMsg(void);

	static CAWResult MapInitialize(void);
	static CAWResult MapUninitialize(void);

	CAWResult deserialize(const CAWString &is);
	CAWResult GetHeaderBlock(const char* pBlockName, const char **ppHeaderBlock);
	CAWResult GetParameter(const char* pParaName, const char **ppParameter);
	CAWResult GetMethod(const char **ppMethod);
	CAWResult serialize(CAWString *os, const char *pszSoapBody = NULL);
	CAWResult AddHeaderBlock(const char* pBlockName, const char* pBlockValue);
	CAWResult AddParameter(const char* pParaName, const char* pParaValue);
	CAWResult SetMethod(const char* pMethodName);
	CAWResult SetVersion(const char* pVersion);
private:
	SoapSerializer		*m_pSZ;
	SoapDeSerializer	*m_pDZ;
	CAWResult Init(void);
};

#endif
