#ifndef STRING_LEVELDB_H_INCLUDED
#define STRING_LEVELDB_H_INCLUDED

# include <vector>
# include <string>
# include <iostream>
#include "leveldb/export.h"
#if _MSC_VER >= 1400 // VC++ 8.0
#pragma warning( disable : 4996 )   // disable warning about strdup being deprecated.
#endif
#ifdef _MSC_VER
#pragma warning(disable: 4786) // identifier was truncated to '255' characters in the browser information(mainly brought by stl)
#pragma warning(disable: 4355) // disable 'this' used in base member initializer list
#pragma warning(disable: 4275) // deriving exported class from non-exported
#pragma warning(disable: 4251) // using non-exported as public in exported
#pragma warning(disable: 4244) // 
#pragma warning(disable: 4819) // 
#pragma warning(disable: 4200) // 
#endif // _MSC_VER
namespace leveldb {
class LEVELDB_EXPORT leveldbstring final
{
public:
    leveldbstring();
    leveldbstring(const leveldbstring& str);
    leveldbstring(const leveldbstring& str, size_t pos, size_t len = std::string::npos);
    leveldbstring(const char* s);
    leveldbstring(const char* s, size_t n);
    leveldbstring(size_t n, char c);

    ~leveldbstring();

    leveldbstring& operator=(const leveldbstring &str);

    leveldbstring& operator+= (const leveldbstring& str);  
    leveldbstring& operator+= (const char* s); 
    leveldbstring& operator+= (char c);

    
    bool operator==(const leveldbstring &str);
    bool operator==(const char *str);
    char& operator[] (size_t pos);
    const char& operator[] (size_t pos) const;

    size_t length() const;
    size_t size() const;
    void clear();
    const char *c_str() const;
    const char *data() const;
    leveldbstring substr (size_t pos = 0, size_t len = std::string::npos) const;

    leveldbstring& append (const leveldbstring& str);
    leveldbstring& append (const leveldbstring& str, size_t subpos, size_t sublen);
    leveldbstring& append (const char* s);
    leveldbstring& append (const char* s, size_t n); 
    leveldbstring& append (size_t n, char c);
	leveldbstring& append(const char* s, const char* l);
    leveldbstring& assign (const leveldbstring& str);
    leveldbstring& assign (const leveldbstring& str, size_t subpos, size_t sublen); 
    leveldbstring& assign (const char* s);
    leveldbstring& assign (const char* s, size_t n); 
    leveldbstring& assign (size_t n, char c);

    leveldbstring& insert (size_t pos, const leveldbstring& str); 
    leveldbstring& insert (size_t pos, const leveldbstring& str,
                          size_t subpos, size_t sublen);  
    leveldbstring& insert (size_t pos, const char* s);
    leveldbstring& insert (size_t pos, const char* s, size_t n);  
    leveldbstring& insert (size_t pos, size_t n, char c);

    leveldbstring& erase (size_t pos = 0, size_t len = std::string::npos);

    leveldbstring& replace (size_t pos, size_t len, const leveldbstring& str);
    leveldbstring& replace (size_t pos, size_t len, const leveldbstring& str,
                           size_t subpos, size_t sublen); 
    leveldbstring& replace (size_t pos, size_t len, const char* s);
    leveldbstring& replace (size_t pos, size_t len, const char* s, size_t n); 
    leveldbstring& replace (size_t pos, size_t len, size_t n, char c);

    void swap (leveldbstring& str);
    void pop_back();
    size_t copy (char* s, size_t len, size_t pos = 0) const;

       
    size_t find (const leveldbstring& str, size_t pos = 0) const;  
    size_t find (const char* s, size_t pos = 0) const;
    size_t find (const char* s, size_t pos, size_t n) const; 
    size_t find (char c, size_t pos = 0) const;

	size_t rfind (const leveldbstring& str, size_t pos = std::string::npos) const;
	size_t rfind (const char* s, size_t pos = std::string::npos) const;
	size_t rfind (const char* s, size_t pos, size_t n) const;
	size_t rfind (char c, size_t pos = std::string::npos) const;

    size_t find_first_of (const leveldbstring& str, size_t pos = 0) const;  
    size_t find_first_of (const char* s, size_t pos = 0) const;
    size_t find_first_of (const char* s, size_t pos, size_t n) const; 
    size_t find_first_of (char c, size_t pos = 0) const;

    size_t find_last_of (const leveldbstring& str, size_t pos = std::string::npos) const;
    size_t find_last_of (const char* s, size_t pos = std::string::npos) const;
    size_t find_last_of (const char* s, size_t pos, size_t n) const; 
    size_t find_last_of (char c, size_t pos = std::string::npos) const;

    size_t find_first_not_of (const leveldbstring& str, size_t pos = 0) const;   
    size_t find_first_not_of (const char* s, size_t pos = 0) const;
    size_t find_first_not_of (const char* s, size_t pos, size_t n) const; 
    size_t find_first_not_of (char c, size_t pos = 0) const;

    size_t find_last_not_of (const leveldbstring& str, size_t pos = std::string::npos) const;
    size_t find_last_not_of (const char* s, size_t pos = std::string::npos) const;
    size_t find_last_not_of (const char* s, size_t pos, size_t n) const; 
    size_t find_last_not_of (char c, size_t pos = std::string::npos) const;

    int compare (const leveldbstring& str) const;
    int compare (size_t pos, size_t len, const leveldbstring& str) const;
    int compare (size_t pos, size_t len, const leveldbstring& str,
                 size_t subpos, size_t sublen) const;  
    int compare (const char* s) const;
    int compare (size_t pos, size_t len, const char* s) const;  
    int compare (size_t pos, size_t len, const char* s, size_t n) const;

    void resize (size_t n);
    void resize (size_t n, char c);

	bool empty() const;
    operator const char *() {return m_string.c_str();}
    void push_back(char ch);
    void reserve(size_t len);
    size_t capacity();
    char at (size_t pos);
	const char &at (size_t pos) const;

    char & back();
    const char& back() const;
    char& front();
    const char& front() const;
    
    const std::string &GetRawData() const;
    std::string &GetRawData();
    friend LEVELDB_EXPORT leveldbstring operator+ (const leveldbstring& lhs, const leveldbstring& rhs);
    friend LEVELDB_EXPORT leveldbstring operator+ (const leveldbstring& lhs, const char* rhs);
    friend LEVELDB_EXPORT leveldbstring operator+ (const char* lhs, const leveldbstring& rhs);
    friend LEVELDB_EXPORT leveldbstring operator+ (const leveldbstring& lhs, char rhs);
    friend LEVELDB_EXPORT leveldbstring operator+ (char lhs, const leveldbstring& rhs);

    friend LEVELDB_EXPORT bool operator== (const leveldbstring& lhs,
        const leveldbstring& rhs);
    friend LEVELDB_EXPORT bool operator== (const char* lhs, const leveldbstring& rhs);
    friend LEVELDB_EXPORT bool operator== (const leveldbstring& lhs, const char* rhs);

    friend LEVELDB_EXPORT bool operator!= (const leveldbstring& lhs,
    	const leveldbstring& rhs);

    friend LEVELDB_EXPORT bool operator!= (const char* lhs, const leveldbstring& rhs);

    friend LEVELDB_EXPORT bool operator!= (const leveldbstring& lhs, const char* rhs);


    friend LEVELDB_EXPORT bool operator<  (const leveldbstring& lhs,
        const leveldbstring& rhs);

    friend LEVELDB_EXPORT bool operator<  (const char* lhs, const leveldbstring& rhs);

    friend LEVELDB_EXPORT bool operator<  (const leveldbstring& lhs, const char* rhs);

    friend LEVELDB_EXPORT bool operator<= (const leveldbstring& lhs,
        const leveldbstring& rhs);

    friend LEVELDB_EXPORT bool operator<= (const char* lhs, const leveldbstring& rhs);
    friend LEVELDB_EXPORT bool operator<= (const leveldbstring& lhs, const char* rhs);

    friend LEVELDB_EXPORT bool operator>  (const leveldbstring& lhs,
        const leveldbstring& rhs);
    friend LEVELDB_EXPORT bool operator>  (const char* lhs, const leveldbstring& rhs);
    friend LEVELDB_EXPORT bool operator>  (const leveldbstring& lhs, const char* rhs);
    friend LEVELDB_EXPORT bool operator>= (const leveldbstring& lhs,
    	const leveldbstring& rhs);
    friend LEVELDB_EXPORT bool operator>= (const char* lhs, const leveldbstring& rhs);
    friend LEVELDB_EXPORT bool operator>= (const leveldbstring& lhs, const char* rhs);
public:
    void Tolower();
private:

    std::string m_string;
};

LEVELDB_EXPORT std::ostream& operator<< (std::ostream& os,const leveldbstring& str);

LEVELDB_EXPORT leveldbstring operator+ (const leveldbstring& lhs, const leveldbstring& rhs);
LEVELDB_EXPORT leveldbstring operator+ (const leveldbstring& lhs, const char* rhs);
LEVELDB_EXPORT leveldbstring operator+ (const char* lhs, const leveldbstring& rhs);
LEVELDB_EXPORT leveldbstring operator+ (const leveldbstring& lhs, char rhs);
LEVELDB_EXPORT leveldbstring operator+ (char lhs, const leveldbstring& rhs);
LEVELDB_EXPORT bool operator== (const leveldbstring& lhs,
	const leveldbstring& rhs);
LEVELDB_EXPORT bool operator== (const char* lhs, const leveldbstring& rhs);
LEVELDB_EXPORT bool operator== (const leveldbstring& lhs, const char* rhs);

LEVELDB_EXPORT bool operator!= (const leveldbstring& lhs,
	const leveldbstring& rhs);

LEVELDB_EXPORT bool operator!= (const char* lhs, const leveldbstring& rhs);

LEVELDB_EXPORT bool operator!= (const leveldbstring& lhs, const char* rhs);


LEVELDB_EXPORT bool operator<  (const leveldbstring& lhs,
    const leveldbstring& rhs);

LEVELDB_EXPORT bool operator<  (const char* lhs, const leveldbstring& rhs);

LEVELDB_EXPORT bool operator<  (const leveldbstring& lhs, const char* rhs);

LEVELDB_EXPORT bool operator<= (const leveldbstring& lhs,
    const leveldbstring& rhs);

LEVELDB_EXPORT bool operator<= (const char* lhs, const leveldbstring& rhs);
LEVELDB_EXPORT bool operator<= (const leveldbstring& lhs, const char* rhs);

LEVELDB_EXPORT bool operator>  (const leveldbstring& lhs,
    const leveldbstring& rhs);
LEVELDB_EXPORT bool operator>  (const char* lhs, const leveldbstring& rhs);
LEVELDB_EXPORT bool operator>  (const leveldbstring& lhs, const char* rhs);
LEVELDB_EXPORT bool operator>= (const leveldbstring& lhs,
    const leveldbstring& rhs);
LEVELDB_EXPORT bool operator>= (const char* lhs, const leveldbstring& rhs);
LEVELDB_EXPORT bool operator>= (const leveldbstring& lhs, const char* rhs);
} // namespace leveldb



#endif // STRING_LEVELDB_H_INCLUDED