/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CIPSSCTPINTERFACE_H
#define CIPSSCTPINTERFACE_H
#include "starbase/CAWStarBase.h"
#include "starbase/CAWDefines.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWUtilTemplates.h"
#include "starbase/CAWMutex.h"
#include "ipstacktp/IPSConnectionInterface.h"
using namespace ipstacktp;
using namespace starbase;
namespace ipssctp
{

class IIPSSCTPAcceptorConnectorSink;
class IIPSSCTPTransportSink;
  class IIPSSCTPTransport;
  class IIPSSCTPAcceptorConnectorId;
    class IIPSSCTPConnector;
    class IIPSSCTPAcceptor;

class CAW_OS_EXPORT CIPSSCTPManager
{
public:
    static CIPSSCTPManager* Instance();
    virtual CAWResult CreateSCTPClient(IIPSSCTPConnector *&aConClient) = 0;
    virtual CAWResult CreateSCTPServer(IIPSSCTPAcceptor *&aAcceptor) = 0;
    virtual void SetUDPIdleTimeOut(long ms)=0;
protected:
     virtual ~CIPSSCTPManager(){}
};

class CAW_OS_EXPORT CIPSSCTPTransportParameter
{
public:
    CIPSSCTPTransportParameter()
        : m_dwHaveSent(0)
    {
    }

    DWORD m_dwHaveSent;
};

class CAW_OS_EXPORT IIPSSCTPAcceptorConnectorSink 
{
public:
    virtual void OnSCTPConnectIndication(
        CAWResult aReason,
        IIPSSCTPTransport *aTrpt,
        IIPSSCTPAcceptorConnectorId *aRequestId) = 0;

protected:
    virtual ~IIPSSCTPAcceptorConnectorSink() {}
};

class CAW_OS_EXPORT IIPSSCTPTransportSink
{
public:
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IIPSSCTPTransport*aTrptId,
        CIPSSCTPTransportParameter *aPara = NULL) = 0;

    virtual void OnSend(
        IIPSSCTPTransport*aTrptId,
        CIPSSCTPTransportParameter *aPara = NULL) = 0;

    virtual void OnDisconnect(
    CAWResult aReason,
        IIPSSCTPTransport*aTrptId) = 0;

protected:
    virtual ~IIPSSCTPTransportSink() {}
};

class CAW_OS_EXPORT IIPSSCTPTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IIPSSCTPTransportSink *aSink) = 0;

    virtual IIPSSCTPTransportSink* GetSink() = 0;
    /*max packet 65535 */
    virtual CAWResult SendData(CAWMessageBlock &aData, CIPSSCTPTransportParameter *aPara = NULL) = 0;
    virtual CAWResult SendData(const char* msg,
        size_t msgsize,
        CIPSSCTPTransportParameter* aPara) = 0;
    /// the <aCommand>s are all listed in file CmErrorNetwork.h
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;

    /// Disconnect the connection, and will not callback <IAWTransportSink> longer.
    virtual CAWResult Disconnect(CAWResult aReason) = 0;

protected:
    virtual ~IIPSSCTPTransport() {}
};


class CAW_OS_EXPORT IIPSSCTPAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IIPSSCTPAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IIPSSCTPConnector : public IIPSSCTPAcceptorConnectorId
{
public:
    virtual void AsycConnect(
        IIPSSCTPAcceptorConnectorSink *aSink,
        const CAWInetAddr &PeerUdpEncap,
        uint16_t localport,
        uint16_t peerport,
        CAWInetAddr *aAddrLocal=NULL) = 0;

    virtual void CancelConnect() = 0;

protected:
    virtual ~IIPSSCTPConnector() {}
};

class CAW_OS_EXPORT IIPSSCTPAcceptor : public IIPSSCTPAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IIPSSCTPAcceptorConnectorSink *aSink,
        const CAWInetAddr &udpEncap,
        uint16_t localport) = 0;
    virtual CAWResult StopListen(CAWResult aReason) = 0;
protected:
    virtual ~IIPSSCTPAcceptor() {}
};

class CAW_OS_EXPORT IIPSSCTPConnectorInternal
{
public:
    virtual int Connect(const CAWInetAddr &aAddr, CAWInetAddr *aAddrLocal = NULL) = 0;
    virtual int Close() = 0;
    virtual ~IIPSSCTPConnectorInternal() { }
};
}

#endif // CAWSCTPINTERFACE_H

