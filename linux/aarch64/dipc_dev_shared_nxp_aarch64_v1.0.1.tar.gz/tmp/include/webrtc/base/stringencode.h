/*
 *  Copyright 2004 The WebRTC Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_BASE_STRINGENCODE_H_
#define WEBRTC_BASE_STRINGENCODE_H_

#include <sstream>
#include <string>
#include <vector>
#include "webrtc/base/basictypes.h"
#include "webrtc/base/checks.h"
#include "webrtc/base/stringutils.h"

namespace rtc {

//////////////////////////////////////////////////////////////////////
// String Encoding Utilities
//////////////////////////////////////////////////////////////////////

// Convert an unsigned value to it's utf8 representation.  Returns the length
// of the encoded string, or 0 if the encoding is longer than buflen - 1.
WEBRTC_DLLEXPORT size_t utf8_encode(char* buffer, size_t buflen, unsigned long value);
// Decode the utf8 encoded value pointed to by source.  Returns the number of
// bytes used by the encoding, or 0 if the encoding is invalid.
WEBRTC_DLLEXPORT size_t utf8_decode(const char* source, size_t srclen, unsigned long* value);

// Escaping prefixes illegal characters with the escape character.  Compact, but
// illegal characters still appear in the string.
WEBRTC_DLLEXPORT size_t escape(char * buffer, size_t buflen,
              const char * source, size_t srclen,
              const char * illegal, char escape);
// Note: in-place unescaping (buffer == source) is allowed.
WEBRTC_DLLEXPORT size_t unescape(char * buffer, size_t buflen,
                const char * source, size_t srclen,
                char escape);

// Encoding replaces illegal characters with the escape character and 2 hex
// chars, so it's a little less compact than escape, but completely removes
// illegal characters.  note that hex digits should not be used as illegal
// characters.
WEBRTC_DLLEXPORT size_t encode(char * buffer, size_t buflen,
              const char * source, size_t srclen,
              const char * illegal, char escape);
// Note: in-place decoding (buffer == source) is allowed.
WEBRTC_DLLEXPORT size_t decode(char * buffer, size_t buflen,
              const char * source, size_t srclen,
              char escape);

// Returns a list of characters that may be unsafe for use in the name of a
// file, suitable for passing to the 'illegal' member of escape or encode.
WEBRTC_DLLEXPORT const char* unsafe_filename_characters();

// url_encode is an encode operation with a predefined set of illegal characters
// and escape character (for use in URLs, obviously).
WEBRTC_DLLEXPORT size_t url_encode(char * buffer, size_t buflen,
                  const char * source, size_t srclen);
// Note: in-place decoding (buffer == source) is allowed.
WEBRTC_DLLEXPORT size_t url_decode(char * buffer, size_t buflen,
                  const char * source, size_t srclen);

// html_encode prevents data embedded in html from containing markup.
WEBRTC_DLLEXPORT size_t html_encode(char * buffer, size_t buflen,
                   const char * source, size_t srclen);
// Note: in-place decoding (buffer == source) is allowed.
WEBRTC_DLLEXPORT size_t html_decode(char * buffer, size_t buflen,
                   const char * source, size_t srclen);

// xml_encode makes data suitable for inside xml attributes and values.
WEBRTC_DLLEXPORT size_t xml_encode(char * buffer, size_t buflen,
                  const char * source, size_t srclen);
// Note: in-place decoding (buffer == source) is allowed.
WEBRTC_DLLEXPORT size_t xml_decode(char * buffer, size_t buflen,
                  const char * source, size_t srclen);

// Convert an unsigned value from 0 to 15 to the hex character equivalent...
WEBRTC_DLLEXPORT char hex_encode(unsigned char val);
// ...and vice-versa.
WEBRTC_DLLEXPORT bool hex_decode(char ch, unsigned char* val);

// hex_encode shows the hex representation of binary data in ascii.
WEBRTC_DLLEXPORT size_t hex_encode(char* buffer, size_t buflen,
                  const char* source, size_t srclen);

// hex_encode, but separate each byte representation with a delimiter.
// |delimiter| == 0 means no delimiter
// If the buffer is too short, we return 0
WEBRTC_DLLEXPORT size_t hex_encode_with_delimiter(char* buffer, size_t buflen,
                                 const char* source, size_t srclen,
                                 char delimiter);

// Helper functions for hex_encode.
WEBRTC_DLLEXPORT rtcstring hex_encode(const rtcstring& str);
WEBRTC_DLLEXPORT rtcstring hex_encode(const char* source, size_t srclen);
WEBRTC_DLLEXPORT rtcstring hex_encode_with_delimiter(const char* source, size_t srclen,
                                      char delimiter);

// hex_decode converts ascii hex to binary.
WEBRTC_DLLEXPORT size_t hex_decode(char* buffer, size_t buflen,
                  const char* source, size_t srclen);

// hex_decode, assuming that there is a delimiter between every byte
// pair.
// |delimiter| == 0 means no delimiter
// If the buffer is too short or the data is invalid, we return 0.
WEBRTC_DLLEXPORT size_t hex_decode_with_delimiter(char* buffer, size_t buflen,
                                 const char* source, size_t srclen,
                                 char delimiter);

// Helper functions for hex_decode.
WEBRTC_DLLEXPORT size_t hex_decode(char* buffer, size_t buflen, const rtcstring& source);
WEBRTC_DLLEXPORT size_t hex_decode_with_delimiter(char* buffer, size_t buflen,
                                 const rtcstring& source, char delimiter);

// Apply any suitable string transform (including the ones above) to an STL
// string.  Stack-allocated temporary space is used for the transformation,
// so value and source may refer to the same string.
typedef size_t (*Transform)(char * buffer, size_t buflen,
                            const char * source, size_t srclen);
WEBRTC_DLLEXPORT size_t transform(rtcstring& value, size_t maxlen, const rtcstring& source,
                 Transform t);

// Return the result of applying transform t to source.
WEBRTC_DLLEXPORT rtcstring s_transform(const rtcstring& source, Transform t);

// Convenience wrappers.
inline rtcstring s_url_encode(const rtcstring& source) {
  return s_transform(source, url_encode);
}
inline rtcstring s_url_decode(const rtcstring& source) {
  return s_transform(source, url_decode);
}

// Splits the source string into multiple fields separated by delimiter,
// with duplicates of delimiter creating empty fields.
WEBRTC_DLLEXPORT size_t split(const rtcstring& source, char delimiter,
             StringVector* fields);

// Splits the source string into multiple fields separated by delimiter,
// with duplicates of delimiter ignored.  Trailing delimiter ignored.
WEBRTC_DLLEXPORT size_t tokenize(const rtcstring& source, char delimiter,
                StringVector* fields);

// Tokenize, including the empty tokens.
WEBRTC_DLLEXPORT size_t tokenize_with_empty_tokens(const rtcstring& source,
                                  char delimiter,
                                  StringVector* fields);

// Tokenize and append the tokens to fields. Return the new size of fields.
WEBRTC_DLLEXPORT size_t tokenize_append(const rtcstring& source, char delimiter,
                       StringVector* fields);

// Splits the source string into multiple fields separated by delimiter, with
// duplicates of delimiter ignored. Trailing delimiter ignored. A substring in
// between the start_mark and the end_mark is treated as a single field. Return
// the size of fields. For example, if source is "filename
// \"/Library/Application Support/media content.txt\"", delimiter is ' ', and
// the start_mark and end_mark are '"', this method returns two fields:
// "filename" and "/Library/Application Support/media content.txt".
WEBRTC_DLLEXPORT size_t tokenize(const rtcstring& source, 
                char delimiter, 
                char start_mark,
                char end_mark, 
                StringVector* fields);

// Extract the first token from source as separated by delimiter, with
// duplicates of delimiter ignored. Return false if the delimiter could not be
// found, otherwise return true.
WEBRTC_DLLEXPORT bool tokenize_first(const rtcstring& source,
                    const char delimiter,
                    rtcstring* token,
                    rtcstring* rest);

// Safe sprintf to std::string
//void sprintf(std::string& value, size_t maxlen, const char * format, ...)
//     PRINTF_FORMAT(3);

// Convert arbitrary values to/from a string.

template <class T>
static bool ToString(const T &t, rtcstring* s) {
  RTC_DCHECK(s);
  std::ostringstream oss;
  oss << std::boolalpha << t;
  *s = oss.str().c_str();
  return !oss.fail();
}

template <class T>
static bool FromString(const rtcstring& s, T* t) {
  RTC_DCHECK(t);
  std::istringstream iss(s.c_str());
  iss >> std::boolalpha >> *t;
  return !iss.fail();
}

// Inline versions of the string conversion routines.

template<typename T>
static inline rtcstring ToString(const T& val) {
  rtcstring str; 
  ToString(val, &str); 
  return str;
}

template<typename T>
static inline T FromString(const rtcstring& str) {
  T val; FromString(str, &val); return val;
}

template<typename T>
static inline T FromString(const T& defaultValue, const rtcstring& str) {
  T val(defaultValue); FromString(str, &val); return val;
}

// simple function to strip out characters which shouldn't be
// used in filenames
WEBRTC_DLLEXPORT char make_char_safe_for_filename(char c);

//////////////////////////////////////////////////////////////////////

}  // namespace rtc

#endif  // WEBRTC_BASE_STRINGENCODE_H__
