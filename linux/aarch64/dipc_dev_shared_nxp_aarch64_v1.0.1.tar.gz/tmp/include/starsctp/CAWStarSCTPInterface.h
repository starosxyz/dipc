/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWSCTPINTERFACE_H
#define CAWSCTPINTERFACE_H
#include "starbase/CAWStarBase.h"
#include "starbase/CAWDefines.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWUtilTemplates.h"
#include "starbase/CAWMutex.h"
using namespace starbase;
namespace starsctp
{

class IAWSCTPAcceptorConnectorSink;
class IAWSCTPTransportSink;
  class IAWSCTPTransport;
  class IAWSCTPAcceptorConnectorId;
    class IAWSCTPConnector;
    class IAWSCTPAcceptor;

class CAW_OS_EXPORT CAWSCTPManager
{
public:
    static CAWSCTPManager* Instance();
    virtual CAWResult CreateSCTPClient(IAWSCTPConnector *&aConClient) = 0;
    virtual CAWResult CreateSCTPServer(IAWSCTPAcceptor *&aAcceptor) = 0;
    virtual void SetUDPIdleTimeOut(long ms)=0;
protected:
     virtual ~CAWSCTPManager(){}
};

class CAW_OS_EXPORT CAWSCTPTransportParameter
{
public:
    CAWSCTPTransportParameter()
        : m_dwHaveSent(0)
    {
    }

    DWORD m_dwHaveSent;
};

/// the sink classes don't need ReferenceControl
class CAW_OS_EXPORT IAWSCTPAcceptorConnectorSink 
{
public:
    virtual void OnSCTPConnectIndication(
        CAWResult aReason,
        IAWSCTPTransport *aTrpt,
        IAWSCTPAcceptorConnectorId *aRequestId) = 0;

protected:
    virtual ~IAWSCTPAcceptorConnectorSink() {}
};

class CAW_OS_EXPORT IAWSCTPTransportSink 
{
public:
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWSCTPTransport *aTrptId,
        CAWSCTPTransportParameter *aPara = NULL) = 0;

    virtual void OnSend(
        IAWSCTPTransport *aTrptId,
        CAWSCTPTransportParameter *aPara = NULL) = 0;

    virtual void OnDisconnect(
    CAWResult aReason,
    IAWSCTPTransport *aTrptId) = 0;

protected:
    virtual ~IAWSCTPTransportSink() {}
};

class CAW_OS_EXPORT IAWSCTPTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWSCTPTransportSink *aSink) = 0;

    virtual IAWSCTPTransportSink* GetSink() = 0;

    virtual CAWResult SendData(CAWMessageBlock &aData, CAWSCTPTransportParameter *aPara = NULL) = 0;
    virtual CAWResult SendData(const char* msg,
        size_t msgsize,
        CAWSCTPTransportParameter* aPara) = 0;
    /// the <aCommand>s are all listed in file CmErrorNetwork.h
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;

    /// Disconnect the connection, and will not callback <IAWTransportSink> longer.
    virtual CAWResult Disconnect(CAWResult aReason) = 0;

protected:
    virtual ~IAWSCTPTransport() {}
};


class CAW_OS_EXPORT IAWSCTPAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWSCTPAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWSCTPConnector : public IAWSCTPAcceptorConnectorId
{
public:
    virtual void AsycConnect(
        IAWSCTPAcceptorConnectorSink *aSink,
        const CAWInetAddr &PeerUdpEncap,
        uint16_t localport,
        uint16_t peerport,
        CAWInetAddr *aAddrLocal=NULL) = 0;

    virtual void CancelConnect() = 0;

protected:
    virtual ~IAWSCTPConnector() {}
};

class CAW_OS_EXPORT IAWSCTPAcceptor : public IAWSCTPAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IAWSCTPAcceptorConnectorSink *aSink,
        const CAWInetAddr &udpEncap,
        uint16_t localport) = 0;
    virtual CAWResult StopListen(CAWResult aReason) = 0;
protected:
    virtual ~IAWSCTPAcceptor() {}
};

class CAW_OS_EXPORT IAWSCTPConnectorInternal
{
public:
    virtual int Connect(const CAWInetAddr &aAddr, CAWInetAddr *aAddrLocal = NULL) = 0;
    virtual int Close() = 0;
    virtual ~IAWSCTPConnectorInternal() { }
};
}

#endif // CAWSCTPINTERFACE_H

