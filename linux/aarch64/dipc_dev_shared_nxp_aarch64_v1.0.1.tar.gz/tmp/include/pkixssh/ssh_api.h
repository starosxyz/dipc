/* $OpenBSD: ssh_api.h,v 1.2 2018/04/10 00:10:49 djm Exp $ */
/*
 * Copyright (c) 2012 Markus Friedl.  All rights reserved.
 * Copyright (c) 2018 Roumen Petrov.  All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef SSH_API_H
#define SSH_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "ssh_export.h"
#define SSH_PROPOSAL_MAX 10
typedef struct ssh SSH;
typedef struct sshkey SSHKEY;
typedef struct ServerOptions_t ServerOPT;
typedef struct ClientOptions_t ClientOPT;

struct kex_params {
	char *proposal[SSH_PROPOSAL_MAX];
};

typedef int send_fn(SSH *ssh, const uint8_t *data,size_t len);
typedef int read_fn(SSH *ssh, const uint8_t *data,size_t len);
typedef int channel_data_fn(SSH *ssh, const uint8_t *data,size_t len);
typedef int channel_on_open_fn(SSH *ssh, int channelid, int result);
typedef int on_auth_request(SSH *ssh, 
        const uint8_t *username,
        size_t userlen,
        const uint8_t *password,
        size_t pwdlen,
        const char *method,
        const char *submethod);

typedef void kex_done_fn(SSH *ssh);

typedef void send_signal(SSH *ssh);

typedef void client_auth_failure_fun(SSH *ssh, char *authlist);


/* public SSH API functions */

/*
 * ssh_crypto_init() initialize cryptographic library.
 */
void	SSH_EXPORT ssh_crypto_init(void);

/*
 * ssh_crypto_fini() finalize cryptographic library - release resources.
 */
void	SSH_EXPORT ssh_crypto_fini(void);


/*
 * release ssh connection state.
 */
void	SSH_EXPORT ssh_free(SSH *);
int SSH_EXPORT exchange_identification(SSH *ssh);
int SSH_EXPORT send_exchange_identification(SSH *ssh);

/*
 * ssh_init() create a ssh connection object with given (optional)
 * key exchange parameters.
 */
int	SSH_EXPORT ssh_init(struct ssh **sshp, int is_server, 
	ServerOPT *serveroption,
	ClientOPT *clientoption,
            const char *username, 
            const char *password,
            int subsystem,
            const char *command,
            const char *host,
            const struct sockaddr *hostaddr,
            uint16_t port);
int	SSH_EXPORT ssh_set_send_fun(SSH *sshp, send_fn *sendfun);
int	SSH_EXPORT ssh_set_read_fun(SSH *sshp, read_fn *readfun);
int	SSH_EXPORT ssh_init_client(const char *configfile, ClientOPT **pclient);
int	SSH_EXPORT ssh_free_client(ClientOPT *pclient);

int	SSH_EXPORT ssh_init_server(const char *configfile, ServerOPT **pserver);

int	SSH_EXPORT ssh_free_server(ServerOPT *pserver);


int	SSH_EXPORT ssh_set_channel_data_fun(SSH *sshp, channel_data_fn *readfun);
int	SSH_EXPORT ssh_set_channel_open_fun(SSH *sshp, channel_on_open_fn *openfun);

int	SSH_EXPORT ssh_set_auth_handler(SSH *sshp, on_auth_request *sendfun);
int	SSH_EXPORT ssh_set_kexdone_handler(SSH *sshp, kex_done_fn *sendfun);
int	SSH_EXPORT ssh_set_send_signal(SSH *sshp, send_signal *sendfun);
int	SSH_EXPORT ssh_set_client_auth_failure(SSH *sshp, client_auth_failure_fun *sendfun);



/*
 * attach application specific data to the connection state
 */
void	SSH_EXPORT ssh_set_app_data(SSH *, void *);
void	SSH_EXPORT *ssh_get_app_data(SSH *);

/*
 * ssh_add_hostkey() registers a private/public hostkey for an ssh
 * connection.
 * ssh_add_hostkey() needs to be called before a key exchange is
 * initiated with ssh_packet_next().
 * private hostkeys are required if we need to act as a server.
 * public hostkeys are used to verify the servers hostkey.
 */
int	SSH_EXPORT ssh_add_hostkey(SSH *ssh, SSHKEY *key);

/*
 * ssh_set_verify_host_key_callback() registers a callback function
 * which should be called instead of the default verification. The
 * function given must return 0 if the hostkey is ok, -1 if the
 * verification has failed.
 */
int	SSH_EXPORT ssh_set_verify_host_key_callback(SSH *ssh,
    int (*cb)(SSHKEY *, SSH *));

/*
 * ssh_packet_next() advances to the next input packet and returns
 * the packet type in typep.
 * ssh_packet_next() works by processing an input byte-stream,
 * decrypting the received data and hiding the key-exchange from
 * the caller.
 * ssh_packet_next() sets typep if there is no new packet available.
 * in this case the caller must fill the input byte-stream by passing
 * the data received over network to ssh_input_append().
 * additionally, the caller needs to send the resulting output
 * byte-stream back over the network. otherwise the key exchange
 * would not proceed. the output byte-stream is accessed through
 * ssh_output_ptr().
 */
int	SSH_EXPORT ssh_packet_next(SSH *ssh, uint8_t *typep);

/*
 * ssh_packet_payload() returns a pointer to the raw payload data of
 * the current input packet and the length of this payload.
 * the payload is accessible until ssh_packet_next() is called again.
 */
const uint8_t SSH_EXPORT *ssh_packet_payload(SSH *ssh, size_t *lenp);

/*
 * ssh_packet_put() creates an encrypted packet with the given type
 * and payload.
 * the encrypted packet is appended to the output byte-stream.
 */
int	SSH_EXPORT ssh_packet_put(SSH *ssh, int type, const uint8_t *data,
    size_t len);
int	SSH_EXPORT 
ssh_packet_put_data(SSH *ssh, const uint8_t *data, size_t len);

/*
 * ssh_input_space() checks if 'len' bytes can be appended to the
 * input byte-stream.
 */
int	SSH_EXPORT ssh_input_space(SSH *ssh, size_t len);

/*
 * ssh_input_append() appends data to the input byte-stream.
 */
int	SSH_EXPORT ssh_input_append(SSH *ssh, const uint8_t *data, size_t len);

int SSH_EXPORT ssh_channel_output_append(SSH *ssh, int channelid, const uint8_t *data, size_t len);

/*
 * ssh_output_space() checks if 'len' bytes can be appended to the
 * output byte-stream. XXX
 */
int	SSH_EXPORT ssh_output_space(SSH *ssh, size_t len);

/*
 * ssh_output_ptr() retrieves both a pointer and the length of the
 * current output byte-stream. the bytes need to be sent over the
 * network. the number of bytes that have been successfully sent can
 * be removed from the output byte-stream with ssh_output_consume().
 */
const uint8_t SSH_EXPORT *ssh_output_ptr(SSH *ssh, size_t *len);

/*
 * ssh_output_consume() removes the given number of bytes from
 * the output byte-stream.
 */
int SSH_EXPORT ssh_output_consume(SSH *ssh, size_t len);
int SSH_EXPORT ssh_service_request(SSH *ssh);
int SSH_EXPORT ssh_send_auth_response(SSH *ssh, int result, const char *method, const char *submethod);

#ifdef __cplusplus
}  // extern "C"
#endif

#endif
