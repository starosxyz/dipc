#ifndef CLEVELDBMANAGER_H
#define CLEVELDBMANAGER_H
#include <functional>
#include "starbase/CAWString.h"
using namespace starbase;
namespace stardb
{
typedef std::function<void(const char *aKey, 
                    const size_t aKeySize, 
                    const char *aValue,
                    const size_t aValueSize)> LEVEL_DUMP_FUN;

class CAW_OS_EXPORT CLevelDBManager
{
public:
    static CLevelDBManager * Create(const CAWString &dbname,bool issync=false,size_t cachesize=104857600);
    static void Destroy(CLevelDBManager *pdb);
    virtual CAWResult DBLookup(char *aKey, size_t aKeySize, CAWString *pvalue) = 0;
    virtual CAWResult DBInsert(char *aKey, size_t aKeySize, char *aValue,size_t aValueSize) = 0;
    virtual CAWResult DBUpdate(char *aKey, size_t aKeySize, char *aValue,size_t aValueSize) = 0;
    virtual CAWResult DBRemove(char *aKey, size_t aKeySize) = 0;
    virtual void DBDump(LEVEL_DUMP_FUN fun) = 0;
    virtual CAWResult Init(const CAWString& dbname, bool issync = false, size_t cachesize = 104857600) = 0;
    virtual void UnInit() = 0;
protected:
    virtual ~CLevelDBManager(){}
};

}//namespace stardb
#endif


