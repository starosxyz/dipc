#ifndef CSIMPLEDATABASE_H
#define CSIMPLEDATABASE_H
#include <functional>
#include "starbase/CAWDefines.h"
#include "starbase/CAWString.h"
#include "starbase/CAWHashMapT.h"
using namespace starbase;
namespace stardb
{
typedef std::function<void(const CAWString &key, const CAWString &value)> SDB_DUMP_FUN;
typedef std::unordered_map<CAWString,CAWString,CAWStringHash> SDBMap;
class CAW_OS_EXPORT CSimpleDatabase
{
public:
    static CSimpleDatabase *Create(const CAWString &dbname);
    static void Destroy(CSimpleDatabase *pdb);
    virtual CAWResult Open(const CAWString &dbname)= 0;
    virtual CAWResult DBLookup(const CAWString &key, CAWString &value) = 0;
    virtual CAWResult DBInsert(const CAWString &key, const CAWString &value) = 0;
    virtual CAWResult DBUpdate(const CAWString &key, const CAWString &value) = 0;
    virtual CAWResult DBRemove(const CAWString &key) = 0;
    virtual void DBDump(SDB_DUMP_FUN fun) = 0;
    /* count=0 ,get all*/
    virtual void GetData(uint32_t count, SDBMap &dbmap) = 0;
    virtual CAWResult Close() = 0;
    virtual void Begin() = 0;
    virtual void Commit() = 0;
protected:
    virtual ~CSimpleDatabase(){}
};

}//namespace stardb
#endif