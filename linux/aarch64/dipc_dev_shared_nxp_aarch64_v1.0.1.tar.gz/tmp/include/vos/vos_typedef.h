/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
/**
 * @defgroup los_typedef Type define
 * @ingroup vos
 */

#ifndef _VOS_TYPEDEF_H
#define _VOS_TYPEDEF_H
#include "vos/vos_os.h"
#include "vos/vos_arch.h"
#include "vos/vos_byteorder.h"
#include "vos/vos_export.h"
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */


#define OS_STRING(x)  #x
#define X_STRING(x) OS_STRING(x)

typedef unsigned short      VOS_WORD16;
typedef unsigned short      VOS_WORD;
typedef signed short        VOS_SWORD16;
typedef unsigned int        VOS_WORD32;
typedef signed int          VOS_SWORD32;
typedef unsigned long long  VOS_WORD64;
typedef long long           VOS_SWORD64;
typedef unsigned int        VOS_DWORD;
typedef signed   long int   VOS_SWORDPTR;  /* 与指针大小相同的WORD类型, 32位或者64位 */
typedef unsigned long int   VOS_WORDPTR;   /* 与指针大小相同的WORD类型, 32位或者64位 */
typedef unsigned long int   VOS_WORDTIME;     /* 表示时间 */
typedef size_t              VOS_TULIP_SIZE_T;
typedef size_t              VOS_SIZE_T;
typedef long int            VOS_SSIZE_T;

typedef int              VOS_INT;
typedef char             VOS_CHAR;
typedef unsigned char    VOS_BYTE;
typedef signed   char    VOS_SBYTE;
typedef unsigned char    VOS_BOOLEAN;


/* type definitions */
typedef unsigned char      VOS_UINT8;
typedef unsigned short     VOS_UINT16;
typedef unsigned int       VOS_UINT32;
typedef signed char        VOS_INT8;
typedef signed short       VOS_INT16;
typedef signed int         VOS_INT32;
typedef float              VOS_FLOAT;
typedef double             VOS_DOUBLE;

typedef unsigned long long      VOS_UINT64;
typedef signed long long        VOS_INT64;
typedef signed   long int      VOS_UINTPTR;
typedef signed   long int        VOS_INTPTR;

typedef VOS_UINTPTR            AARCHPTR;

#define VOID               void
#define STATIC             static

#ifndef FALSE
#define FALSE              0U
#endif

#ifndef TRUE
#define TRUE               1U
#endif

#ifndef NULL
#define NULL               ((VOID *)0)
#endif

#ifdef YES
#undef YES
#endif
#define YES                1

#ifdef NO
#undef NO
#endif
#define NO                 0

#define OS_NULL_BYTE       ((VOS_UINT8)0xFF)
#define OS_NULL_SHORT      ((VOS_UINT16)0xFFFF)
#define OS_NULL_INT        ((VOS_UINT32)0xFFFFFFFF)

#ifndef VOS_OK
#define VOS_OK             0
#endif

#ifndef VOS_NOK
#define VOS_NOK            1
#endif

#define OS_FAIL            1
#define OS_ERROR           (VOS_UINT32)(-1)
#define OS_INVALID         (VOS_UINT32)(-1)

#ifndef VOS_LABEL_DEFN
#define VOS_LABEL_DEFN(label) label
#endif

#ifndef VOSARC_ALIGNMENT
#define VOSARC_ALIGNMENT 8
#endif
/* And corresponding power of two alignment */
#ifndef VOSARC_P2ALIGNMENT
#ifdef VOSCFG_AARCH64
#define VOSARC_P2ALIGNMENT 3
#else
#define VOSARC_P2ALIGNMENT 2
#endif
#endif

/* Give a type or object explicit minimum alignment */
#if !defined(VOSBLD_ATTRIB_ALIGN)
#define VOSBLD_ATTRIB_ALIGN(__align__) __attribute__((aligned(__align__)))
#endif

/* Assign a defined variable to a specific section */
#if !defined(VOSBLD_ATTRIB_SECTION)
#define VOSBLD_ATTRIB_SECTION(__sect__) __attribute__((section(__sect__)))
#endif

/*
 * Tell the compiler not to throw away a variable or function. Only known
 * available on 3.3.2 or above. Old version's didn't throw them away,
 * but using the unused attribute should stop warnings.
 */
#define VOSBLD_ATTRIB_USED __attribute__((used))

# define VOS_SWAP_LONG(L) ((VOS_SWAP_WORD ((L) & 0xFFFF) << 16) \
            | VOS_SWAP_WORD(((L) >> 16) & 0xFFFF))
# define VOS_SWAP_WORD(L) ((((L) & 0x00FF) << 8) | (((L) & 0xFF00) >> 8))

# define VOS_HTONL(X) htonl (X)
# define VOS_NTOHL(X) ntohl (X)

# if defined (VOS_LITTLE_ENDIAN)
#   define VOS_IDL_NCTOHL(X) (X)
#   define VOS_IDL_NSTOHL(X) (X)
# else
#   define VOS_IDL_NCTOHL(X) (X << 24)
#   define VOS_IDL_NSTOHL(X) ((X) << 16)
# endif /* VOS_LITTLE_ENDIAN */

// MQX doesn't define these macros correctly.
# if defined (VOS_LITTLE_ENDIAN) && defined (VOS_MQX)
#   define VOS_HTONS(x) x
#   define VOS_NTOHS(x) x
# else
#   define VOS_HTONS(x) htons(x)
#   define VOS_NTOHS(x) ntohs(x)
# endif

# define VOS_LONGLONG_TO_PTR(PTR_TYPE, L) \
     (PTR_TYPE)((intptr_t)(L))


typedef VOS_INT32 VOS_STATUS;

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */

#endif /* _VOS_TYPEDEF_H */
