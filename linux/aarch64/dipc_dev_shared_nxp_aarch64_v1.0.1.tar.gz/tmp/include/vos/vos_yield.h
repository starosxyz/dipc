/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef VOS_YIELD_H_
#define VOS_YIELD_H_
#include "vos_typedef.h"
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */
// Request rescheduling of threads.
VOS_EXPORT void YieldCurrentThread();
#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */
#endif /*VOS_YIELD_H_*/
