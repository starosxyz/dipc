/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef _VOS_PRINTF_H
#define _VOS_PRINTF_H

#include "vos_typedef.h"
#include "vos/vos_export.h"
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */

#define LOS_COMMOM_LEVEL (0)

#define LOS_ERR_LEVEL    (LOS_COMMOM_LEVEL + 1)

#define LOS_WARN_LEVEL   (LOS_ERR_LEVEL + 1)

#define LOS_INFO_LEVEL   (LOS_WARN_LEVEL + 1)

#define LOS_DEBUG_LEVEL  (LOS_INFO_LEVEL + 1)

#define PRINT_LEVEL      LOS_DEBUG_LEVEL

VOS_EXPORT int vos_printf(const char *format, ...);

#define vos_dprintf  vos_printf

#define diag_printf vos_dprintf

#ifndef PRINT_DEBUG
#if PRINT_LEVEL < LOS_DEBUG_LEVEL
#define PRINT_DEBUG(fmt, ...)
#else
#define PRINT_DEBUG(fmt, ...) do {           \
    (vos_dprintf("[DEBUG] "), vos_dprintf(fmt, ##__VA_ARGS__)); \
} while (0)
#endif
#endif

#ifndef PRINT_INFO
#if PRINT_LEVEL < LOS_INFO_LEVEL
#define PRINT_INFO(fmt, ...)
#else
#define PRINT_INFO(fmt, ...) do {           \
    (vos_dprintf("[INFO] "), vos_dprintf(fmt, ##__VA_ARGS__)); \
} while (0)
#endif
#endif

#ifndef PRINT_WARN
#if PRINT_LEVEL < LOS_WARN_LEVEL
#define PRINT_WARN(fmt, ...)
#else
#define PRINT_WARN(fmt, ...) do {           \
    (vos_dprintf("[WARN] "), vos_dprintf(fmt, ##__VA_ARGS__)); \
} while (0)
#endif
#endif

#ifndef PRINT_ERR
#if PRINT_LEVEL < LOS_ERR_LEVEL
#define PRINT_ERR(fmt, ...)
#else
#define PRINT_ERR(fmt, ...) do {           \
    (vos_dprintf("[ERR] "), vos_dprintf(fmt, ##__VA_ARGS__)); \
} while (0)
#endif
#endif


#ifndef PRINT_RELEASE
#define PRINT_RELEASE(fmt, ...)   vos_dprintf(fmt, ##__VA_ARGS__)
#endif

#ifndef PRINT_TRACE
#ifdef DEBUG_TRACE
#define PRINT_TRACE(fmt, ...)   do {vos_dprintf("[TRACE] "fmt, ##__VA_ARGS__);} while (0)
#else
#define PRINT_TRACE(fmt, ...)
#endif
#endif


#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */

#endif /* _VOS_PRINTF_H */
