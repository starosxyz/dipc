/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef VOS_INLINE_H_
#define VOS_INLINE_H_

#if defined(_MSC_VER)

#define VOS_FORCE_INLINE __forceinline
#define VOS_NO_INLINE __declspec(noinline)

#elif defined(__GNUC__)

#define VOS_FORCE_INLINE __attribute__((__always_inline__))
#define VOS_NO_INLINE __attribute__((__noinline__))

#else

#define VOS_FORCE_INLINE
#define VOS_NO_INLINE

#endif

#endif  // VOS_INLINE_H_
