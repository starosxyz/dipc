#ifndef VOS_PLATFORM_H
#define VOS_PLATFORM_H
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__)
#define VOS_OS_WINDOWS
#elif defined(__CYGWIN__) || defined(__CYGWIN32__)
#define VOS_OS_CYGWIN
#elif defined(linux) || defined(__linux) || defined(__linux__)
#ifndef VOS_OS_LINUX
#define VOS_OS_LINUX
#endif
#elif defined(macintosh) || defined(__APPLE__) || defined(__APPLE_CC__)
#define VOS_OS_MACOSX
#elif defined(__FreeBSD__)
#define VOS_OS_FREEBSD
#elif defined(__NetBSD__)
#define VOS_OS_NETBSD
#elif defined(__OpenBSD__)
#define VOS_OS_OPENBSD
#else
// TODO(hamaji): Add other platforms.
#error Platform not supported by glog. Please consider to contribute platform information by submitting a pull request on Github.
#endif
#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */
#endif // VOS_PLATFORM_H
