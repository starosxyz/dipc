/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef _VOS_TIME_H
#define _VOS_TIME_H
#include "vos_typedef.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */

typedef int64_t vos_time_t;

#define NumMillisecsPerSec INT64_C(1000)
#define NumMicrosecsPerSec INT64_C(1000000)
#define NumNanosecsPerSec INT64_C(1000000000)

#define NumMicrosecsPerMillisec NumMicrosecsPerSec / NumMillisecsPerSec;
#define NumNanosecsPerMillisec NumNanosecsPerSec / NumMillisecsPerSec;
#define NumNanosecsPerMicrosec NumNanosecsPerSec / NumMicrosecsPerSec;

#define vos_time_sec(time) ((time) / NumMicrosecsPerSec)
#define vos_time_usec(time) ((time) % NumMicrosecsPerSec)
#define vos_time_msec(time) (((time) / 1000) % 1000)
#define vos_time_to_msec(time) ((time) ? (1 + ((time) - 1) / 1000) : 0)
#define vos_time_from_msec(msec) ((ogs_time_t)(msec) * 1000)
#define vos_time_from_sec(sec) ((ogs_time_t)(sec) * NumMicrosecsPerSec)

// Returns the current time in milliseconds.
VOS_EXPORT VOS_UINT64 VOS_GetCurrentTime();
// Returns the current time in microseconds.
VOS_EXPORT VOS_UINT64 VOS_GetCurrentTimeMicros();
// Returns the current time in nanoseconds.
VOS_EXPORT VOS_UINT64 VOS_GetCurrentTimeNanos();
VOS_EXPORT void VOS_SleepMs(int msecs);
VOS_EXPORT void VOS_USleep(time_t usec);
// Returns total CPU time of a current process in nanoseconds.
// Time base is unknown, therefore use only to calculate deltas.
VOS_EXPORT int64_t GetProcessCpuTimeNanos();

// Returns total CPU time of a current thread in nanoseconds.
// Time base is unknown, therefore use only to calculate deltas.
VOS_EXPORT int64_t GetThreadCpuTimeNanos();
VOS_EXPORT int VOS_Gettimeofday(struct timeval* tv);
VOS_EXPORT vos_time_t VOS_TimeNow(void);
VOS_EXPORT void VOS_GMTime(time_t s, struct tm* tm);
VOS_EXPORT void VOS_LocalTime(time_t s, struct tm* tm);
VOS_EXPORT int VOS_TimeZone(void);
VOS_EXPORT vos_time_t VOS_GetMonotonicTime(void);
VOS_EXPORT char* VOS_GetDateString(char date[128]);
#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */

#endif