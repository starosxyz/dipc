/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
/**
 * @defgroup los_byteoder Type define
 * @ingroup vos
 */
#ifndef _VOS_BYTE_ORDER_H
#define _VOS_BYTE_ORDER_H

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */

/*Byte-order (endian-ness) determination.*/
#if defined (BYTE_ORDER)
#  if (BYTE_ORDER == LITTLE_ENDIAN)
#    define VOS_LITTLE_ENDIAN 0x0123
#    define VOS_BYTE_ORDER VOS_LITTLE_ENDIAN
#  elif (BYTE_ORDER == BIG_ENDIAN)
#    define VOS_BIG_ENDIAN 0x3210
#    define VOS_BYTE_ORDER VOS_BIG_ENDIAN
#  else
#    error: unknown BYTE_ORDER!
#  endif /* BYTE_ORDER */
#elif defined (_BYTE_ORDER)
#  if (_BYTE_ORDER == _LITTLE_ENDIAN)
#    define VOS_LITTLE_ENDIAN 0x0123
#    define VOS_BYTE_ORDER VOS_LITTLE_ENDIAN
#  elif (_BYTE_ORDER == _BIG_ENDIAN)
#    define VOS_BIG_ENDIAN 0x3210
#    define VOS_BYTE_ORDER VOS_BIG_ENDIAN
#  else
#    error: unknown _BYTE_ORDER!
#  endif /* _BYTE_ORDER */
#elif defined (__BYTE_ORDER)
#  if (__BYTE_ORDER == __LITTLE_ENDIAN)
#    define VOS_LITTLE_ENDIAN 0x0123
#    define VOS_BYTE_ORDER VOS_LITTLE_ENDIAN
#  elif (__BYTE_ORDER == __BIG_ENDIAN)
#    define VOS_BIG_ENDIAN 0x3210
#    define VOS_BYTE_ORDER VOS_BIG_ENDIAN
#  else
#    error: unknown __BYTE_ORDER!
#  endif /* __BYTE_ORDER */
#else /* ! BYTE_ORDER && ! __BYTE_ORDER */
#   if defined (i386) || defined (__i386__) || defined (_M_IX86) || \
     defined (vax) || defined (__alpha) || defined (__LITTLE_ENDIAN__) || \
     defined (ARM) || defined (_M_IA64) || defined (_M_AMD64) || \
     defined (__amd64) || \
     ((defined (__ia64__) || defined (__ia64)) && !defined (__hpux))
#     define VOS_LITTLE_ENDIAN 0x0123
#     define VOS_BYTE_ORDER VOS_LITTLE_ENDIAN
#   else
#     define VOS_BIG_ENDIAN 0x3210
#     define VOS_BYTE_ORDER VOS_BIG_ENDIAN
#   endif
#endif /* ! BYTE_ORDER && ! __BYTE_ORDER */

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */

#endif /* _VOS_BYTE_ORDER_H */