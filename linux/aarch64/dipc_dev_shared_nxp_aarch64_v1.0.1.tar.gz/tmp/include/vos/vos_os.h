/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
/**
 * @defgroup los_os Type define
 * @ingroup vos
 */
#ifndef _VOS_OS_H
#define _VOS_OS_H
#include "vos_platform.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */

/* WTF_COMPILER_MSVC Microsoft Visual C++ */
/* WTF_COMPILER_MSVC7_OR_LOWER Microsoft Visual C++ 2003 or lower*/
/* WTF_COMPILER_MSVC9_OR_LOWER Microsoft Visual C++ 2008 or lower*/
#if defined(_MSC_VER)
#define VOS_COMPILER_MSVC 1
#if _MSC_VER < 1400
#define VOS_COMPILER_MSVC7_OR_LOWER 1
#elif _MSC_VER < 1600
#define VOS_COMPILER_MSVC9_OR_LOWER 1
#endif
#endif

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__)
  #ifndef VOS_WIN32
    #define VOS_WIN32 1
  #endif // VOS_WIN32
#endif

#if defined(linux) || defined(__linux) || defined(__linux__)
  #ifndef VOS_LINUX
    #define VOS_LINUX
    //#define VOS_USE_OPENSSL
  #endif // VOS_LINUX
  #ifndef VOS_POSIX
    #define VOS_POSIX
    //#define CAW_USE_OPENSSL 1
  #endif // CAW_POSIX
#endif

#if defined(macintosh) || defined(__APPLE__) || defined(__APPLE_CC__)
  #ifndef VOS_DARWIN
    #define VOS_DARWIN 1
  #endif // VOS_DARWIN
  #ifndef VOS_MACOS
    #define VOS_MACOS 1
  #endif // VOS_DARWIN
#ifndef VOS_UNIX
    #define VOS_UNIX 1
#endif // VOS_DARWIN
#endif


#ifdef VOS_WIN32
  #ifndef NOMINMAX
    #define NOMINMAX
  #endif // NOMINMAX

  // supports Windows NT 4.0 and later, not support Windows 95.
  // mainly for using winsock2 functions
  #ifndef _WIN32_WINNT
    //#define _WIN32_WINNT 0x0400
    #define _WIN32_WINNT 0x0600
   #endif // _WIN32_WINNT
  #define _WINSOCKAPI_    // stops windows.h including winsock.h
  #include <windows.h>
  #include <winsock2.h>
  #include <WS2tcpip.h>
#include <mmsystem.h>
#endif

#if defined(VOS_LINUX) || defined(VOS_UNIX)
  #include <stdint.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <unistd.h>
  #include <errno.h>
  #include <limits.h>
  #include <stdarg.h>
  #include <time.h>
  #include <signal.h>
  #include <sys/stat.h>
  #include <sys/fcntl.h>
  #include <pthread.h>
  #include <fcntl.h>
  #include <sys/types.h>
  #include <sys/ioctl.h>
  #include <sys/socket.h>
  #include <sys/time.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <netdb.h>
  #include <ctype.h>
  #include <sys/poll.h>
  #include <dirent.h>
  #include <sys/wait.h>
  #include <sys/uio.h>
  #include <assert.h>
#endif
#ifdef VOS_MACOS
    #include <stdint.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <unistd.h>
    #include <errno.h>
    #include <limits.h>
    #include <stdarg.h>
    #include <time.h>
    #include <signal.h>
    #include <sys/stat.h>
    #include <sys/fcntl.h>
    #include <pthread.h>
    #include <fcntl.h>
    #include <sys/types.h>
    #include <sys/ioctl.h>
    #include <sys/socket.h>
    #include <sys/time.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <netdb.h>
    #include <ctype.h>
    #include <sys/poll.h>
    #include <dirent.h>
    #include <sys/wait.h>
    #include <sys/uio.h>
#include <sys/errno.h>
    #include <assert.h>
  #include <unistd.h>
  #include <sys/syscall.h>
  #include <sys/time.h>
#include <sys/param.h>
#include <sys/sysctl.h>
#endif

#ifdef VOS_MACOS
  #include <time.h>
  #include <mach/mach_time.h>
#include <mach/mach_init.h>
#include <mach/mach_port.h>
#include <mach/thread_policy.h>
#include <pthread.h>
#include <libkern/OSAtomic.h>
#include <mach/thread_info.h>
#include <mach/thread_act.h>
#include <mach/task.h>
#include <mach/port.h>
#include <mach/port_obj.h>
#include <mach/policy.h>
#endif

#include "vos/vos_typedef.h"
#include "vos/vos_export.h"
VOS_EXPORT long VOS_GetNumOfProcessors (void);
VOS_EXPORT int VOS_GetCurCpus(void);
#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */

#endif /* _VOS_OS_H */