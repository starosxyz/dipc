/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef VOS_LOG_H
#define VOS_LOG_H
#include "vos/vos_typedef.h"
#include "vos/vos_time.h"
#include "vos/vos_export.h"
#include "vos/vos_printf.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef enum
{
    VOS_LOG_DEBUG = 0,
    VOS_LOG_INFO,
    VOS_LOG_WARNING,
    VOS_LOG_ERR,
    VOS_LOG_FATAL,
    VOS_LOG_MAX
} vos_log_e;

VOS_EXPORT int vos_log(const char* format, ...);

/**
 *@ingroup agenttiny
 *@brief set log level.
 *
 *@par Description:
 *This API is used to set log level. The log informations whose level is not less than
  the level set up in this interface are displayed.
 *@attention none.
 *
 *@param level          [IN] Log level to be set up.
 *
 *@retval none.
 *@par Dependency: none.
 *@see vos_get_log_level.
 */
VOS_EXPORT void vos_set_log_level(vos_log_e level);

/**
 *@ingroup agenttiny
 *@brief get log level.
 *
 *@par Description:
 *This API is used to get log level set by vos_set_log_level.
 *@attention none.
 *
 *@param none.
 *
 *@retval #vos_log_e  Log level.
 *@par Dependency: none.
 *@see vos_set_log_level.
 */
VOS_EXPORT vos_log_e vos_get_log_level(void);

VOS_EXPORT const char* vos_get_log_level_name(vos_log_e log_level);

#ifdef VOS_DEBUG
#define VOS_LOG(level, fmt, ...) \
    do \
    { \
        if ((level) >= vos_get_log_level()) \
        { \
            (void)vos_log("[%s][%u][%s:%d] " fmt "\r\n", \
            vos_get_log_level_name((level)), (uint64_t)VOS_GetCurrentTime(), __FUNCTION__, __LINE__, ##__VA_ARGS__); \
        } \
    } while (0)
#else
#define VOS_LOG(level, fmt, ...)
#endif

#ifdef __cplusplus
}
#endif

#endif

