/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
/**
 * @defgroup los_typedef Type define
 * @ingroup vos
 */

#ifndef _VOS_BASE_H
#define _VOS_BASE_H
#include "stddef.h"
#include "stdbool.h"
#include "stdint.h"
#include "vos/vos_platform.h"
#include "vos/vos_os.h"
#include "vos/vos_arch.h"
#include "vos/vos_byteorder.h"
#include "vos/vos_export.h"
#include "vos/vos_typedef.h"
#include "vos/vos_log.h"
#include "vos/vos_assert.h"
#include "vos/vos_file.h"
#include "vos/vos_time.h"
#include "vos/vos_inline.h"
#include "vos/vos_unused.h"
#include "vos/vos_printf.h"
#endif /* _VOS_BASE_H */
