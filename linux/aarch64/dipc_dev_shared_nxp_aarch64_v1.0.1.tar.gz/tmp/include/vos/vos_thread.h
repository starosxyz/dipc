/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef VOS_THREAD_H_
#define VOS_THREAD_H_
#include "vos_typedef.h"
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */
#ifdef VOS_WIN32
  typedef DWORD VOS_THREAD_ID;
  typedef HANDLE CAW_THREAD_HANDLE;
  typedef DWORD VOS_PID;
#else // !VOS_WIN32
  typedef pthread_t VOS_THREAD_ID;
  typedef VOS_THREAD_ID VOS_THREAD_HANDLE;
  typedef pid_t VOS_PID;
#endif // VOS_WIN32

typedef void (*vos_thread_cb)(void* arg);


VOS_EXPORT int VOS_CreateThread(VOS_THREAD_ID* tid, vos_thread_cb entry, void* arg);
#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */
#endif /*VOS_YIELD_H_*/