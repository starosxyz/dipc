/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
/**
 * @defgroup vos_arch Type define
 * @ingroup vos
 */
#ifndef _VOS_ARCH_H
#define _VOS_ARCH_H
#include "vos/vos_os.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */

#ifdef VOS_WIN32
  #include <crtdbg.h>
  #ifdef _DEBUG
	#ifndef VOS_DEBUG
		#define VOS_DEBUG
	#endif
  #endif // _DEBUG

  #if defined (VOS_DEBUG)
    #define VOS_ASSERTE _ASSERTE
  #endif // VOS_DEBUG
#endif // VOS_WIN32

#if defined (VOS_UNIX) || defined(VOS_LINUX)
  #include <assert.h>
  #if defined (VOS_DEBUG) && !defined (VOS_DISABLE_ASSERTE)
    #define VOS_ASSERTE assert
  #endif // VOS_DEBUG
#endif // VOS_UNIX

#ifdef VOS_DISABLE_ASSERTE
  #include "vos/vos_log.h"
  #define VOS_ASSERTE(expr) \
    do { \
        if (!(expr)) { \
            VOS_LOG(VOS_LOG_ERR," Assert failed"); \
        } \
    } while (0)
#endif // VOS_DISABLE_ASSERTE

#ifndef VOS_ASSERTE
  #define VOS_ASSERTE(expr) 
#endif // VOS_ASSERTE

//#define VOS_ASSERTE_THROW VOS_ASSERTE

#ifdef VOS_DISABLE_ASSERTE
  #define VOS_ASSERTE_RETURN(expr, rv) \
    do { \
        if (!(expr)) { \
            VOS_LOG(VOS_LOG_ERR," Assert failed"); \
            return rv; \
        } \
    } while (0)

  #define VOS_ASSERTE_RETURN_VOID(expr) \
    do { \
        if (!(expr)) { \
            VOS_LOG(VOS_LOG_ERR," Assert failed"); \
            return; \
        } \
    } while (0)
#else
  #define VOS_ASSERTE_RETURN(expr, rv) \
    do { \
        VOS_ASSERTE((expr)); \
        if (!(expr)) { \
            VOS_LOG(VOS_LOG_ERR," Assert failed"); \
            return rv; \
        } \
    } while (0)

  #define VOS_ASSERTE_RETURN_VOID(expr) \
    do { \
        VOS_ASSERTE((expr)); \
        if (!(expr)) { \
            VOS_LOG(VOS_LOG_ERR," Assert failed"); \
            return; \
        } \
    } while (0)

#endif // VOS_DISABLE_ASSERTE

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */

#endif /* _VOS_ARCH_H */

