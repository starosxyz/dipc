/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef VOS_FILE_H
#define VOS_FILE_H
#include "vos/vos_typedef.h"
#include "vos/vos_export.h"
#include <stddef.h>
#include <stdio.h>

#include <string.h>

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */

VOS_EXPORT FILE* VOS_FileOpen(const char* file_name_utf8, bool read_only, int* error);
VOS_EXPORT long VOS_FileSize(FILE* pfile);
VOS_EXPORT bool VOS_FileClose(FILE* pfile);
VOS_EXPORT bool VOS_FileWrite(FILE* pfile,const void* buf, size_t length);
VOS_EXPORT bool VOS_FileReadEof(FILE* pfile);
VOS_EXPORT size_t VOS_FileRead(FILE* pfile,void* buf, size_t length);
VOS_EXPORT bool VOS_FileFlush(FILE* pfile);
VOS_EXPORT bool VOS_FileSeekTo(FILE* pfile,int64_t position);
VOS_EXPORT bool VOS_FileRelative(FILE* pfile,int64_t offset);

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */

#endif /* VOS_FILE_H */


