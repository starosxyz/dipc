/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef _VOS_LIKELY_H
#define _VOS_LIKELY_H
#if __GNUC__
#define VOS_DETAIL_BUILTIN_EXPECT(b, t) (__builtin_expect(b, t))
#else
#define VOS_DETAIL_BUILTIN_EXPECT(b, t) b
#endif
#define VOS_LIKELY(x) VOS_DETAIL_BUILTIN_EXPECT((x), 1)
#define VOS_UNLIKELY(x) VOS_DETAIL_BUILTIN_EXPECT((x), 0)
#endif/*_VOS_LIKELY_H*/
