/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef VOS_UNUSED_H_
#define VOS_UNUSED_H_

// Prevent the compiler from warning about an unused variable. For example:
//   int result = DoSomething();
//   VOS_DCHECK(result == 17);
//   VOS_UNUSED(result);
// Note: In most cases it is better to remove the unused variable rather than
// suppressing the compiler warning.
#ifndef VOS_UNUSED
#define VOS_UNUSED(x) static_cast<void>(x)
#endif  // VOS_UNUSED

#endif  // VOS_UNUSED_H_
