/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
/**
 * @defgroup vos_arch Type define
 * @ingroup vos
 */
#ifndef _VOS_ARCH_H
#define _VOS_ARCH_H

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* __cplusplus */


#if (defined(mips) || defined(__mips__) || defined(MIPS) || defined(_MIPS_))
#if defined(__MIPSEB__) \
	|| defined(MIPSEB) \
	|| defined(_MIPSEB)\
	|| defined(__MIPSEB)
#define VOS_ARCH_BIG_ENDIAN 1
#endif
#if defined(__MIPSEL__) \
	|| defined(MIPSEL) \
	|| defined(_MIPSEL)\
	|| defined(__MIPSEL)
#define VOS_ARCH_LITTLE_ENDIAN 1
#endif

#if defined(_LP64) || defined(__LP64__)
#define VOS_ARCH_64_BITS 1
#define VOS_CPU_MIPS64 1
#else 
#define VOS_ARCH_32_BITS 1
#define VOS_CPU_MIPS64 1
#endif

/* MIPS requires allocators to use aligned memory */
#define VOS_USE_ARENA_ALLOC_ALIGNMENT_INTEGER 1
#endif /* MIPS */

/* VOS_CPU_PPC - PowerPC 32-bit */
#if   defined(__ppc__)     \
    || defined(__PPC__)     \
    || defined(__powerpc__) \
    || defined(__powerpc)   \
    || defined(__POWERPC__) \
    || defined(_M_PPC)      \
    || defined(__PPC)
#define VOS_CPU_PPC 1
#define VOS_ARCH_32_BITS 1
#define VOS_ARCH_BIG_ENDIAN 1
#endif

/* VOS_CPU_PPC64 - PowerPC 64-bit */
#if   defined(__ppc64__) \
    || defined(__PPC64__)
#define VOS_CPU_PPC64 1
#define VOS_ARCH_64_BITS 1
#define VOS_ARCH_BIG_ENDIAN 1
#endif

/* VOS_CPU_X86 - i386 / x86 32-bit */
#if   defined(__i386__) \
    || defined(i386)     \
    || defined(_M_IX86)  \
    || defined(_X86_)    \
    || defined(__THW_INTEL)
#define VOS_CPU_X86 1
#define VOS_ARCH_32_BITS 1
#define VOS_ARCH_LITTLE_ENDIAN 1
#endif

/* VOS_CPU_X86_64 - AMD64 / Intel64 / x86_64 64-bit */
#if   defined(__x86_64__) \
    || defined(_M_X64)
#define VOS_CPU_X86_64 1
#define VOS_ARCH_64_BITS 1
#define VOS_ARCH_LITTLE_ENDIAN 1
#endif


/* CPU(ARM) - ARM, any version*/
#if   defined(arm) \
   || defined(__arm__)\
   || defined(__aarch64__)
#define VOS_CPU_ARM 1

#if defined(__ARMEB__)
#define VOS_ARCH_BIG_ENDIAN 1

#elif !defined(__ARM_EABI__) \
   && !defined(__EABI__) \
   && !defined(__VFP_FP__) \
   && !defined(ANDROID)
#define VOS_CPU_MIDDLE_ENDIAN 1

#endif

#if defined(__ARMEL__) || defined(__AARCH64EL__)
#define VOS_ARCH_LITTLE_ENDIAN 1
#endif

#define VOS_ARM_ARCH_AT_LEAST(N) (VOS_CPU_ARM && VOS_ARM_ARCH_VERSION >= N)

/* Set VOS_ARM_ARCH_VERSION */
#if   defined(__ARM_ARCH_4__) \
   || defined(__ARM_ARCH_4T__) \
   || defined(__MARM_ARMV4__) \
   || defined(_ARMV4I_)
#define VOS_ARM_ARCH_VERSION 4

#elif defined(__ARM_ARCH_5__) \
   || defined(__ARM_ARCH_5T__) \
   || defined(__ARM_ARCH_5E__) \
   || defined(__ARM_ARCH_5TE__) \
   || defined(__ARM_ARCH_5TEJ__) \
   || defined(__MARM_ARMV5__)
#define VOS_ARM_ARCH_VERSION 5

#elif defined(__ARM_ARCH_6__) \
   || defined(__ARM_ARCH_6J__) \
   || defined(__ARM_ARCH_6K__) \
   || defined(__ARM_ARCH_6Z__) \
   || defined(__ARM_ARCH_6ZK__) \
   || defined(__ARM_ARCH_6T2__) \
   || defined(__ARMV6__)
#define VOS_ARM_ARCH_VERSION 6

#elif defined(__ARM_ARCH_7A__) \
   || defined(__ARM_ARCH_7R__)
#define VOS_ARM_ARCH_VERSION 7

#elif defined(__ARM_ARCH_8A)
#define VOS_ARM_ARCH_VERSION 8

/* RVCT sets _TARGET_ARCH_ARM */
#elif defined(__TARGET_ARCH_ARM)
#define VOS_ARM_ARCH_VERSION __TARGET_ARCH_ARM

#else
#define VOS_ARM_ARCH_VERSION 0

#endif

/* Set VOS_THUMB_ARCH_VERSION */
#if   defined(__ARM_ARCH_4T__)
#define VOS_THUMB_ARCH_VERSION 1

#elif defined(__ARM_ARCH_5T__) \
   || defined(__ARM_ARCH_5TE__) \
   || defined(__ARM_ARCH_5TEJ__)
#define VOS_THUMB_ARCH_VERSION 2

#elif defined(__ARM_ARCH_6J__) \
   || defined(__ARM_ARCH_6K__) \
   || defined(__ARM_ARCH_6Z__) \
   || defined(__ARM_ARCH_6ZK__) \
   || defined(__ARM_ARCH_6M__)
#define VOS_THUMB_ARCH_VERSION 3

#elif defined(__ARM_ARCH_6T2__) \
   || defined(__ARM_ARCH_7__) \
   || defined(__ARM_ARCH_7A__) \
   || defined(__ARM_ARCH_7R__) \
   || defined(__ARM_ARCH_7M__)
#define VOS_THUMB_ARCH_VERSION 4

/* RVCT sets __TARGET_ARCH_THUMB */
#elif defined(__TARGET_ARCH_THUMB)
#define VOS_THUMB_ARCH_VERSION __TARGET_ARCH_THUMB

#else
#define VOS_THUMB_ARCH_VERSION 0
#endif


/* CPU(ARMV5_OR_LOWER) - ARM instruction set v5 or earlier */
/* On ARMv5 and below the natural alignment is required. 
   And there are some other differences for v5 or earlier. */
#if !defined(ARMV5_OR_LOWER) /* && !CPU_ARM_ARCH_AT_LEAST(6) */
#define VOS_CPU_ARMV5_OR_LOWER 1
#endif


/* CPU(ARM_TRADITIONAL) - Thumb2 is not available, only traditional ARM (v4 or greater) */
/* CPU(ARM_THUMB2) - Thumb2 instruction set is available */
/* Only one of these will be defined. */
#if !defined(VOS_CPU_ARM_TRADITIONAL) && !defined(VOS_CPU_ARM_THUMB2)
#  if defined(thumb2) || defined(__thumb2__) \
  || ((defined(__thumb) || defined(__thumb__)) && VOS_THUMB_ARCH_VERSION == 4)
#    define VOS_CPU_ARM_TRADITIONAL 1
#    define VOS_CPU_ARM_THUMB2 0
#  elif VOS_ARM_ARCH_AT_LEAST(4)
#    define VOS_CPU_ARM_TRADITIONAL 1
#    define VOS_CPU_ARM_THUMB2 0
#  else
#    error "Not supported ARM architecture"
#  endif
#elif VOS_CPU_ARM_TRADITIONAL && VOS_CPU_ARM_THUMB2 /* Sanity Check */
#  error "Cannot use both of VOS_CPU_ARM_TRADITIONAL and VOS_CPU_ARM_THUMB2 platforms"
#endif // !defined(VOS_CPU_ARM_TRADITIONAL) && !defined(VOS_CPU_ARM_THUMB2)

#endif /* ARM */



#if !(defined(VOS_ARCH_LITTLE_ENDIAN) ^ defined(VOS_ARCH_BIG_ENDIAN))
#error Define either VOS_ARCH_LITTLE_ENDIAN or VOS_ARCH_BIG_ENDIAN
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cplusplus */
#endif /* __cplusplus */

#endif /* _VOS_ARCH_H */

