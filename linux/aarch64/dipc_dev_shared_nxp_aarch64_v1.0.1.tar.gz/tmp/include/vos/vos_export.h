/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
/**
 * @defgroup los_export Type define
 * @ingroup vos
 */
#ifndef VOS_INCLUDE_EXPORT_H_
#define VOS_INCLUDE_EXPORT_H_

#if !defined(VOS_EXPORT)

#if defined(VOS_SHARED_LIBRARY)
#if defined(_WIN32)

#if defined(VOS_COMPILE_LIBRARY)
#define VOS_EXPORT __declspec(dllexport)
#else
#define VOS_EXPORT __declspec(dllimport)
#endif  // defined(VOS_COMPILE_LIBRARY)

#else  // defined(_WIN32)
#if defined(VOS_COMPILE_LIBRARY)
#define VOS_EXPORT __attribute__((visibility("default")))
#else
#define VOS_EXPORT
#endif
#endif  // defined(_WIN32)

#else  // defined(VOS_SHARED_LIBRARY)
#define VOS_EXPORT
#endif

#endif  // !defined(VOS_EXPORT)

#endif  // VOS_INCLUDE_EXPORT_H_
