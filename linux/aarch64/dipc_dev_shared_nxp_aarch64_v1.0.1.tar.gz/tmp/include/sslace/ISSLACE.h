/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef ISSLACE_H
#define ISSLACE_H
#include "starbase/CAWStarBase.h"
#include "wface/CAWConnectionInterface.h"
using namespace wface;
using namespace starbase;
namespace sslace
{
class CAW_OS_EXPORT ISSLConnection : public IConnectionInterface
{
public:
    static ISSLConnection* Instance();
    virtual ~ISSLConnection(){}

    virtual CAWResult LoadVerifyLocations(const CAWString &caroot)=0;
    virtual void SetVerifyPeer (int strict = 0, int once = 1, int depth = 0) = 0;
    virtual CAWResult PrivateKey (const CAWString &file_name) = 0;
    virtual CAWResult Certificate (const CAWString &file_name) = 0;
    virtual CAWString GetPrivateKey () = 0;
    virtual CAWString GetCertificate () = 0;
    virtual CAWString GetRoot() = 0;
};
}

#endif // ISSLACE_H

