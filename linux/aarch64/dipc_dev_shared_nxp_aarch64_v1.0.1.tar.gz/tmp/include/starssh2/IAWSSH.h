/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IAWSSH_H
#define IAWSSH_H
#include "starbase/CAWStarBase.h"
#include "wface/CAWACEWrapper.h"
using namespace starbase;
using namespace wface;

namespace starssh2
{

class IAWSSHTransport;
class IAWSSHConnector;
class IAWSSHAcceptor;
class IAWSSHAcceptorCallHome;
class IAWSSHConnectorCallHome;
class IAWSSHAcceptorConnectorSink;

class CAW_OS_EXPORT IAWSSH
{
public:
    static IAWSSH* Instance();
    virtual ~IAWSSH(){}
    virtual CAWResult CreateSSH2Client(CAWAutoPtr<IAWSSHConnector> &aClient) = 0;
    virtual CAWResult CreateSSH2CallHomeAcceptor(CAWAutoPtr<IAWSSHAcceptorCallHome> &aAcceptor) = 0;
    virtual CAWResult CreateSSH2Server(CAWAutoPtr<IAWSSHAcceptor> &aServer) = 0;
    virtual CAWResult CreateSSH2CallHomeConnector(CAWAutoPtr<IAWSSHConnectorCallHome> &aConnector) = 0;
};
class CAW_OS_EXPORT IAWSSHAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWSSHAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWSSHConnector : public IAWSSHAcceptorConnectorId
{
public:
    virtual CAWResult AsycSSHConnect(
        IAWSSHAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const CAWString &username,
        const CAWString &password,
        const CAWString &privKeyFile,
        const bool bwantsubsystem,
        const CAWString &command,
        const bool keepAlives=true,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;
    virtual void CancelSSHConnect() = 0;
protected:
    virtual ~IAWSSHConnector() { }
};

class CAW_OS_EXPORT IAWSSHAcceptorCallHome : public IAWSSHAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(
        IAWSSHAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const CAWString &username,
        const CAWString &password,
        const CAWString &privKeyFile,
        const bool bwantsubsystem,
        const CAWString &command,
        const bool keepAlives=true,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

protected:
    virtual ~IAWSSHAcceptorCallHome() {}
};

class CAW_OS_EXPORT IAWSSHAcceptor : public IAWSSHAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(
       IAWSSHAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;
    virtual CAWResult SendAuthResult(CAWResult rv,
                    const CAWString &method,
                    const CAWString &submethod,
                    const CAWInetAddr &hostip) = 0;

protected:
    virtual ~IAWSSHAcceptor() { }
};

class CAW_OS_EXPORT IAWSSHConnectorCallHome : public IAWSSHAcceptorConnectorId
{
public:
    virtual CAWResult AsycSSHConnect(
            IAWSSHAcceptorConnectorSink *aSink,
            const CAWInetAddr &aAddrListen,
            const char *configfile=NULL,
            CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult CancelSSHConnect(CAWResult aReason) = 0;
    virtual CAWResult SendAuthResult(CAWResult rv,
                    const CAWString &method,
                    const CAWString &submethod,
                    const CAWInetAddr &hostip) = 0;

protected:
    virtual ~IAWSSHConnectorCallHome() { }
};


class CAW_OS_EXPORT IAWSSHAcceptorConnectorSink
{
public:
    virtual void OnSSHConnectIndication(CAWResult aReason,
        IAWSSHTransport *aTrpt,
        IAWSSHAcceptorConnectorId *aRequestId) = 0;
    virtual void OnSSHAuthenticateRequest(const CAWString &username, 
        const CAWString &password, 
        const CAWString &method,
        const CAWString &submethod,
        const CAWInetAddr& hostip) = 0;
    virtual void OnAuthFailure(const CAWString& authlist,
        const CAWString& username,
        const CAWString& password,
        const CAWInetAddr& hostip) = 0;
protected:
    virtual ~IAWSSHAcceptorConnectorSink() { }
};


class CAW_OS_EXPORT IAWSSHTransportSink 
{
public:
    virtual void OnSSHDataReceive(
        CAWMessageBlock &aData,
        IAWSSHTransport *aTrptId) = 0;

    virtual void OnSSHDataSend(
        IAWSSHTransport *aTrptId) = 0;

    virtual void OnSSHPeerDisconnect(
                CAWResult aReason,
                IAWSSHTransport *aTrptId) = 0;
protected:
    virtual ~IAWSSHTransportSink() {}
};


class CAW_OS_EXPORT IAWSSHTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWSSHTransportSink *psink) = 0;

    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;

    virtual CAWResult SSHDisconnect(CAWResult aReason) = 0;

	virtual CAWResult SendData(CAWMessageBlock &aData) =0;
protected:
    virtual ~IAWSSHTransport() {}
};
}//namespace starssh2

#endif // IAWSTARSSH2MANAGER_H
