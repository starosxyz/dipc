#ifndef PLATFORM_VERSION_H
#define PLATFORM_VERSION_H


/////////////////////////////////////
#define PLATFORM_MAJOR_VERSION 1
#define PLATFORM_MINOR_VERSION 0
#define PLATFORM_BETA_VERSION 1
///////////////////////////////////////////


#endif
