/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IIPSHTTPS_H
#define IIPSHTTPS_H
#include "starbase/CAWStarBase.h"
#include "ipshttp/IIPSHttpInterface.h"
using namespace starbase;
using namespace ipshttp;
namespace ipshttps
{
class CAW_OS_EXPORT IIPSHttps
{
public:
    static IIPSHttps* Instance();
    virtual ~IIPSHttps(){}

    virtual CAWResult CreateHttpsConnector(
                IPSHttpConnector *&aClient) = 0;

    virtual CAWResult CreateHttpsAcceptor(IPSChannelServerAcceptor *&aAcceptor,
        const CAWString &cerfile,
        const CAWString &keyfile) = 0;
    //friend class CAWSingletonT<CStarHttpsImp>;
};
}

#endif // IIPSHTTPS_H
