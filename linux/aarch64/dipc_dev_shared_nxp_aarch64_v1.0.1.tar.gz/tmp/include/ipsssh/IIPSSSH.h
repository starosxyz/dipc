/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IIPSSSHINTERFACE_H
#define IIPSSSHINTERFACE_H
#include "starbase/CAWStarBase.h"
#include "ipstacktp/IPSConnectionInterface.h"
using namespace starbase;
using namespace ipstacktp;

namespace ipsssh
{

class IIPSSSHTransport;
class IIPSSSHConnector;
class IIPSSSHAcceptor;
class IIPSSSHAcceptorCallHome;
class IIPSSSHConnectorCallHome;
class IIPSSSHAcceptorConnectorSink;

class CAW_OS_EXPORT IIPSSSH
{
public:
    static IIPSSSH* Instance();
    virtual ~IIPSSSH(){}
    virtual CAWResult CreateSSH2Client(CAWAutoPtr<IIPSSSHConnector> &aClient) = 0;
    virtual CAWResult CreateSSH2CallHomeAcceptor(CAWAutoPtr<IIPSSSHAcceptorCallHome> &aAcceptor) = 0;
    virtual CAWResult CreateSSH2Server(CAWAutoPtr<IIPSSSHAcceptor> &aServer) = 0;
    virtual CAWResult CreateSSH2CallHomeConnector(CAWAutoPtr<IIPSSSHConnectorCallHome> &aConnector) = 0;
};
class CAW_OS_EXPORT IIPSSSHAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IIPSSSHAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IIPSSSHConnector : public IIPSSSHAcceptorConnectorId
{
public:
    virtual CAWResult AsycSSHConnect(
        IIPSSSHAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const CAWString &username,
        const CAWString &password,
        const CAWString &privKeyFile,
        const bool bwantsubsystem,
        const CAWString &command,
        const bool keepAlives=true,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;
    virtual void CancelSSHConnect() = 0;
protected:
    virtual ~IIPSSSHConnector() { }
};

class CAW_OS_EXPORT IIPSSSHAcceptorCallHome : public IIPSSSHAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(
        IIPSSSHAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const CAWString &username,
        const CAWString &password,
        const CAWString &privKeyFile,
        const bool bwantsubsystem,
        const CAWString &command,
        const bool keepAlives=true,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

protected:
    virtual ~IIPSSSHAcceptorCallHome() {}
};

class CAW_OS_EXPORT IIPSSSHAcceptor : public IIPSSSHAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(
       IIPSSSHAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        const char *configfile=NULL,
        CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;
    virtual CAWResult SendAuthResult(CAWResult rv,
                    const CAWString &method,
                    const CAWString &submethod,
                    const CAWInetAddr &hostip) = 0;

protected:
    virtual ~IIPSSSHAcceptor() { }
};

class CAW_OS_EXPORT IIPSSSHConnectorCallHome : public IIPSSSHAcceptorConnectorId
{
public:
    virtual CAWResult AsycSSHConnect(
            IIPSSSHAcceptorConnectorSink *aSink,
            const CAWInetAddr &aAddrListen,
            const char *configfile=NULL,
            CAWTimeValue *aTimeDelay=NULL) = 0;

    virtual CAWResult CancelSSHConnect(CAWResult aReason) = 0;
    virtual CAWResult SendAuthResult(CAWResult rv,
                    const CAWString &method,
                    const CAWString &submethod,
                    const CAWInetAddr &hostip) = 0;

protected:
    virtual ~IIPSSSHConnectorCallHome() { }
};


class CAW_OS_EXPORT IIPSSSHAcceptorConnectorSink
{
public:
    virtual void OnSSHConnectIndication(CAWResult aReason,
        IIPSSSHTransport *aTrpt,
        IIPSSSHAcceptorConnectorId *aRequestId) = 0;
    virtual void OnSSHAuthenticateRequest(const CAWString &username, 
        const CAWString &password, 
        const CAWString &method,
        const CAWString &submethod,
        const CAWInetAddr& hostip) = 0;
    virtual void OnAuthFailure(const CAWString& authlist,
        const CAWString& username,
        const CAWString& password,
        const CAWInetAddr& hostip) = 0;
protected:
    virtual ~IIPSSSHAcceptorConnectorSink() { }
};


class CAW_OS_EXPORT IIPSSSHTransportSink 
{
public:
    virtual void OnSSHDataReceive(
        CAWMessageBlock &aData,
        IIPSSSHTransport *aTrptId) = 0;

    virtual void OnSSHDataSend(
        IIPSSSHTransport *aTrptId) = 0;

    virtual void OnSSHPeerDisconnect(
                CAWResult aReason,
                IIPSSSHTransport *aTrptId) = 0;
protected:
    virtual ~IIPSSSHTransportSink() {}
};


class CAW_OS_EXPORT IIPSSSHTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IIPSSSHTransportSink *psink) = 0;

    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;

    virtual CAWResult SSHDisconnect(CAWResult aReason) = 0;
    /*max packet 1024*32 */
	virtual CAWResult SendData(CAWMessageBlock &aData) =0;
protected:
    virtual ~IIPSSSHTransport() {}
};
}//namespace starssh2

#endif // IAWSTARSSH2MANAGER_H
