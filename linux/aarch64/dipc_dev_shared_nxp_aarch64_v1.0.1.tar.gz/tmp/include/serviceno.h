/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef DIPCSERVICENO_H
#define DIPCSERVICENO_H

#include <stdint.h>

#define SERVICENO_WEBSERVER		(uint16_t)(2)
#define SERVICENO_WEBCLIENT		(uint16_t)(3)
#define SERVICENO_SYSLOG		(uint16_t)(4)
#define SERVICENO_SYSDB			(uint16_t)(5)
#define SERVICENO_STARLANG			(uint16_t)(6)
#define SERVICENO_NETCONFSERVER			(uint16_t)(7)
#define SERVICENO_NETCONFCLIENT			(uint16_t)(8)
#define SERVICENO_DIPCCLI			(uint16_t)(9)
#define SERVICENO_DIPCCONFIG			(uint16_t)(10)

#endif//DIPCSERVICENO_H

