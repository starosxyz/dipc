/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef HTTP2HEADER_H
#define HTTP2HEADER_H
#include "starbase/CAWStarBase.h"
namespace utilsex
{
typedef std::unordered_map<CAWString, CAWString, CAWStringHash> HEADERMAP;
typedef std::function<void(const CAWString& key, const CAWString& value)> HeaderCallBack;
class CAW_OS_EXPORT Http2Headers
{
public:
    Http2Headers();
    ~Http2Headers();
    CAWResult AddHeader(const CAWString& name, const CAWString& value);
    CAWResult RemoveHeader(const CAWString& name);
    CAWString GetHeader(const CAWString& name);
    uint32_t GetSize();
    void Clear();
    void CopyDataTo(Http2Headers& other);
    void Dump();
    void DumpHeader(HeaderCallBack callback);
private:
    //CAWMutexThread m_locker;
    HEADERMAP m_headers;
};

}//utilsex

#endif // HTTP2HEADER_H
