#ifndef CWEBSOCKETCOMMON_H_
#define CWEBSOCKETCOMMON_H_

#include "starbase/CAWDefines.h"

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include "utilsex/websocketutf8.h"
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

namespace utilsex
{
#define htonl64(p) {\
    (char)(((p & ((uint64_t)0xff <<  0)) >>  0) & 0xff), (char)(((p & ((uint64_t)0xff <<  8)) >>  8) & 0xff), \
    (char)(((p & ((uint64_t)0xff << 16)) >> 16) & 0xff), (char)(((p & ((uint64_t)0xff << 24)) >> 24) & 0xff), \
    (char)(((p & ((uint64_t)0xff << 32)) >> 32) & 0xff), (char)(((p & ((uint64_t)0xff << 40)) >> 40) & 0xff), \
    (char)(((p & ((uint64_t)0xff << 48)) >> 48) & 0xff), (char)(((p & ((uint64_t)0xff << 56)) >> 56) & 0xff) }

#define CWS_HANDSHAKE_BUFFER_MAX 256

#define CWS_DATA_BUFFER_MAX 65543

#define CWS_STACK_SIZE_MIN 8


#define CWS_VERSION "0.1a"

#define WEBSOCKET_STATE_CONNECTING   (1 << 0)
#define WEBSOCKET_STATE_CONNECTED    (1 << 1)
#define WEBSOCKET_STATE_OPEN         (1 << 2)
#define WEBSOCKET_STATE_CLOSING      (1 << 3)
#define WEBSOCKET_STATE_CLOSED       (1 << 4)

#define WEBSOCKET_FLAG_SSL           (1 << 0)

#define CWS_HANDSHAKE_HAS_UPGRADE    (1 << 0)
#define CWS_HANDSHAKE_HAS_CONNECTION (1 << 1)
#define CWS_HANDSHAKE_HAS_KEY        (1 << 2)
#define CWS_HANDSHAKE_HAS_VERSION    (1 << 3)
#define CWS_HANDSHAKE_HAS_ACCEPT     (1 << 4)

typedef enum {
    CONTINUATION = 0x00,
    TEXT_FRAME = 0x01,
    BINARY_FRAME = 0x02,
    CLOSE = 0x08,
    PING = 0x09,
    PONG = 0x0A,
} eopcode;

typedef struct {
    BOOL fin;
    BOOL rsv1;
    BOOL rsv2;
    BOOL rsv3;
    eopcode opcode;
    BOOL mask;
    uint64_t payload_len;
    uint32_t masking_key[4];
} cwebsocket_frame;


CAW_OS_EXPORT char* cwebsocket_base64_encode(const unsigned char *input, int length);
CAW_OS_EXPORT char* cwebsocket_create_key_challenge_response(const char *seckey);
CAW_OS_EXPORT void cwebsocket_create_key_challenge_response_free(const char* seckey);
}//namespace shttp

#endif
