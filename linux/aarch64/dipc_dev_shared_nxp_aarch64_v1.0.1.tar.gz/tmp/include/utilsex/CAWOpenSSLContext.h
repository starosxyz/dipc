/***********************************************************************
 * Copyright (C) 2016-2022, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef CAW_OPENSSL_CONTEXT_H
#define CAW_OPENSSL_CONTEXT_H
#include "starbase/CAWStarBase.h"
#include "starbase/CAWReactorInterface.h"
#include "wface/CAWConnectionInterface.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWTimerWrapperID.h"
#include "starbase/CAWTimeValue.h"
#include "starbase/CAWUtilTemplates.h"

#include <openssl/ssl.h>
#include <string>

using namespace starbase;
using namespace wface;

namespace utilsex
{

class CAW_OS_EXPORT CAWOpenSSLDataFile
{
public:
    /// Default constructor
    CAWOpenSSLDataFile (void)
        : type_ (-1)
    {
    }

    /// Contructor from a file name and the file type.
    CAWOpenSSLDataFile (const char *file_name,
                     int type = SSL_FILETYPE_PEM)
        : file_name_ (file_name),type_ (type)
    {
    }

    /// The file name
    const char *FileName (void) const
    {
        return this->file_name_.c_str ();
    }

    /// The type
    int Type (void) const
    {
        return this->type_;
    }
private:
    /// The file name
    std::string file_name_;

    /// The type, used by the SSL library to parse the file contents.
    int type_;
};

// ****************************************************************

// NOTE: Solaris studio compilers amongst others will issue warnings if the
// the correct type of function pointer (i.e. extern "C" ) is not stored/used
// of the form:
// Warning (Anachronism): Formal argument callback of type
//   extern "C" int(*)(int,x509_store_ctx_st*) in call to
//   SSL_CTX_set_verify(ssl_ctx_st*, int, extern "C" int(*)(int,x509_store_ctx_st*))
//   is being passed int(*)(int,x509_store_ctx_st*)
// when C library routines are passed CallBack functions pointers that are
// actually C++ functions.
//
// Unfortunatly you can not specify extern "C" linkage anywhere inside a class
// declaration or inside a function prototype for individual parameters. I.e:
//   class { extern "C" int (*callback_) (int, void *); };
// to store a function pointer as a data member of the class is illegal as is:
//   void function (extern "C" int (*callback) (int, void *);
// to declare function (or a class member) that takes a extern "C" function
// pointer as a parameter.
//
// Since we need an extern "C" function pointer as a parameter to be stored
// in the class and handled by member functions, we are forced to declare
// a typedef of that extern "C" function pointer that we can then use.
// Again unfortunatly you also are not allowed to simply add the extern "C"
// to the typedef itself, instead you have to place the typedef declaration
// inside an extern "C" block, thus:

extern "C" {
  typedef int (*extern_C_CallBackVerify_t) (int, X509_STORE_CTX *);
}

/**
 * @class ACE_SSL_Context
 *
 * @brief A wrapper for the OpenSSL SSL_CTX related functions.
 *
 * This class provides a wrapper for the SSL_CTX data structure.
 * Since most applications have a single SSL_CTX structure, this class
 * can be used as a singleton.
 */
class CAW_OS_EXPORT CAWOpenSSLContext
{
public:
    enum {
        INVALID_METHOD = -1,
#if !defined (OPENSSL_NO_SSL2)
        SSLv2_client = 1,
        SSLv2_server,
        SSLv2,
#endif /* !OPENSSL_NO_SSL2 */
        SSLv3_client = 4,
        SSLv3_server,
        SSLv3,
        SSLv23_client,
        SSLv23_server,
        SSLv23,
        TLSv1_client,
        TLSv1_server,
        TLSv1,
        TLSv1_1_client,
        TLSv1_1_server,
        TLSv1_1,
        TLSv1_2_client,
        TLSv1_2_server,
        TLSv1_2
    };

    /// Constructor
    CAWOpenSSLContext (void);

    /// Destructor
    ~CAWOpenSSLContext (void);

    CAWResult Init(void *pcontext,
        int mode, 
        const CAWString& cerfile, 
        const CAWString& keyfile,
        const CAWString& caroot);

    /**
    * Set the CTX mode.  The mode can be set only once, afterwards the
    * function has no effect and returns -1.
    * Once the mode is set the underlying SSL_CTX is initialized and
    * the class can be used.
    * If the mode is not set, then the class automatically initializes
    * itself to the default mode.
    */
    int SetMode (int mode = CAWOpenSSLContext::SSLv23);

    int GetMode (void) const;

    /// Get the SSL context
    SSL_CTX *GetSSLContext (void);
    void SetContext(SSL_CTX *pcontext);
    /// Get the file name and file format used for the private key
    int PrivateKeyType (void) const;
    const char *PrivateKeyFileName (void) const;

    /// Set the private key file.
    /**
        * @note This method should only be called after a certificate has
        *       been set since key verification is performed against the
        *       certificate, among other things.
        */
    int PrivateKey (const char *file_name, int type = SSL_FILETYPE_PEM);

    /// Verify that the private key is valid.
    /**
        * @note This method should only be called after a certificate has
        *       been set since key verification is performed against the
        *       certificate, among other things.
        */
    int VerifyPrivateKey (void);

    /// Get the file name and file format used for the certificate file
    int CertificateType (void) const;
    const char *CertificateFileName (void) const;

    /// Set the certificate file.
    int Certificate (const char *file_name,
                   int type = SSL_FILETYPE_PEM);

    /// Load certificate from memory rather than a file.
    int Certificate (X509* cert);

    /**
        *  @todo Complete this documentation where elipses(...) are used
        *
        *  @doc Use this method when certificate chain verification is
        *  required.  The default server behaviour is SSL_VERIFY_NONE
        *  i.e. client certicates are requested for verified. This method
        *  can be used to configure server to request client certificates
        *  and perform the certificate verification. If <strict> is set
        *  true the client connection is rejected when certificate
        *  verification fails.  Otherwise the session is accepted with a
        *  warning, which is the default behaviour.  If <once> is set true
        *  (default), certificates are requested only once per session.
        *  The last parameter <depth> can be used to set the verification
        *  depth.
        *
        *  Note for verification to work correctly there should be a valid
        *  CA name list set using load_trusted_ca().
        *
        *  @see OpenSSL documentation of SSL_CTX_set_verify(3) for details of
        *  the verification process.
        *
        *  @see OpenSSL documentation ... set_verify_depth(3) ...
        *
        *  Note that this method overrides the use of the
        *  default_verify_mode() method.
        */
    void SetVerifyPeer (int strict = 0, int once = 1, int depth = 0);

    /// TODO: a implementation that will lookup the CTX table for the list
    /// of files and paths etc.
    /// Query the location of trusted certification authority
    /// certificates.
    // const char* ca_file_name(void) const;
    // const char* ca_dir_name(void) const;

    /**
        * Set and query the default verify mode for this context, it is
        * inherited by all the ACE_SSL objects created using the context.
        * It can be overriden on a per-ACE_SSL object.
        */
    void DefaultVerifyMode (int mode);
    int DefaultVerifyMode (void) const;

    /**
        * Set and query the default verify callback for this context, it is
        * inherited by all the ACE_SSL objects created using the context.
        * It can be overriden on a per-ACE_SSL object.
        */
    void DefaultVerifyCallback (extern_C_CallBackVerify_t);
    extern_C_CallBackVerify_t  DefaultVerifyCallback (void) const;

    /**
        * @name OpenSSL Random Number Generator Seed Related Methods
        *
        * These are methods that can be used to seed OpenSSL's
        * pseudo-random number generator.  These methods can be called more
        * than once.
        */
    //@{
    /// Seed the underlying random number generator.  This value should
    /// have at least 128 bits of entropy.
    static int RandomSeed (const char * seed);

    /// Print SSL error corresponding to the given error code.
    static void ReportError (unsigned long error_code);

    /// Print the last SSL error for the current thread.
    static void ReportError (void);

  CAWResult SetCAFile(const CAWString &cafile);
  
  CAWResult SetPrivateKey(const CAWString &keyfile);
  CAWResult SetRoot(const CAWString &rootfile);
private:
    /// Verify if the context has been initialized or not.
    void CheckContext (void);

    /// @@ More to document
    void SSLLibraryInit ();
    void SSLLibraryFini ();

    // = Prevent assignment and copy initialization.
    //@{
    CAWOpenSSLContext (const CAWOpenSSLContext &);
    CAWOpenSSLContext & operator= (const CAWOpenSSLContext &);
    //@}

private:
    /// The SSL_CTX structure
    SSL_CTX *context_;

    /// Cache the mode so we can answer fast
    int mode_;

    /// The private key, certificate, and Diffie-Hellman parameters files
    CAWOpenSSLDataFile private_key_;
    CAWOpenSSLDataFile certificate_;

    /// The default verify mode.
    int default_verify_mode_;

    /// The default verify callback.
    extern_C_CallBackVerify_t  default_verify_callback_;

    /// count of successful CA load attempts
    int have_ca_;
    CAWString m_cafile;
    CAWString m_keyfile;
};
}//namespace utilsex

#endif//CAW_OPENSSL_CONTEXT_H


