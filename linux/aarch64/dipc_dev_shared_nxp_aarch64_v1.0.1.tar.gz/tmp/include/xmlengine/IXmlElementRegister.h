#ifndef IXMLELEMENTEXTREGISTER_H
#define IXMLELEMENTEXTREGISTER_H
#include "starbase/CAWStarBase.h"
#include "starbase/CAWString.h"
#include "starbase/CAWMessageBlock.h"
#include "xmlengine/IXmlElementExecute.h"
namespace xmlengine
{
class CAW_OS_EXPORT IXmlElementRegister
{
public:
	static IXmlElementRegister *Instance();
	virtual CAWResult RegisterElementExecute(const CAWString& name, 
		IXmlElementExecute *pexthandler) = 0;
protected:
	virtual ~IXmlElementRegister(){}
};
}
#endif//IXMLELEMENTEXTREGISTER_H