/***********************************************************************
 Copyright (C) 2017-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef ISTARLANGEVENTHANDLER_H
#define ISTARLANGEVENTHANDLER_H 
#include <xmlengine/IXmlEngine.h>
namespace xmlengine {

typedef std::function<void(IXmlEngine *pengine,uint64_t sessionid,
    uint64_t objectid,
    const CAWString& method,
    XMLParams& params,
    CAWMessageBlock& pmsgblock)> RemoteMethodHandler;

typedef std::function<void(IXmlEngine *pengine,
	uint64_t sessionid,
    const CAWString& method,
    XMLParams& inparams,
    XMLParams& outparams)> LocalMethodHandler;

typedef std::unordered_map<CAWString, RemoteMethodHandler, CAWStringHash> HANDLEMAP;
typedef HANDLEMAP::iterator  HANDLEMAPiterator;
typedef HANDLEMAP::value_type HANDLEMAPPair;

typedef std::unordered_map<CAWString, LocalMethodHandler, CAWStringHash> LOCALHANDLEMAP;
typedef LOCALHANDLEMAP::iterator  LOCALHANDLEMAPiterator;
typedef LOCALHANDLEMAP::value_type LOCALHANDLEMAPPair;

class CAW_OS_EXPORT IXmlEngineEventHandler
{
public:
	static IXmlEngineEventHandler *Instance();
    virtual CAWResult RegisterRemoteMethodHandler(const CAWString& method, RemoteMethodHandler callback) = 0;
    virtual CAWResult UnRegisterRemoteMethodHandler(const CAWString& method) = 0;
    virtual RemoteMethodHandler FindRemoteMethodHandler(const CAWString& method) = 0;

    virtual CAWResult RegisterLocalMethodHandler(const CAWString& method, LocalMethodHandler callback) = 0;
    virtual CAWResult UnRegisterLocalMethodHandler(const CAWString& method) = 0;
    virtual LocalMethodHandler FindLocalMethodHandler(const CAWString& method) = 0;
protected:
    virtual ~IXmlEngineEventHandler() {}
};
}//namespace xmlengine
#endif//ISTARLANGEVENTHANDLER_H
