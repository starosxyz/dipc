/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IXMLENGINE_H
#define IXMLENGINE_H
#include "starbase/CAWStarBase.h"
#include "starbase/CAWString.h"
#include "starbase/CAWMessageBlock.h"
#include "Python.h"
#include "starbase/CAWPathName.h"
using namespace starbase;
namespace xmlengine
{
#define XML_SESSION_DEFAUIL_ID  (uint64_t)0
#define XML_SESSION_INVALID_ID  (uint64_t)0xffffffffffffffff

typedef std::function<void(const CAWString &key, const CAWString &value)> XMLParamsCallBack;

class CAW_OS_EXPORT XMLParams
{
public :
    XMLParams();
    ~XMLParams();
    XMLParams( const XMLParams &other );    
    XMLParams &operator=( const XMLParams &other );
    size_t GetCount();
    void AddParam(const CAWString &key, const CAWString &value);
    void RemoveParam(const CAWString &key);
    CAWString GetParam(const CAWString &key) const ;
    void DumpParams(XMLParamsCallBack callback);
public:
    std::unordered_map<CAWString, CAWString, CAWStringHash> m_params;
};

class CAW_OS_EXPORT IXmlEngineSink
{
public:
    virtual ~IXmlEngineSink(){}
    virtual CAWResult OnXMLLocalCall(uint64_t sessionid, 
                            const CAWString &method, 
                            XMLParams &inparams,
                            XMLParams &outparams)=0;

    virtual CAWResult OnXMLRemoteCall(uint64_t sessionid,
                                uint64_t objectid,
                                const CAWString & method,
                                XMLParams &params,
                                CAWMessageBlock &pmsgblock)=0;

    virtual CAWResult OnXMLRemoteEventCall(uint64_t sessionid,
                                uint64_t objectid,
                                const CAWString & method,
                                XMLParams &params,
                                CAWMessageBlock &pmsgblock)=0;

    virtual void OnParserXMLError(uint64_t bundleid, const CAWString &strerror) = 0;

    virtual void OnXmlStartEngine(const CAWString& strDefPage,
        uint64_t defaultsessionid,
        uint64_t xmlthreadid) = 0;
};


class CAW_OS_EXPORT IXmlEngine : public IAWReferenceControl
{
public:
    virtual CAWResult StartEngine(const CAWString &strDefPage,IXmlEngineSink *psink) = 0;
     virtual CAWResult StoptEngine() = 0;

    virtual uint64_t CreateBundleAPP(const CAWString &strDefPage, XMLParams &params) = 0;

    virtual CAWResult DestroyBundleAPP(uint64_t sessionid)=0;

    virtual CAWResult PostXMLEvent(uint64_t sessionid, 
                                uint64_t objectid,
                                const CAWString & eventname, 
                                XMLParams &params,
                                CAWMessageBlock &pmsgblock) = 0;

    virtual CAWResult SendXMLEvent(uint64_t sessionid, 
                                uint64_t objectid,
                                const CAWString & eventname, 
                                XMLParams &params,
                                CAWMessageBlock &pmsgblock) = 0;

    virtual long GetMainBundleId() = 0;

    virtual void AddIncludePath(const CAWString &strpath) = 0;

    virtual CAWString PrintObjectInfo() = 0;

    virtual CAWResult SetValueUChar(const CAWString &arg1,unsigned char arg2)=0;
    virtual CAWResult SetValueShort(const CAWString &arg1,short arg2)=0;
    virtual CAWResult SetValueUShort(const CAWString &arg1,unsigned short arg2)=0;
    virtual CAWResult SetValueInt(const CAWString &arg1,int arg2)=0;
    virtual CAWResult SetValueUInt(const CAWString &arg1,unsigned int arg2)=0;
    virtual CAWResult SetValueLong(const CAWString &arg1,long arg2)=0;
    virtual CAWResult SetValueULong(const CAWString &arg1,unsigned long arg2)=0;
    virtual CAWResult SetValueLongLong(const CAWString &arg1,long long arg2)=0;
    virtual CAWResult SetValueULongLong(const CAWString &arg1,unsigned long long arg2)=0;
    virtual CAWResult SetValueFloat(const CAWString &arg1,float arg2)=0;
    virtual CAWResult SetValueDouble(const CAWString &arg1,double arg2)=0;
    virtual CAWResult SetValueBool(const CAWString &arg1,bool arg2)=0;
    virtual CAWResult SetValueString(const CAWString &arg1,const CAWString &arg2)=0;
    virtual CAWResult SetValueBytes(const CAWString &arg1,char *buffer, size_t buffersize)=0;
    virtual CAWResult SetValueMessageBlock(const CAWString &arg1,char *buffer, size_t buffersize)=0;
    virtual CAWResult SetValuePython(const CAWString &arg1,PyObject *arg2)=0;
    virtual CAWResult GetValueUChar(const CAWString &arg1,unsigned char& arg2)=0;
    virtual CAWResult GetValueShort(const CAWString &arg1,short &arg2)=0;
    virtual CAWResult GetValueUShort(const CAWString &arg1,unsigned short &arg2)=0;
    virtual CAWResult GetValueInt(const CAWString &arg1, int &arg2)=0;
    virtual CAWResult GetValueUInt(const CAWString &arg1,unsigned int &arg2)=0;
    virtual CAWResult GetValueLong(const CAWString &arg1,long &arg2)=0;
    virtual CAWResult GetValueULong(const CAWString &arg1,unsigned long &arg2)=0;
    virtual CAWResult GetValueLongLong(const CAWString &arg1,long long &arg2)=0;
    virtual CAWResult GetValueULongLong(const CAWString &arg1,unsigned long long &arg2)=0;
    virtual CAWResult GetValueFloat(const CAWString &arg1,float &arg2)=0;
    virtual CAWResult GetValueDouble(const CAWString &arg1,double &arg2)=0;
    virtual CAWResult GetValueBool(const CAWString &arg1,bool &arg2)=0;
    virtual CAWResult GetValueString(const CAWString &arg1,CAWString &arg2)=0;
    virtual CAWResult GetValueStringFromBytes(const CAWString &arg1,char *&buffer, size_t &buffersize)=0;
    virtual CAWResult GetValueBytesFromString(const CAWString &arg1,CAWString &arg2)=0;
    virtual CAWResult GetValueBytes(const CAWString &arg1,char *&buffer, size_t &buffersize)=0;
    virtual CAWResult GetValueBytesFromMessageBlock(const CAWString &arg1,CAWMessageBlock *&arg2)=0;
    virtual CAWResult GetValueChar(const CAWString &arg1, char &arg2)=0;
    virtual CAWResult GetValueOneStr(const CAWString &arg1, int &arg2)=0;
    virtual CAWResult GetValuePython(const CAWString &arg1,PyObject *&arg2)=0;
    virtual CAWResult Log(const CAWString &arg1,int level)=0;

    virtual uint64_t GetXmlThreadId()=0;
    virtual void ActiveThread() = 0;
    virtual void DeactiveThread() = 0;
    virtual CAWResult SimplePostXMLEvent(const CAWString& eventname, 
        const CAWString& eventdata)=0;
    virtual CAWResult PythonRunSimpleFile(const CAWString& filename) = 0;
    virtual CAWResult PythonRunSimpleString(const CAWString& strsrc) = 0;
    virtual CAWResult StarLangRunSimpleString(const CAWString& strsrc) = 0;
    virtual CAWResult StarLangRunSimpleFile(const CAWString& strsrc) = 0;
    virtual CAWResult RunXmlFuntion(const CAWString& funtionname) = 0;

    virtual CAWResult SetPythonLibPath(const CAWString& strpath) = 0;
    virtual CAWString GetPythonLibPath() = 0;

    virtual CAWResult SetDyMudulePath(const CAWString& strpath) = 0;
protected:
    virtual ~IXmlEngine(){}
};

class CAW_OS_EXPORT IXmlEngineManager
{
public:
    static IXmlEngineManager *Instance();
    virtual const CAWString &GetXmlEngineHome() const = 0;
    virtual CAWResult InitXmlEngine(const CAWString& xmlengineroot,
        const CAWString& xmlincludepath,
        const CAWString& pythonpath,
        const CAWString& xmlmodulepath,
        bool enablepython=true) =0;
    virtual CAWResult CreateXmlEngine(CAWAutoPtr<IXmlEngine> &xmlengine) = 0;
    virtual CAWResult SetPythonLibPath(const CAWString &strpath)=0;
    virtual CAWResult RemovePythonLibPath(const CAWString& strpath) = 0;
    virtual void GetAllPythonLibPath(std::list<CAWString> &pythonpath) = 0;
    virtual CAWResult UnInitXmlEngine() = 0;
    //virtual PyThreadState* GetMainPyThreadState()=0;
    virtual CAWResult CreateThread(const CAWString& threadpage, uint64_t threadid) = 0;
    virtual CAWResult DestroyThread(uint64_t threadid) = 0;
    virtual CAWResult ActiveThread(uint64_t threadid) = 0;
    virtual CAWResult DeactiveThread(uint64_t threadid) = 0;
    virtual CAWResult SimplePostXMLEvent(uint64_t threadid,
        const CAWString& eventname, 
        const CAWString& eventdata) = 0;
    virtual CAWResult PostXMLEvent(uint64_t threadid,
                            uint64_t sessionid,
                            uint64_t objectid,
                            const CAWString& eventname,
                            XMLParams& params,
                            CAWMessageBlock& pmsgblock) = 0;
    virtual CAWResult MainThread(const CAWString& threadpage) = 0;
    virtual uint64_t GetMainXmlThreadId() = 0;
    virtual size_t GetThreadSize() = 0;
    virtual CAWResult MainPythonRunSimpleFile(const CAWString& filename) = 0;
    virtual CAWResult MainPythonRunSimpleString(const CAWString& strsrc) = 0;

    virtual CAWResult MainXmlEnginePythonRunSimpleFile(const CAWString& filename) = 0;
    virtual CAWResult MainXmlEnginePythonRunSimpleString(const CAWString& strsrc) = 0;
    virtual CAWResult MainXmlEngineStarLangRunSimpleFile(const CAWString& filename) = 0;
    virtual CAWResult MainXmlEngineStarLangRunSimpleString(const CAWString& strsrc) = 0;

    virtual CAWResult PythonRunSimpleFile(IXmlEngine* pengine, const CAWString& filename) = 0;
    virtual CAWResult PythonRunSimpleString(IXmlEngine* pengine, const CAWString& strsrc) = 0;
    virtual CAWResult StarLangRunSimpleFile(IXmlEngine* pengine, const CAWString& filename) = 0;
    virtual CAWResult StarLangRunSimpleString(IXmlEngine* pengine, const CAWString& strsrc) = 0;
    virtual IXmlEngine* GetMainXmlEngine() = 0;
    virtual CAWResult AddIncludePath(const CAWString& libpath) = 0;
    virtual CAWResult RemoveIncludePath(const CAWString& libpath) = 0;
    virtual void GetAllIncludePath(std::list<CAWString>& includepath) = 0;
    virtual void AddDynamicModulePath(const CAWPathName& modulepath) = 0;
    virtual void RemoveDynamicModulePath(const CAWPathName& modulepath) = 0;
    virtual void GetAllDyModulePath(std::list<CAWString>& listpath) = 0;
    virtual bool GetIsEnablePython() = 0;
protected:
    virtual ~IXmlEngineManager(){}
};
}

#endif /* IXMLENGINE_H */

