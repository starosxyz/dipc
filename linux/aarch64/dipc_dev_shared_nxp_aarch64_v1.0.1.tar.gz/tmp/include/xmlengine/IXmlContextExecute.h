#ifndef IXMLCONTEXTEXECUTE_H
#define IXMLCONTEXTEXECUTE_H
#include "starbase/CAWStarBase.h"
#include "starbase/CAWString.h"
#include "starbase/CAWMessageBlock.h"
#include "xmlengine/IXmlEngine.h"
#include "IXmlObjectType.h"
namespace xmlengine
{
class CAW_OS_EXPORT IXmlContextExecute
{
public:
	virtual ~IXmlContextExecute(){}
	virtual IXmlEngine* GetXmlEngine() = 0;
	virtual CAWResult String2UInt32(const CAWString& strid,uint32_t& nout)=0;
	virtual long GetCurrentSessionId()=0;
	virtual uint64_t GetCurrentClassObjectId()=0;
	virtual CAWString GetContent()=0;
	virtual CAWString StringEvaluate(const CAWString& strvalue)=0;
	virtual CAWResult GetMessageBlock(const CAWString& strmsgblock, CAWMessageBlock **msgblock)=0;
	virtual CAWResult GetParams(const CAWString& strparamname, XMLParams& params)=0;
	virtual CAWResult SetValue(const CAWString& strname, const CAWString& value) = 0;
	virtual CAWResult SetValue(const CAWString& strname, long value) = 0;
	virtual CAWResult SetValue(const CAWString& strname, CAWAutoPtr<IXmlObjectType> &object) = 0;
	virtual CAWResult GetValue(const CAWString& strname, CAWString& value) = 0;
	virtual CAWResult GetValue(const CAWString& strname, long &value) = 0;
	virtual CAWResult GetValue(const CAWString& strname, CAWAutoPtr<IXmlObjectType> &object) = 0;
	virtual CAWResult GetObjectHoldDataType(const CAWString& name, IXmlObjectType*& datatype) = 0;
};
}//namespace xmlengine
#endif /* IXMLCONTEXT_H */
