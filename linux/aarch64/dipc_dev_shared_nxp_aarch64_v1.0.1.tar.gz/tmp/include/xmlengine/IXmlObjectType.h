#ifndef IXMLOBJECTTYPE_H
#define IXMLOBJECTTYPE_H
#include "starbase/CAWStarBase.h"
using namespace starbase;
namespace xmlengine
{
class CAW_OS_EXPORT IXmlObjectType : public IAWReferenceControl
{
public:
protected:
    virtual ~IXmlObjectType() {}
};
}
#endif//IXMLOBJECTTYPE_H