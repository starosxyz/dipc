import unittest
from . import load_tests

unittest.main()
