# test iso-8859-1 encoding
# -*- encoding: iso-8859-1 -*-
test = ("Les hommes ont oubli� cette v�rit�, "
        "dit le renard. Mais tu ne dois pas l'oublier. Tu deviens "
        "responsable pour toujours de ce que tu as apprivois�.")
