#ifndef SNAPPY_INCLUDE_EXPORT_H_
#define SNAPPY_INCLUDE_EXPORT_H_

#if !defined(SNAPPY_EXPORT)

#if defined(SNAPPY_SHARED_LIBRARY)
#if defined(_WIN32)

#if defined(SNAPPY_COMPILE_LIBRARY)
#define SNAPPY_EXPORT __declspec(dllexport)
#else
#define SNAPPY_EXPORT __declspec(dllimport)
#endif  // defined(SNAPPY_COMPILE_LIBRARY)

#else  // defined(_WIN32)
#if defined(SNAPPY_COMPILE_LIBRARY)
#define SNAPPY_EXPORT __attribute__((visibility("default")))
#else
#define SNAPPY_EXPORT
#endif
#endif  // defined(_WIN32)

#else  // defined(SNAPPY_SHARED_LIBRARY)
#define SNAPPY_EXPORT
#endif

#endif  // !defined(SNAPPY_EXPORT)

#endif  // STORAGE_SNAPPY_INCLUDE_EXPORT_H_
