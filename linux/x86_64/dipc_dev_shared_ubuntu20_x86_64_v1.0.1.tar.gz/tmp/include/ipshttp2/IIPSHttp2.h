/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IIPSHTTP2_H
#define IIPSHTTP2_H
#include "starbase/CAWStarBase.h"
#include "utilsex/Http2Headers.h"
#include "ipstacktp/IPSConnectionInterface.h"
using namespace starbase;
using namespace utilsex;
using namespace ipstacktp;
namespace ipshttp2
{
class IIPSHttp2AcceptorSink;
class IIPSHttp2SessionSink;
class IIPSHttp2StreamSink;
class IIPSHttp2Session;
class IIPSHttp2Stream;
class IIPSHttp2SessionClient;
class CAW_OS_EXPORT IIPSHttp2ClientSink
{
public:
    /// Channel is connected.
    virtual void OnSesstionConnected(CAWResult aReason, CAWAutoPtr<IIPSHttp2Session> &psession) = 0;
protected:
    virtual ~IIPSHttp2ClientSink() { }
};

class CAW_OS_EXPORT IIPSHttp2Client : public IAWReferenceControl
{
public:
    virtual CAWResult AsyncOpen(const CAWString& strURL,
        IIPSHttp2ClientSink* aSink,
        CAWTimeValue* timeout = NULL) = 0;
    virtual CAWResult GetUrlPath(CAWString& strURLPath) = 0;
    virtual CAWResult SetUrlPath(const CAWString& strURLPath) = 0;
    virtual CAWResult PrivateKey(const CAWString& file_name) = 0;
    virtual CAWResult Certificate(const CAWString& file_name) = 0;
    virtual CAWResult CancelConnect(CAWResult rv) = 0;
protected:
    virtual ~IIPSHttp2Client() { }
};

class CAW_OS_EXPORT IIPSHttp2StreamSink
{
public:
    virtual void OnHeaders(Http2Headers &headers) = 0;
    virtual void OnDataEndStream() = 0;
    virtual void OnStreamDataChunkRecv(CAWMessageBlock& aData, IIPSHttp2Stream* pstream) = 0;
    virtual void OnStreamDisconnect(CAWResult aReason,IIPSHttp2Stream* pstream) = 0;
protected:
    virtual ~IIPSHttp2StreamSink() { }
};

class CAW_OS_EXPORT IIPSHttp2Stream : public IAWReferenceControl
{
public:
    virtual CAWResult GetAllRequestHeaders(Http2Headers& headers) = 0;
    virtual CAWResult GetAllResponseHeaders(Http2Headers& headers) = 0;
    virtual CAWResult OpenWithSink(IIPSHttp2StreamSink* aSink) = 0;
    virtual CAWResult ClearResponseHeader() = 0;
    virtual CAWResult ClearRequestHeader() = 0;
    virtual CAWResult SetOrAddResponseHeader(
        const CAWString& aHeader,
        const CAWString& aValue) = 0;
    virtual CAWResult SetOrAddRequestHeader(
        const CAWString& aHeader,
        const CAWString& aValue) = 0;
    virtual CAWResult RemoveRequestHeader(
        const CAWString& aHeader) = 0;
    virtual CAWResult RemoveResponseHeader(
        const CAWString& aHeader) = 0;
    virtual CAWResult SetResponseStatus(
        DWORD aStatus,
        const CAWString& aText) = 0;
    virtual CAWResult GetResponseStatus(LONG& aStatus) = 0;
    virtual CAWResult GetRequestMethod(CAWString& aMethod) = 0;
    virtual CAWResult SetRequestMethod(const CAWString& aMethod) = 0;
    virtual CAWResult GetRequestHeader(
        const CAWString& aHeader,
        CAWString& aValue) = 0;
    virtual CAWResult GetResponseHeader(
        const CAWString& aHeader,
        CAWString& aValue) = 0;
    virtual CAWResult GetRequestPath(CAWString& aPath) = 0;
    virtual CAWResult SendResponse(uint32_t status, 
        CAWMessageBlock& aData, 
        Http2Headers& headers,
        bool endstream=true) = 0;
    virtual int32_t GetStreamId() = 0;
    virtual CAWResult SetRequestPath(const CAWString& aPath) = 0;
    virtual const CAWString& GetAuthority() const = 0;
    virtual const CAWString& GetScheme() const = 0;
    virtual void SetAuthority(const CAWString& strauth) = 0;
    virtual void SetScheme(const CAWString& scheme) = 0;
    virtual CAWResult SubmitTrailers() = 0;
    virtual CAWResult SubmitHeaders(Http2Headers& headers) = 0;
    virtual CAWResult SubmitTrailers(Http2Headers& headers) = 0;
    virtual CAWResult SubmitData(CAWMessageBlock& aData,bool isendstream=false) = 0;
    virtual CAWResult SubmitDataWithoutTrailers(CAWMessageBlock& aData) = 0;
    virtual CAWResult StreamDisconnect(CAWResult rv) = 0;
    virtual ~IIPSHttp2Stream() { }
};

class CAW_OS_EXPORT IIPSHttp2SessionSink
{
public:
    virtual void OnStreamCreate(CAWAutoPtr<IIPSHttp2Stream> &pstream) = 0;
    virtual void OnSessionDisconnect(IIPSHttp2Session *psession) = 0;
protected:
    virtual ~IIPSHttp2SessionSink() { }
};

class CAW_OS_EXPORT IIPSHttp2Session : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IIPSHttp2SessionSink* aSink) = 0;
    //virtual void DestroyStream(int32_t streamid) = 0;
    virtual CAWResult OpenRequestStream(const CAWString& method,
        CAWMessageBlock& aData,
        Http2Headers& headers) = 0;
    //virtual void DestroyStream(IAWHttp2Stream *pstream) = 0;
    //virtual IAWHttp2Stream* FindStream(int32_t streamid) = 0;
    virtual CAWResult SessionDisconnect(CAWResult aReason) = 0;
    virtual CAWResult SendRequest(const CAWString& method,
        CAWMessageBlock& aData,
        Http2Headers& headers) = 0;
protected:
    virtual ~IIPSHttp2Session() { }
};

class CAW_OS_EXPORT IIPSHttp2Acceptor : public IAWReferenceControl
{
public:
    virtual CAWResult StartListen(
        IIPSHttp2AcceptorSink* aSink,
        const CAWInetAddr& aAddrListen) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;
    virtual CAWResult PrivateKey(const CAWString& file_name) = 0;
    virtual CAWResult Certificate(const CAWString& file_name) = 0;

protected:
    virtual ~IIPSHttp2Acceptor() {}
};

class CAW_OS_EXPORT IIPSHttp2AcceptorSink
{
public:
    virtual void OnSessionCreation(CAWAutoPtr<IIPSHttp2Session> &aServer) = 0;
protected:
    virtual ~IIPSHttp2AcceptorSink() { }
};
class CAW_OS_EXPORT IIPSHttp2
{
public:
    static IIPSHttp2* Instance();
    virtual CAWResult CreateHttp2Connector(
                CAWAutoPtr<IIPSHttp2Client> &aClient) = 0;

    virtual CAWResult CreateHttp2Acceptor(CAWAutoPtr<IIPSHttp2Acceptor> &aAcceptor,
        const CAWString &cerfile,
        const CAWString &keyfile) = 0;
protected:
    virtual ~IIPSHttp2() {}
};
}//starhttp2

#endif // ISTARHTTP2_H
