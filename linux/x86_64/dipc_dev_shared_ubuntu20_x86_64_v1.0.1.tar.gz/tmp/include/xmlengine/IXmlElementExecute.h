#ifndef IXMLELEMENTEXECUTE_H
#define IXMLELEMENTEXECUTE_H
#include "starbase/CAWStarBase.h"
#include "starbase/CAWString.h"
#include "starbase/CAWMessageBlock.h"
#include "xmlengine/IXmlContextExecute.h"
#include "xmlengine/IXmlEngine.h"
namespace xmlengine
{
class CAW_OS_EXPORT IXmlElementExecute
{
public:
	virtual ~IXmlElementExecute(){}
    virtual CAWResult Execute(IXmlContextExecute *pelement)=0;
    virtual CAWString GetElementName() = 0;
    virtual void OnStartElement(const XMLParams& params) = 0;
    virtual void OnEndElement(const CAWString& element) = 0;
    virtual void OnCharacterData(const CAWString& data) = 0;
    virtual CAWString GetHelp() = 0;
    virtual IXmlElementExecute* Clone() = 0;
};
}

#endif /* IXMLELEMENTEXECUTE_H */
