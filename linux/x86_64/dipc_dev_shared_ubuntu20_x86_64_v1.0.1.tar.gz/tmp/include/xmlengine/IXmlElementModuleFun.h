#ifndef IXMLELEMENTMODULEFUN_H
#define IXMLELEMENTMODULEFUN_H
#include "xmlengine/IXmlElementExecute.h"
namespace xmlengine
{
#if defined(__cplusplus)
#    define XML_MODINIT_FUNC extern "C" CAW_OS_EXPORT IXmlElementExecute*
#else /* __cplusplus */
#    define XML_MODINIT_FUNC CAW_OS_EXPORT IXmlElementExecute*
#endif /* __cplusplus */
}
#endif//IXMLELEMENTMODULEFUN_H