/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef ISTARHTTP2_H
#define ISTARHTTP2_H
#include "starbase/CAWStarBase.h"
#include "shttp/IAWHttpManager.h"
#include "utilsex/Http2Headers.h"
using namespace starbase;
using namespace shttp;
using namespace utilsex;
namespace starhttp2
{
class IAWHttp2AcceptorSink;
class IAWHttp2SessionSink;
class IAWHttp2StreamSink;
class IAWHttp2Session;
class IAWHttp2Stream;
class IAWHttp2SessionClient;
class CAW_OS_EXPORT IAWHttp2ClientSink
{
public:
    /// Channel is connected.
    virtual void OnSesstionConnected(CAWResult aReason, CAWAutoPtr<IAWHttp2Session> &psession) = 0;
protected:
    virtual ~IAWHttp2ClientSink() { }
};

class CAW_OS_EXPORT IAWHttp2Client : public IAWReferenceControl
{
public:
    virtual CAWResult AsyncOpen(const CAWString& strURL,
        IAWHttp2ClientSink* aSink,
        CAWTimeValue* timeout = NULL) = 0;
    virtual CAWResult GetUrlPath(CAWString& strURLPath) = 0;
    virtual CAWResult SetUrlPath(const CAWString& strURLPath) = 0;
    virtual CAWResult PrivateKey(const CAWString& file_name) = 0;
    virtual CAWResult Certificate(const CAWString& file_name) = 0;
    virtual CAWResult CancelConnect(CAWResult rv) = 0;
protected:
    virtual ~IAWHttp2Client() { }
};

class CAW_OS_EXPORT IAWHttp2StreamSink
{
public:
    virtual void OnHeaders(Http2Headers &headers) = 0;
    virtual void OnDataEndStream() = 0;
    virtual void OnStreamDataChunkRecv(CAWMessageBlock& aData, IAWHttp2Stream* pstream) = 0;
    virtual void OnStreamDisconnect(CAWResult aReason,IAWHttp2Stream* pstream) = 0;
protected:
    virtual ~IAWHttp2StreamSink() { }
};

class CAW_OS_EXPORT IAWHttp2Stream : public IAWReferenceControl
{
public:
    virtual CAWResult GetAllRequestHeaders(Http2Headers& headers) = 0;
    virtual CAWResult GetAllResponseHeaders(Http2Headers& headers) = 0;
    virtual CAWResult OpenWithSink(IAWHttp2StreamSink* aSink) = 0;
    virtual CAWResult ClearResponseHeader() = 0;
    virtual CAWResult ClearRequestHeader() = 0;
    virtual CAWResult SetOrAddResponseHeader(
        const CAWString& aHeader,
        const CAWString& aValue) = 0;
    virtual CAWResult SetOrAddRequestHeader(
        const CAWString& aHeader,
        const CAWString& aValue) = 0;
    virtual CAWResult RemoveRequestHeader(
        const CAWString& aHeader) = 0;
    virtual CAWResult RemoveResponseHeader(
        const CAWString& aHeader) = 0;
    virtual CAWResult SetResponseStatus(
        DWORD aStatus,
        const CAWString& aText) = 0;
    virtual CAWResult GetResponseStatus(LONG& aStatus) = 0;
    virtual CAWResult GetRequestMethod(CAWString& aMethod) = 0;
    virtual CAWResult SetRequestMethod(const CAWString& aMethod) = 0;
    virtual CAWResult GetRequestHeader(
        const CAWString& aHeader,
        CAWString& aValue) = 0;
    virtual CAWResult GetResponseHeader(
        const CAWString& aHeader,
        CAWString& aValue) = 0;
    virtual CAWResult GetRequestPath(CAWString& aPath) = 0;
    virtual CAWResult SendResponse(uint32_t status, 
        CAWMessageBlock& aData, 
        Http2Headers& headers,
        bool endstream=true) = 0;
    virtual int32_t GetStreamId() = 0;
    virtual CAWResult SetRequestPath(const CAWString& aPath) = 0;
    virtual const CAWString& GetAuthority() const = 0;
    virtual const CAWString& GetScheme() const = 0;
    virtual void SetAuthority(const CAWString& strauth) = 0;
    virtual void SetScheme(const CAWString& scheme) = 0;
    virtual CAWResult SubmitTrailers() = 0;
    virtual CAWResult SubmitHeaders(Http2Headers& headers) = 0;
    virtual CAWResult SubmitTrailers(Http2Headers& headers) = 0;
    virtual CAWResult SubmitData(CAWMessageBlock& aData,bool isendstream=false) = 0;
    virtual CAWResult SubmitDataWithoutTrailers(CAWMessageBlock& aData) = 0;
    virtual CAWResult StreamDisconnect(CAWResult rv) = 0;
    virtual ~IAWHttp2Stream() { }
};

class CAW_OS_EXPORT IAWHttp2SessionSink
{
public:
    virtual void OnStreamCreate(CAWAutoPtr<IAWHttp2Stream> &pstream) = 0;
    virtual void OnSessionDisconnect(IAWHttp2Session *psession) = 0;
protected:
    virtual ~IAWHttp2SessionSink() { }
};

class CAW_OS_EXPORT IAWHttp2Session : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWHttp2SessionSink* aSink) = 0;
    //virtual void DestroyStream(int32_t streamid) = 0;
    virtual CAWResult OpenRequestStream(const CAWString& method,
        CAWMessageBlock& aData,
        Http2Headers& headers) = 0;
    //virtual void DestroyStream(IAWHttp2Stream *pstream) = 0;
    //virtual IAWHttp2Stream* FindStream(int32_t streamid) = 0;
    virtual CAWResult SessionDisconnect(CAWResult aReason) = 0;
    virtual CAWResult SendRequest(const CAWString& method,
        CAWMessageBlock& aData,
        Http2Headers& headers) = 0;
protected:
    virtual ~IAWHttp2Session() { }
};

class CAW_OS_EXPORT IAWHttp2Acceptor : public IAWReferenceControl
{
public:
    virtual CAWResult StartListen(
        IAWHttp2AcceptorSink* aSink,
        const CAWInetAddr& aAddrListen) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;
    virtual CAWResult PrivateKey(const CAWString& file_name) = 0;
    virtual CAWResult Certificate(const CAWString& file_name) = 0;

protected:
    virtual ~IAWHttp2Acceptor() {}
};

class CAW_OS_EXPORT IAWHttp2AcceptorSink
{
public:
    virtual void OnSessionCreation(CAWAutoPtr<IAWHttp2Session> &aServer) = 0;
protected:
    virtual ~IAWHttp2AcceptorSink() { }
};
class CAW_OS_EXPORT IStarHttp2
{
public:
    static IStarHttp2* Instance();
    virtual CAWResult CreateHttp2Connector(
                CAWAutoPtr<IAWHttp2Client> &aClient) = 0;

    virtual CAWResult CreateHttp2Acceptor(CAWAutoPtr<IAWHttp2Acceptor> &aAcceptor,
        const CAWString &cerfile,
        const CAWString &keyfile) = 0;
protected:
    virtual ~IStarHttp2() {}
};
}//starhttp2

#endif // ISTARHTTP2_H
