/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef CAWPTCPSTREAMBASE_H
#define CAWPTCPSTREAMBASE_H
#include "wface/CAWACEWrapper.h"
#include "ptcp/IAWPseudoTCPManager.h"
using namespace wface;
namespace ptcp
{
class CAW_OS_EXPORT CAWPTCPStreamBase : public IAWPseudoTCPTransportSink
   // ,public CAWReferenceControlMutilThreadTimerDelete
{ 
public: 
    CAWPTCPStreamBase();
    virtual ~CAWPTCPStreamBase();

    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWPseudoTCPTransport *aTrptId,
        CAWPseudoTCPTransportParameter *aPara = NULL);

    virtual void OnSend(
        IAWPseudoTCPTransport *aTrptId,
        CAWPseudoTCPTransportParameter *aPara = NULL);

    virtual void OnDisconnect(
        CAWResult aReason,
        IAWPseudoTCPTransport *aTrptId);


    virtual CAWResult SendPTCPData(CAWMessageBlock &aData, CAWPseudoTCPTransportParameter *pparam=NULL);

    virtual WORD16 HandleMessage(CAWMessageBlock &aData) = 0;
    virtual void OnPeerDisconnect(CAWResult aReason) = 0;
    
    virtual CAWResult SetTransportHandle(CAWAutoPtr<IAWPseudoTCPTransport> &pTransport);

    virtual CAWResult Disconnect(CAWResult reason);

    void SetSendBufferSize(WORD32 bufferSize);
    void SetRcvBufferSize(WORD32 bufferSize);

    void GetPeerIP(CAWString &ip);
    
    void GetLocalIP(CAWString &ip);
    
    WORD16 GetPeerPort();
    
    WORD16 GetLocalPort();
    
    const CAWInetAddr &GetPeerAddr() const;
    const CAWInetAddr &GetLocalAddr() const;
    
protected:
    CAWAutoPtr<IAWPseudoTCPTransport> m_pTransport;
    CAWMessageBlock *           m_pBlocks;
    CAWMessageBlock *           m_pMbSendBuf;
    WORD32                      m_dwSendBufMaxLen;
    WORD32                      m_dwRcvBufMaxLen;
    CAWInetAddr                 m_addrPeer;
    CAWInetAddr                 m_addrLocal;
    bool m_isClose;
};
}//namespace ptcp

#endif /* CAWPTCPSTREAMBASE_H */

