/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IAWPSEUDOTCPMANAGER_H
#define IAWPSEUDOTCPMANAGER_H
#include "starbase/CAWStarBase.h"
#include "wface/CAWACEWrapper.h"
using namespace starbase;
using namespace wface;
namespace ptcp
{
class IAWPseudoTCPAcceptorConnectorSink;
class IAWPseudoTCPTransportSink;
  class IAWPseudoTCPTransport;
  class IAWPseudoTCPAcceptorConnectorId;
    class IAWPseudoTCPConnector;
    class IAWPseudoTCPAcceptor;
    class IAWPseudoTCPHybrid;

    class IAWPseudoTCPNotify;
    class IAWPseudoTCP;

class CAW_OS_EXPORT IAWPseudoTCPManager
{
public:
    static IAWPseudoTCPManager &Instance();
    virtual ~IAWPseudoTCPManager(){}
    /** \brief 创建PTCP客户端
    * @param aClient  输出客户端对象
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult CreatePseudoTCPConnector(CAWAutoPtr<IAWPseudoTCPConnector> &aClient) = 0;   
    /** \brief 创建PTCP服务器端
    * @param aClient  输出服务器对象
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult CreatePseudoTCPAcceptor(CAWAutoPtr<IAWPseudoTCPAcceptor> &aAcceptor) = 0;
    /** \brief 创建PTCP服务器端/客户端混合模式
    * @param aClient  输出服务器对象
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult CreatePseudoTCPHybrid(CAWAutoPtr<IAWPseudoTCPHybrid> &aAcceptor) = 0;

    virtual CAWResult CreatePTCP(CAWAutoPtr<IAWPseudoTCP> &ptcp) = 0;
};
class CAW_OS_EXPORT IAWPseudoTCP : public IAWReferenceControl
{
public:
    enum TcpState {
    	TCP_LISTEN, TCP_SYN_SENT, TCP_SYN_RECEIVED, TCP_ESTABLISHED, TCP_CLOSED
    };
    virtual int Recv(char* buffer, size_t len) = 0;
    virtual int Send(const char* buffer, size_t len) = 0;
    virtual void Close(bool force) = 0;
    virtual int GetError() = 0;
    virtual TcpState State() const = 0;
    virtual void Open(IAWPseudoTCPNotify* notify, uint32_t conv) = 0;
    virtual int Connect() = 0;
    virtual void NotifyMTU(uint16_t mtu)=0;
    virtual void adjustMTU() = 0;
    virtual void NotifyClock(uint32_t now)=0;
    virtual bool GetNextClock(uint32_t now, long& timeout)=0;
    virtual bool NotifyPacket(const char* buffer, size_t len) = 0;
protected:
    virtual ~IAWPseudoTCP() { }
};

class CAW_OS_EXPORT IAWPseudoTCPNotify
{
public:
    // Notification of tcp events
    virtual void OnTcpOpen(IAWPseudoTCP* tcp) = 0;
    virtual void OnTcpReadable(IAWPseudoTCP* tcp) = 0;
    virtual void OnTcpWriteable(IAWPseudoTCP* tcp) = 0;
    virtual void OnTcpClosed(IAWPseudoTCP* tcp, uint32_t error) = 0;

    // Write the packet onto the network
    enum WriteResult { WR_SUCCESS, WR_TOO_LARGE, WR_FAIL };
    virtual WriteResult TcpWritePacket(IAWPseudoTCP* tcp, const char* buffer, size_t len) = 0;

protected:
    virtual ~IAWPseudoTCPNotify() {}
};
class CAW_OS_EXPORT CAWPseudoTCPTransportParameter
{
public:
    CAWPseudoTCPTransportParameter()
        : m_dwHaveSent(0)
    {
    }

    DWORD m_dwHaveSent;
};


class CAW_OS_EXPORT IAWPseudoTCPAcceptorConnectorSink
{
public:
    /** \brief 当连接成功或者服务器端又连接到来，回调执行函数
    * @param aReason    连接建立是否成功
    * @param aTrpt      连接建立传输对象
    * @param aTrpt      其他对象
    * @return  void--   无返回值
    */
    virtual void OnPseudoTCPConnectIndication(        CAWResult aReason,
            IAWPseudoTCPTransport *aTrpt,
            IAWPseudoTCPAcceptorConnectorId *aRequestId) = 0;

protected:
    virtual ~IAWPseudoTCPAcceptorConnectorSink() { }
};

class CAW_OS_EXPORT IAWPseudoTCPTransportSink 
{
public:
    /** \brief 当连接成功或者服务器端又连接到来，回调执行函数
    * @param aReason    连接建立是否成功
    * @param aTrpt      连接建立传输对象
    * @param aTrpt      其他对象
    * @return  void--   无返回值
    */
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWPseudoTCPTransport *aTrptId,
        CAWPseudoTCPTransportParameter *aPara = NULL) = 0;

    virtual void OnSend(
        IAWPseudoTCPTransport *aTrptId,
        CAWPseudoTCPTransportParameter *aPara = NULL) = 0;

    virtual void OnDisconnect(
    CAWResult aReason,
    IAWPseudoTCPTransport *aTrptId) = 0;

protected:
    virtual ~IAWPseudoTCPTransportSink() {}
};

class CAW_OS_EXPORT IAWPseudoTCPTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWPseudoTCPTransportSink *aSink) = 0;

    virtual IAWPseudoTCPTransportSink* GetSink() = 0;
    virtual CAWResult SendData(CAWMessageBlock &aData, CAWPseudoTCPTransportParameter *aPara = NULL) = 0;
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;

    virtual CAWResult Disconnect(CAWResult aReason) = 0;
    virtual CAWInetAddr GetPeerAddr() = 0;
    virtual CAWInetAddr GetLocalAddr() = 0;

protected:
    virtual ~IAWPseudoTCPTransport() {}
};


class CAW_OS_EXPORT IAWPseudoTCPAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWPseudoTCPAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWPseudoTCPConnector : public IAWPseudoTCPAcceptorConnectorId
{
public:
    virtual void AsycConnect(       
        IAWPseudoTCPAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrPeer,
        CAWTimeValue *aTimeout = NULL,
        CAWInetAddr *aAddrLocal = NULL) = 0;

    virtual void CancelConnect() = 0;

protected:
    virtual ~IAWPseudoTCPConnector() {}

};


class CAW_OS_EXPORT IAWPseudoTCPAcceptor : public IAWPseudoTCPAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IAWPseudoTCPAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

protected:
    virtual ~IAWPseudoTCPAcceptor() {}
};


class CAW_OS_EXPORT IAWPseudoTCPHybrid : public IAWPseudoTCPAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IAWPseudoTCPAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen,
        bool isudp=false) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

    virtual void AsycConnect(
        const CAWInetAddr &aAddrPeer,
        CAWTimeValue *aTimeout = NULL,
        bool isudp=false) = 0;

    virtual void ListenConnect(const CAWInetAddr &aAddrPeer) = 0;
    virtual void CancelConnect(const CAWInetAddr &aAddrPeer) = 0;
protected:
	virtual ~IAWPseudoTCPHybrid() {}
};

class CAW_OS_EXPORT IAWPseudoTCPConnectorInternal
{
public:
    virtual int Connect(const CAWInetAddr &aAddr, CAWInetAddr *aAddrLocal = NULL) = 0;
    virtual int Close() = 0;
    virtual ~IAWPseudoTCPConnectorInternal() { }
};
}/*namespace ptcp*/

#endif // IAWPSEUDOTCPMANAGER_H

