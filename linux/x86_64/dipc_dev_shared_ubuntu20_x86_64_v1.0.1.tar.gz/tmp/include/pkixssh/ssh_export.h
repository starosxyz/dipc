#ifndef SSH_INCLUDE_EXPORT_H_
#define SSH_INCLUDE_EXPORT_H_

#if !defined(SSH_EXPORT)

#if defined(SSH_SHARED_LIBRARY)
#if defined(_WIN32)

#if defined(SSH_COMPILE_LIBRARY)
#define SSH_EXPORT __declspec(dllexport)
#else
#define SSH_EXPORT __declspec(dllimport)
#endif  // defined(SSH_COMPILE_LIBRARY)

#else  // defined(_WIN32)
#if defined(SSH_COMPILE_LIBRARY)
#define SSH_EXPORT __attribute__((visibility("default")))
#else
#define SSH_EXPORT
#endif
#endif  // defined(_WIN32)

#else  // defined(SSH_SHARED_LIBRARY)
#define SSH_EXPORT
#endif

#endif  // !defined(SSH_EXPORT)

#endif  // SSH_INCLUDE_EXPORT_H_
