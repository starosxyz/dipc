/***********************************************************************
    Copyright (C) 2018-2021 南京北星极网络科技有限公司
**********************************************************************/
#ifndef DIPC_VERSION_H
#define DIPC_VERSION_H

#define DIPC_MAJOR_VERSION 			1
#define DIPC_MINOR_VERSION 			0
#define DIPC_BETA_VERSION 			1
#define DIPC_VERSION_STRING 		"1.0.0"
#define DIPC_VERSION				"DIPC_1.0.1"
#define DIPC_PORTABLE				"p1"
#define DIPC_RELEASE				DIPC_VERSION DIPC_PORTABLE

#endif
