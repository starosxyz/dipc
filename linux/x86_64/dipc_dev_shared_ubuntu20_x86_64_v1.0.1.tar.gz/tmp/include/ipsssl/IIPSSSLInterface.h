/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/

#ifndef IIPSSSLINTERFACE_H
#define IIPSSSLINTERFACE_H
#include "starbase/CAWStarBase.h"
#include "ipstacktp/IPSConnectionInterface.h"
using namespace ipstacktp;
using namespace starbase;

namespace ipsssl
{

class IIPSSSLTransportSink;
class IIPSSSLTransport;
class IIPSSSLConnector;
class IIPSSSLAcceptor;
class IIPSSSLConnectionSink;
class CAW_OS_EXPORT IIPSSSLInterface
{
public:
    static IIPSSSLInterface&Instance();
    virtual ~IIPSSSLInterface(){}
    virtual CAWResult CreateSSLConnector(CAWAutoPtr<IIPSSSLConnector> &aClient) = 0;
    virtual CAWResult CreateSSLAcceptor(CAWAutoPtr<IIPSSSLAcceptor> &aAcceptor) = 0;
};

class CAW_OS_EXPORT IIPSSSLTransportSink 
{
public:
    virtual void OnSSLDataReceive(CAWMessageBlock &aData, IIPSSSLTransport *ptrans) = 0;
    virtual void OnSSLDisconnect(CAWResult aReason, IIPSSSLTransport *ptrans) = 0;
    virtual void OnSSLDataSend(IIPSSSLTransport *ptrans)=0;

protected:
    virtual ~IIPSSSLTransportSink() {}
};

class CAW_OS_EXPORT IIPSSSLTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IIPSSSLTransportSink *aSink) = 0;
    virtual CAWResult SendSSLData(const char *pdata, size_t datasize, CPSTransportParameter* aPara = NULL) = 0;
    virtual CAWResult SendSSLData(CAWMessageBlock &aData, CPSTransportParameter *aPara=NULL) = 0;
    virtual CAWResult Disconnect(CAWResult aReason) = 0;
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAW_HANDLE GetTransportHandle() const=0;
    virtual void* GetSSL() = 0;
protected:
    virtual ~IIPSSSLTransport() {}
};

class CAW_OS_EXPORT IIPSSSLAcceptor : public IAWReferenceControl
{
public:
    virtual void SetSSLContext(void* context) = 0;
    virtual CAWResult StartListen(
        IIPSSSLConnectionSink *aSink,
        const CAWInetAddr &aAddrListen,
        IPSConnectionManager::CType type,
        CAWTimeValue *pTimeout=NULL) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;
    virtual CAWResult LoadVerifyLocations(const CAWString &caroot)=0;
    virtual void SetVerifyPeer (int strict = 0, int once = 1, int depth = 0) = 0;
    virtual CAWResult PrivateKey (const CAWString &file_name) = 0;
    virtual CAWResult Certificate (const CAWString &file_name) = 0;
protected:
    virtual ~IIPSSSLAcceptor() {}
};

class CAW_OS_EXPORT IIPSSSLConnector : public IAWReferenceControl
{
public:
    virtual void SetSSLContext(void* context) = 0;
    virtual CAWResult StartConnect(
        IIPSSSLConnectionSink *aSink,
        const CAWInetAddr &aAddrListen,
        IPSConnectionManager::CType type,
        CAWTimeValue *pTimeout=NULL,
        CAWInetAddr *aAddrLocal=NULL) = 0;

    virtual CAWResult StopConnect(CAWResult aReason) = 0;
    virtual CAWResult LoadVerifyLocations(const CAWString &caroot)=0;
    virtual void SetVerifyPeer (int strict = 0, int once = 1, int depth = 0) = 0;
    virtual CAWResult PrivateKey (const CAWString &file_name) = 0;
    virtual CAWResult Certificate (const CAWString &file_name) = 0;

protected:
    virtual ~IIPSSSLConnector() {}
};


class CAW_OS_EXPORT IIPSSSLConnectionSink
{
public:
    virtual void OnSSLConnected(CAWResult result,IIPSSSLTransport *aTransport) = 0;

protected:
    virtual ~IIPSSSLConnectionSink() { }
};
}//namespace ipsssl;

#endif // IAWSSLUTILS_H
