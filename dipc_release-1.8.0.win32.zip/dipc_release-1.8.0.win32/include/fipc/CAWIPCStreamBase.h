/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWIPCSTREAMBASE_H
#define CAWIPCSTREAMBASE_H
#include "CAWACEWrapper.h"
#include "CAWIPCAddr.h"
#include "CAWIPCInterface.h"
#include "CAWUtilTemplates.h"
#include "CAWMessageBlock.h"

class CAW_OS_EXPORT CAWIPCStreamBase : public IAWIPCTransportSink,
                        public IAWIPCAcceptorConnectorSink,
                        public CAWReferenceControlSingleThread
{ 
public: 
    CAWIPCStreamBase();
    virtual ~CAWIPCStreamBase();

    virtual void OnIPCConnectIndication(
        CAWResult aReason,
        IAWIPCTransport *aTrpt,
        IAWIPCAcceptorConnectorId *aRequestId);

    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWIPCTransport *aTrptId,
        CAWIPCTransportParameter *aPara = NULL);

    virtual void OnSend(
        IAWIPCTransport *aTrptId,
        CAWIPCTransportParameter *aPara = NULL);

    virtual void OnDisconnect(
        CAWResult aReason,
        IAWIPCTransport *aTrptId);

    virtual CAWResult Connect(const CAWIPCAddr &peerAddr, CAWIPCAddr *aAddrLocal = NULL);

    virtual CAWResult SendMessage(CAWMessageBlock &aData);
    virtual CAWResult SendMessage(const char *data, size_t datasize);

    virtual size_t HandleMessage(const char *data, size_t datasize) = 0;
    virtual void OnPeerDisconnect(CAWResult aReason) = 0;
    virtual void OnConnected(CAWResult aReason) = 0;
    virtual void OnRcvBufferOverFlow(WORD32 buffersize) = 0;

    bool IsClient(){return m_bIsClient;}

    virtual CAWResult SetTransportHandle(CAWAutoPtr<IAWIPCTransport> &pTransport);

    virtual CAWResult Close(CAWResult reason);

    void SetSendBufferSize(WORD32 bufferSize);
    void SetRcvBufferSize(WORD32 bufferSize);
    
    const CAWIPCAddr &GetPeerAddr() const;
    const CAWIPCAddr &GetLocalAddr() const;
    bool IsSendOverBuffer() const;
    bool IsRcvOverBuffer() const;
    bool IsClosed();
protected:
    CAWAutoPtr<IAWIPCTransport> m_pTransport;
    CAWAutoPtr<IAWIPCConnector> m_pConnector;
    CAWMessageBlock *           m_pMbSendBuf;
    CAWMessageBlock *           m_pMbRcvBuf;
    bool                        m_bConnected;
    bool                        m_bIsClient;
    WORD32                      m_dwSendBufMaxLen;
    WORD32                      m_dwRcvBufMaxLen;
    CAWIPCAddr                  m_addrPeer;
    CAWIPCAddr                  m_addrLocal;
    bool                        m_bisRcvoverbuffer;
    bool                        m_bisSendoverbuffer;
    bool                        m_isClose;
};


#endif /* CAWIPCSTREAMBASE_H */

