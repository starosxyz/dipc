/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CMCONNECTIONINTERFACE_H
#define CMCONNECTIONINTERFACE_H

#include "CAWDefines.h"
#include "CAWReferenceControl.h"
#include "CAWUtilTemplates.h"
#include "CAWMutex.h"

class CAWInetAddr;
class CAWTimeValue;
class CAWMessageBlock;

class IAWAcceptorConnectorSink;
class IAWTransportSink;
class IAWReferenceControl;
  class IAWTransport;
  class IAWRawTransport;
  class IAWAcceptorConnectorId;
    class IAWConnector;
      class IAWDetectionConnector;
    class IAWAcceptor;

class CAW_OS_EXPORT CAWConnectionManager
{
public:
    static CAWConnectionManager* Instance();
    typedef int CReactorType;
    typedef DWORD CType;
    enum { 
        // connection type
        CTYPE_NONE = 0,
        CTYPE_TCP = (1 << 0),
        CTYPE_UDP = (1 << 1),

        // the range of connection type is from (1 << 0) to (1 << 15)
        CTYPE_TYPE_MASK = 0xFFFF,

        // thread module of connection
        // the upper layer prefers invoking and callbacked in network thread. 
        CTYPE_INVOKE_NETWORK_THREAD = (1 << 16),

        // the upper layer will invoke the functions of Connection in multi-threads.
        CTYPE_INVOKE_MULTITHREAD = (1 << 17), 

        // the range of connection type is from (1 << 19) to (1 << 16)
        CTYPE_INVOKE_MASK = 0xF0000,

        // property of sending.
        CTYPE_SEND_NO_PARTIAL_DATA = (1 << 20),
        CTYPE_SEND_PRIORITY = (1 << 21),

        // the range of sending is from (1 << 23) to (1 << 20)
        CTYPE_SEND_MASK = 0xF00000,

        // will Add length ahead to upper layer data
        CTYPE_PDU_LENGTH = (1 << 27),

        // property of private connection PDU.
        // the following propertys contain CTYPE_SEND_NO_PARTIAL_DATA,
        // connect request and response for detecting connect
        CTYPE_PDU_PACKAGE = (1 << 28),
        CTYPE_PDU_KEEPALIVE = (1 << 29),
        CTYPE_PDU_RECONNECT = (1 << 30),
        // the reliable connection implements packet, keep-alive and reconnection functions.
        CTYPE_PDU_RELIABLE = CTYPE_PDU_PACKAGE | CTYPE_PDU_KEEPALIVE | CTYPE_PDU_RECONNECT,

        // the range of PDU is from (1 << 31) to (1 << 24)
        CTYPE_PDU_MASK = 0xFF000000,
    };

    enum CPriority
    {
        CPRIORITY_HIGH,
        CPRIORITY_ABOVE_NORMAL,
        CPRIORITY_NORMAL,
        CPRIORITY_BELOW_NORMAL,
        CPRIORITY_LOW,
    };

    enum 
    {
        UDP_SEND_MAX_LEN = 16 * 1024,
        UDP_ONE_PACKET_MAX_LEN = 1514-14-20-8,
    };

    enum
    {
        USE_SIG_REALTIME=0,
        USE_EPOLL,
        USE_SELECT
    };
    virtual ~CAWConnectionManager(){}

    /// Create <IAWConnector>.
    virtual CAWResult CreateConnectionClient(CType aType, 
                        IAWConnector *&aConClient) = 0;

    /// Create <IAWAcceptor>.
    virtual CAWResult CreateConnectionServer(CType aType,
        IAWAcceptor *&aAcceptor) = 0;

    virtual CAWResult CreateConnectionClientWithThread(CType aType, 
                        IAWConnector *&aConClient, 
                        CAWThread *pNetworkThread) = 0;
    
    /// Create <IAWAcceptor>.
    virtual CAWResult CreateConnectionServerWithThread(CType aType,
                    IAWAcceptor *&aAcceptor, 
                    CAWThread *pNetworkThread) = 0;


    virtual int GetReactorType() = 0;

};

class CAW_OS_EXPORT CAWTransportParameter
{
public:
    CAWTransportParameter(CAWConnectionManager::CPriority aPriority = CAWConnectionManager::CPRIORITY_NORMAL)
        : m_dwHaveSent(0)
        , m_Priority(aPriority)
    {
    }

    DWORD m_dwHaveSent;
    CAWConnectionManager::CPriority m_Priority;
};

/// the sink classes don't need ReferenceControl
class CAW_OS_EXPORT IAWAcceptorConnectorSink 
{
public:
    /**
        * <aReason> indicates Connect successful or failed, 
        * if successful, <aTrpt> is not NULL, otherwise is NULL.
        * <aRequestId> indicates which Connector calls it.
        */
    virtual void OnConnectIndication(
        CAWResult aReason,
        IAWTransport *aTrpt,
        IAWAcceptorConnectorId *aRequestId) = 0;

protected:
    virtual ~IAWAcceptorConnectorSink() {}
};

class CAW_OS_EXPORT IAWTransportSink 
{
public:
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL) = 0;

    virtual void OnSend(
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL) = 0;

    virtual void OnDisconnect(
    CAWResult aReason,
    IAWTransport *aTrptId) = 0;

   protected:
    virtual ~IAWTransportSink() {}
};

class CAW_OS_EXPORT IAWTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWTransportSink *aSink) = 0;

    virtual IAWTransportSink* GetSink() = 0;

    /// If success, fill <aPara->m_dwHaveSent> if <aPara> is not NULL:
    ///    if <aData> has sent completely, return CAW_OK;
    ///    else return CAW_ERROR_PARTIAL_DATA;
    /// Note: <aData> has been advanced <aPara->m_dwHaveSent> bytes in this function.
    virtual CAWResult SendData(CAWMessageBlock &aData, CAWTransportParameter *aPara = NULL) = 0;

    /// the <aCommand>s are all listed in file CmErrorNetwork.h
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;

    /// Disconnect the connection, and will not callback <IAWTransportSink> longer.
    virtual CAWResult Disconnect(CAWResult aReason) = 0;
    virtual CAW_HANDLE GetTransportHandle() const = 0;

protected:
    virtual ~IAWTransport() {}
};

class CAW_OS_EXPORT IAWRawTransportSink 
{
public:
    virtual void OnReceive(const char *data, size_t size) = 0;

   protected:
       virtual ~IAWRawTransportSink() {}
};

class CAW_OS_EXPORT IAWRawTransport : public IAWReferenceControl
{

public:
    virtual CAWResult Open(WORD16 type, IAWRawTransportSink *aSink) = 0;

    virtual IAWRawTransportSink* GetSink() = 0;

    virtual CAWResult Bind(CAWInetAddr &aAddrLocal,CAWInetAddr &aAddrPeer) = 0;

    virtual CAWResult SendData(const char *data, size_t size) = 0;

    virtual CAWResult Close(CAWResult aReason) = 0;
protected:
    virtual ~IAWRawTransport() {}
};


class CAW_OS_EXPORT IAWAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWConnector : public IAWAcceptorConnectorId
{
public:
    /**
        * If <aTimeout> equals NULL, there is no limit time for connecting.
        * No return value, IAWAcceptorConnectorSink::OnConnectIndication() will 
        * callback to indicate successful or failed.
        * 
        * <aAddrLocal> is bind() before connect() if it is not NULL.
        *
        * If you want to send some user data in the connect request,
        * call SetOption(CAW_OPT_CONNECTION_CONNCET_DATA) before call this funtion.
        */
    virtual void AsycConnect(
        IAWAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrPeer, 
        CAWTimeValue *aTimeout = NULL,
        CAWInetAddr *aAddrLocal = NULL) = 0;

    /**
        * IAWAcceptorConnectorSink::OnConnectIndication() will never callback 
        * after invoking it.
        */
    virtual void CancelConnect() = 0;

protected:
    virtual ~IAWConnector() {}
};

class CAW_OS_EXPORT IAWDetectionConnector : public IAWConnector
{
public:
    /// add connection one by one, and the prior has high priority.
    virtual CAWResult AddConnection(
        CAWConnectionManager::CType Type, 
        const CAWInetAddr &aAddrPeer,
        CAWTimeValue *aTimeDelay = NULL) = 0;

    /// Start connecting at the same time in <aTimeout>,
    /// If low priority connection connected, wait high priority connection in <aTimeDelay>.
    virtual void StartDetectionConnect(IAWAcceptorConnectorSink *aSink,CAWTimeValue *aTimeout = NULL ) =0;

protected:
    virtual ~IAWDetectionConnector() {}
};

class CAW_OS_EXPORT IAWAcceptor : public IAWAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IAWAcceptorConnectorSink *aSink,const CAWInetAddr &aAddrListen) = 0;
    virtual CAWResult StopListen(CAWResult aReason) = 0;
protected:
    virtual ~IAWAcceptor() {}
};

#endif // CMCONNECTIONINTERFACE_H

