/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTCPSESSION_BASE_H
#define CAWTCPSESSION_BASE_H
#include "CAWACEWrapper.h"
#include "CAWInetAddr.h"
#include "CAWConnectionInterface.h"
#include "CAWUtilTemplates.h"
#include "CAWMessageBlock.h"

class CAW_OS_EXPORT CAWTCPSessionBase : public IAWTransportSink,
                        public IAWAcceptorConnectorSink,
                        public CAWReferenceControlSingleThread
{ 
public: 
    CAWTCPSessionBase();
    virtual ~CAWTCPSessionBase();

    virtual void OnConnectIndication(
        CAWResult aReason,
        IAWTransport *aTrpt,
        IAWAcceptorConnectorId *aRequestId);

    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL);

    virtual void OnSend(
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL);

    virtual void OnDisconnect(
        CAWResult aReason,
        IAWTransport *aTrptId);

    virtual CAWResult Connect(const CAWInetAddr &peerAddr, CAWInetAddr *aAddrLocal = NULL);

    virtual CAWResult SendMessage(CAWMessageBlock &aData);
    virtual CAWResult SendMessage(const char *data, size_t datasize);

    virtual size_t HandleMessage(const char *data, size_t datasize) = 0;
    virtual void OnPeerDisconnect(CAWResult aReason) = 0;
    virtual void OnConnected(CAWResult aReason) = 0;
    virtual void OnRcvBufferOverFlow(WORD32 buffersize) = 0;

    bool IsClient(){return m_bIsClient;}

    virtual CAWResult SetTransportHandle(CAWAutoPtr<IAWTransport> &pTransport);

    virtual CAWResult Close(CAWResult reason);

    void SetSendBufferSize(WORD32 bufferSize);
    void SetRcvBufferSize(WORD32 bufferSize);
    void GetPeerIP(CAWString &ip);
    void GetLocalIP(CAWString &ip);
    WORD16 GetPeerPort();
    WORD16 GetLocalPort();
    const CAWInetAddr &GetPeerAddr() const;
    const CAWInetAddr &GetLocalAddr() const;
    bool IsClose();
protected:
    CAWAutoPtr<IAWTransport> m_pTransport;
    CAWAutoPtr<IAWConnector> m_pConnector;
    CAWMessageBlock *m_pMbSendBuf;
    CAWMessageBlock *m_pMbRcvBuf;
    bool                        m_bConnected;
    bool                        m_bIsClient;
    WORD32                      m_dwSendBufMaxLen;
    WORD32                      m_dwRcvBufMaxLen;
    CAWInetAddr                 m_addrPeer;
    CAWInetAddr                 m_addrLocal;
    bool m_bisoverbuffer;
    bool m_isClose;
};


#endif /* CCMTCPSESSION_BASE_H */

