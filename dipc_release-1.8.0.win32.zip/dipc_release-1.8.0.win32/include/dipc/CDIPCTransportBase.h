/***********************************************************************
    Copyright (C) 2018-2019 �Ͼ����Ǽ�����Ƽ����޹�˾
**********************************************************************/
#ifndef CDIPCTRANSPORTBASE_H
#define CDIPCTRANSPORTBASE_H
#include "CAWACEWrapper.h"

#include "dipc.h"
#include "DIPCPDUBase.h"

class CDIPCTransportManager;
class CAW_OS_EXPORT CDIPCTransportBase : public IDIPCTransportSink, public CAWReferenceControlSingleThread
{
public:
    CDIPCTransportBase();
    virtual ~CDIPCTransportBase();
    virtual CAWResult SetTransport(CAWAutoPtr<IDIPCTransport> &ptransport);
    virtual void OnReceive(CAWMessageBlock &aData,
                            IDIPCTransport *aTrptId);
    //�Զ˶Ͽ�����
    virtual void OnDisconnect(CAWResult aReason,
                    IDIPCTransport *aTrptId);
    virtual void OnSend(IDIPCTransport *aTrptId);
    virtual size_t HandleMessage(const char *msg, size_t msgsize);
    virtual void OnDIPCMessage(uint16_t type, 
        uint32_t xid, 
        const char *msg, 
        size_t msgsize) = 0;

    virtual CAWResult SendMessage(CAWMessageBlock &aData);
    virtual CAWResult SendMessage(const char *msg, size_t msgsize);
    virtual CAWResult RealSendMessage(CAWMessageBlock &aData);
    virtual CAWResult Disconnect(CAWResult reason);
    virtual CAWResult SendDIPCMessage(uint16_t type, uint32_t xid, const char *msg, size_t msgsize);
    virtual CAWResult SendDIPCMessage(uint16_t type, uint32_t xid, CAWMessageBlock &msg);

    void AddTransportToManager(CDIPCTransportManager *pmgr);
private:
    uint32_t m_xid;
    CAWAutoPtr<IDIPCTransport> m_pTransport;
    CAWMessageBlock *m_pMbSendBuf;
    CAWMessageBlock *m_pMbRcvBuf;
    CDIPCTransportManager *m_pmgr;
    bool m_isClose;
};


#endif//CDIPCTRANSPORTBASE_H
