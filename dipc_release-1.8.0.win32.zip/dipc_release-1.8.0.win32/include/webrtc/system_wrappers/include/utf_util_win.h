/*
 *  Copyright (c) 2014 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

// Conversion functions for UTF-8 and UTF-16 strings on Windows.
// Duplicated from talk/base/win32.h.
#ifndef WEBRTC_SYSTEM_WRAPPERS_INCLUDE_UTF_UTIL_H_
#define WEBRTC_SYSTEM_WRAPPERS_INCLUDE_UTF_UTIL_H_

#ifdef WIN32
#include <windows.h>
#include <string>

#include "webrtc/base/scoped_ptr.h"
#include "webrtc/base/stringutils.h"

namespace webrtc {

inline WEBRTC_DLLEXPORT wchar_t *ToUtf16(const char* utf8, size_t len) {
    int len16 = ::MultiByteToWideChar(CP_UTF8, 0, utf8, static_cast<int>(len),
                                      NULL, 0);
    wchar_t* ws = (wchar_t*)malloc(wchar_t*(len16+1));
    ::memset(ws,0,wchar_t*(len16+1));
    ::MultiByteToWideChar(CP_UTF8, 0, utf8, static_cast<int>(len), ws, len16);
    return ws;

}
inline WEBRTC_DLLEXPORT void FreeToUtf8(char *putf8) {
    if (putf8)
    free(putf8);
}

inline WEBRTC_DLLEXPORT void FreeToUtf16(wchar_t *putf8) {
    if (putf8)
    free(putf8);
}

inline WEBRTC_DLLEXPORT wchar_t *ToUtf16(const rtc::rtcstring& str) {
  return ToUtf16(str.data(), str.length());
}

inline WEBRTC_DLLEXPORT char *ToUtf8(const wchar_t* wide, size_t len) {
    int len8 = ::WideCharToMultiByte(CP_UTF8, 0, wide, static_cast<int>(len),
                                     NULL, 0, NULL, NULL);
    char* ns = (char *)malloc(len8+1);
    ::memset(ns,0,len8+1);
    ::WideCharToMultiByte(CP_UTF8, 0, wide, static_cast<int>(len), ns, len8,
                          NULL, NULL);
    return ns;

}

inline WEBRTC_DLLEXPORT char *ToUtf8(const wchar_t* wide) {
  return ToUtf8(wide, wcslen(wide));
}

inline WEBRTC_DLLEXPORT char *ToUtf8(const std::wstring& wstr) {
  return ToUtf8(wstr.data(), wstr.length());
}

}  // namespace webrtc

#endif  // WIN32
#endif  // WEBRTC_SYSTEM_WRAPPERS_INCLUDE_UTF_UTIL_H_
