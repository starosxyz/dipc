StarDLLS
===================

# StarDLLS is base libary for StarOS

StarDLLS是基础平台库，包含第三方的开源库。

1)设置STAROS_HOME环境变量
windows/Linux


