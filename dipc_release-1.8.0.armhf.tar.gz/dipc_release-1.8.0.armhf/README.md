DIPC
===================

# 分布式进程间通信

1)设置DIPC_HOME环境变量
windows/Linux



