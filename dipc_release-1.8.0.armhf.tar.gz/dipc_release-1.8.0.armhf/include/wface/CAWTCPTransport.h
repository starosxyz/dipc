/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTCPTRANSPORT_H
#define CAWTCPTRANSPORT_H
#include "CAWACEWrapper.h"
#include "CAWInetAddr.h"
#include "CAWConnectionInterface.h"
#include "CAWUtilTemplates.h"
#include "CAWMessageBlock.h"
#include <mutex>

class CAW_OS_EXPORT CAWTCPTransport : public IAWTransportSink
{ 
public: 
    CAWTCPTransport();
    virtual ~CAWTCPTransport();

    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL);

    virtual void OnSend(
        IAWTransport *aTrptId,
        CAWTransportParameter *aPara = NULL);

    virtual void OnDisconnect(
        CAWResult aReason,
        IAWTransport *aTrptId);

    virtual CAWResult SendMessage(CAWMessageBlock &aData, CAWTransportParameter *pparam=NULL);

    virtual WORD16 HandleMessage(CAWMessageBlock &aData) = 0;
    virtual void OnPeerDisconnect(CAWResult aReason) = 0;
    
    virtual CAWResult SetTransportHandle(CAWAutoPtr<IAWTransport> &pTransport);

    virtual CAWResult Disconnect(CAWResult reason);

    void SetSendBufferSize(WORD32 bufferSize);
    void SetRcvBufferSize(WORD32 bufferSize);

    void GetPeerIP(CAWString &ip);
    void GetLocalIP(CAWString &ip);
    
    WORD16 GetPeerPort();
    
    WORD16 GetLocalPort();
    
    const CAWInetAddr &GetPeerAddr() const;
    const CAWInetAddr &GetLocalAddr() const;
    bool IsClose();
protected:
    CAWAutoPtr<IAWTransport> m_pTransport;
    CAWMessageBlock *           m_pBlocks;
    CAWMessageBlock *           m_pMbSendBuf;
    WORD32                      m_dwSendBufMaxLen;
    WORD32                      m_dwRcvBufMaxLen;
    CAWInetAddr                 m_addrPeer;
    CAWInetAddr                 m_addrLocal;
    bool                        m_isClose;
};


#endif /* CAWTCPTransport */

