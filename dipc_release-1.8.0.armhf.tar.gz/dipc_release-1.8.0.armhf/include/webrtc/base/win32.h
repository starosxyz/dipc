/*
 *  Copyright 2004 The WebRTC Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_BASE_WIN32_H_
#define WEBRTC_BASE_WIN32_H_

#if defined(WEBRTC_WIN)

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

// Make sure we don't get min/max macros
#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <winsock2.h>
#include <windows.h>

#ifndef SECURITY_MANDATORY_LABEL_AUTHORITY
// Add defines that we use if we are compiling against older sdks
#define SECURITY_MANDATORY_MEDIUM_RID               (0x00002000L)
#define TokenIntegrityLevel static_cast<TOKEN_INFORMATION_CLASS>(0x19)
typedef struct _TOKEN_MANDATORY_LABEL {
    SID_AND_ATTRIBUTES Label;
} TOKEN_MANDATORY_LABEL, *PTOKEN_MANDATORY_LABEL;
#endif  // SECURITY_MANDATORY_LABEL_AUTHORITY

#undef SetPort

#include <string>

#include "webrtc/base/stringutils.h"
#include "webrtc/base/basictypes.h"

namespace rtc {

WEBRTC_DLLEXPORT const char* win32_inet_ntop(int af, const void *src, char* dst, socklen_t size);
WEBRTC_DLLEXPORT int win32_inet_pton(int af, const char* src, void *dst);

WEBRTC_DLLEXPORT wchar_t* ToUtf16(const char* utf8, size_t len);

WEBRTC_DLLEXPORT wchar_t* ToUtf16(const char *str);
WEBRTC_DLLEXPORT wchar_t* ToUtf16(const rtcstring &str);
WEBRTC_DLLEXPORT char *ToUtf8(const wchar_t* wide, size_t len);

WEBRTC_DLLEXPORT void FreeToUtf8(char *putf8);

WEBRTC_DLLEXPORT void FreeToUtf16(wchar_t *putf8);


WEBRTC_DLLEXPORT char *ToUtf8(const wchar_t* wide);

WEBRTC_DLLEXPORT char *ToUtf8(const std::wstring& wstr);
// Convert FILETIME to time_t
WEBRTC_DLLEXPORT void FileTimeToUnixTime(const FILETIME& ft, time_t* ut);

// Convert time_t to FILETIME
WEBRTC_DLLEXPORT void UnixTimeToFileTime(const time_t& ut, FILETIME * ft);

// Convert a Utf8 path representation to a non-length-limited Unicode pathname.
WEBRTC_DLLEXPORT bool Utf8ToWindowsFilename(const rtcstring& utf8, std::wstring* filename);

// Convert a FILETIME to a UInt64
WEBRTC_DLLEXPORT inline uint64_t ToUInt64(const FILETIME& ft) {
  ULARGE_INTEGER r = {{ft.dwLowDateTime, ft.dwHighDateTime}};
  return r.QuadPart;
}

enum WindowsMajorVersions {
  kWindows2000 = 5,
  kWindowsVista = 6,
};
WEBRTC_DLLEXPORT bool GetOsVersion(int* major, int* minor, int* build);

WEBRTC_DLLEXPORT inline bool IsWindowsVistaOrLater() {
  int major;
  return (GetOsVersion(&major, NULL, NULL) && major >= kWindowsVista);
}

WEBRTC_DLLEXPORT inline bool IsWindowsXpOrLater() {
  int major, minor;
  return (GetOsVersion(&major, &minor, NULL) &&
          (major >= kWindowsVista ||
          (major == kWindows2000 && minor >= 1)));
}

WEBRTC_DLLEXPORT inline bool IsWindows8OrLater() {
  int major, minor;
  return (GetOsVersion(&major, &minor, NULL) &&
          (major > kWindowsVista ||
          (major == kWindowsVista && minor >= 2)));
}

// Determine the current integrity level of the process.
WEBRTC_DLLEXPORT bool GetCurrentProcessIntegrityLevel(int* level);

WEBRTC_DLLEXPORT inline bool IsCurrentProcessLowIntegrity() {
  int level;
  return (GetCurrentProcessIntegrityLevel(&level) &&
      level < SECURITY_MANDATORY_MEDIUM_RID);
}

WEBRTC_DLLEXPORT bool AdjustCurrentProcessPrivilege(const TCHAR* privilege, bool to_enable);

}  // namespace rtc

#endif  // WEBRTC_WIN
#endif  // WEBRTC_BASE_WIN32_H_
