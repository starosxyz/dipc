/*
 *  Copyright 2004 The WebRTC Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

// @file Contains utility classes that make it easier to use SecBuffers

#ifndef WEBRTC_BASE_SEC_BUFFER_H__
#define WEBRTC_BASE_SEC_BUFFER_H__
#include <string>
#include <vector>
#include <iostream>
#include <type_traits>
#include <deque>
namespace rtc {

WEBRTC_DLLEXPORT void* allocate_memory(size_t elems, size_t elem_size);

WEBRTC_DLLEXPORT void deallocate_memory(void* p, size_t elems, size_t elem_size);


template<typename T>
class secure_allocator
   {
   public:
       static_assert(std::is_integral<T>::value, "secure_allocator supports only integer types");

      typedef T          value_type;
      typedef std::size_t size_type;

      secure_allocator() noexcept = default;
      secure_allocator(const secure_allocator&) noexcept = default;
      secure_allocator& operator=(const secure_allocator&) noexcept = default;
      ~secure_allocator() noexcept = default;

      template<typename U>
      secure_allocator(const secure_allocator<U>&) noexcept {}

      T* allocate(std::size_t n)
         {
         return static_cast<T*>(allocate_memory(n, sizeof(T)));
         }

      void deallocate(T* p, std::size_t n)
         {
         deallocate_memory(p, n, sizeof(T));
         }
   };

template<typename T, typename U> inline bool
operator==(const secure_allocator<T>&, const secure_allocator<U>&)
   { return true; }

template<typename T, typename U> inline bool
operator!=(const secure_allocator<T>&, const secure_allocator<U>&)
   { return false; }

template<typename T> using secure_vector = std::vector<T, secure_allocator<T>>;
template<typename T> using secure_deque = std::deque<T, secure_allocator<T>>;

}

#endif

