#ifndef WCP_VERSION_H
#define WCP_VERSION_H

#define WCP_MAJOR_VERSION 0
#define WCP_MINOR_VERSION 1
#define WCP_BETA_VERSION 0
#define WCP_VERSION "0.1.0"


#endif

