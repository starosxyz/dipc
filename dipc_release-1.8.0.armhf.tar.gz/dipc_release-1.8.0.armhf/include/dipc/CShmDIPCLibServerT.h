/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef CDIPCLIBSERVERT_H
#define CDIPCLIBSERVERT_H
#include "CAWACEWrapper.h"

#include "CAWShmIPCStreamBase.h"
#include "DIPCPDUBase.h"

template <class DIPCClientType>
class CAW_OS_EXPORT CShmDIPCLibServerT : public IAWShmIPCAcceptorConnectorSink
{
public:
    typedef CShmDIPCLibServerT SelfType;
    CShmDIPCLibServerT()
            :m_dipcProcess(NULL)
    {
    }
    virtual ~CShmDIPCLibServerT()
    {
        CleanUp();
    }
    
    virtual CAWResult LibServerListen(IDIPCProcess *dipcProcess, uint16_t serviceid)
    {
        if (m_acceptor.Get())
        {
            m_acceptor->StopListen(CAW_OK);
            m_acceptor=NULL;
        }
        uint16_t jno=dipcProcess->GetLocalJno();
        CAWShmIPCAddr address(jno,serviceid);
        m_dipcProcess = dipcProcess;
        dipcProcess->CreateShmIPCServer(m_acceptor);
        if (m_acceptor.Get())
        {
            printf("LibServerListen address=%s\n", address.ToString().c_str());
            return m_acceptor->StartListen(this,address);
        }
        else 
        {
            return CAW_ERROR_FAILURE;
        }
    }
    void CleanUp()
    {
        typename ClientType::iterator it = m_clients.begin();
        while (it != m_clients.end())
        {
            it=m_clients.erase(it);
        }
    }
    CAWResult AddClient(uint32_t id, CAWAutoPtr<DIPCClientType> &pprocess)
    {
        printf("LibServer AddClient count=%d,id=%d\n", m_clients.size(),id);

        typename ClientType::iterator it = m_clients.find(id);
        if (it == m_clients.end())
        {
            m_clients[id]=pprocess;
            return CAW_OK;
        }
        else 
        {
            return CAW_ERROR_FAILURE;
        }
    }
    DIPCClientType *FindClient(uint32_t id)
    {

        typename ClientType::iterator it = m_clients.find(id);
        if (it != m_clients.end())
        {
            CAWAutoPtr<DIPCClientType> &pclient = it->second;
            return pclient.Get();
        }  

        return NULL;
    }
    CAWResult RemoveClient(uint32_t id)
    {
        printf("LibServer RemoveClient count=%d,id=%d\n", m_clients.size(),id);

        typename ClientType::iterator it = m_clients.find(id);
        if (it != m_clients.end())
        {
            //CAWAutoPtr<DIPCClientType> &client = it->second;
            m_clients.erase(it);
            return CAW_OK;
        }
        return CAW_ERROR_NOT_FOUND;
    }
    void DisconnectAllLibChannel()
    {
        typename ClientType::iterator it = m_clients.begin();
        while (it != m_clients.end())
        {
            CAWAutoPtr<DIPCClientType> &pclient = it->second;
            pclient->Close(CAW_OK);
            it=m_clients.erase(it);
        } 
    }
protected:
    CAWAutoPtr < IAWShmIPCAcceptor> m_acceptor;
    CAWMutexThread m_Mutex;
    IDIPCProcess *m_dipcProcess;
    typedef std::unordered_map<uint32_t,CAWAutoPtr<DIPCClientType>> ClientType;
    ClientType m_clients;
};

#endif//CDIPCLIBSERVERT_H


