/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWINETADDR_H
#define CAWINETADDR_H

#include "CAWStdCpp.h"
#include "CAWString.h"
#include "CAWError.h"
#ifndef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
  #define CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME 1
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME

/// The concept of <CAWInetAddr> is mainly copyed by <ACE_INET_Addr>
/// http://www.cs.wustl.edu/~schmidt/ACE.html
class CAW_OS_EXPORT CAWInetAddr  
{
public:
    CAWInetAddr();

    /// Creates an <CAWInetAddr> from a <aPort> and the remote
    /// <aHostName>. The port number is assumed to be in host byte order.
    CAWInetAddr(LPCSTR aHostName, WORD aPort);

    /**
        * Initializes an <CAWInetAddr> from the <aIpAddrAndPort>, which can be
        * "ip-number:port-number" (e.g., "tango.cs.wustl.edu:1234" or
        * "128.252.166.57:1234").  If there is no ':' in the <address> it
        * is assumed to be a port number, with the IP address being
        * INADDR_ANY.
        */
    CAWInetAddr(LPCSTR aIpAddrAndPort);

    CAWResult Set(LPCSTR aHostName, WORD aPort);
    CAWResult Set(LPCSTR aIpAddrAndPort);

    CAWResult SetIpAddrByString(LPCSTR aIpAddr);
    CAWResult SetIpAddrBy4Bytes(DWORD aIpAddr, BOOL aIsNetworkOrder = TRUE);
    CAWResult SetPort(WORD aPort);

    /// Compare two addresses for equality.  The addresses are considered
    /// equal if they contain the same IP address and port number.
    bool operator == (const CAWInetAddr &aRight) const;

    /**
        * Returns true if <this> is less than <aRight>.  In this context,
        * "less than" is defined in terms of IP address and TCP port
        * number.  This operator makes it possible to use <ACE_INET_Addr>s
        * in STL maps.
        */
    bool operator < (const CAWInetAddr &aRight) const;

    CAWString GetIpDisplayName() const;

    WORD GetPort() const;

    DWORD GetIpAddrIn4Bytes() const;

    DWORD GetSize() const;

    DWORD GetType() const;

    const sockaddr_in* GetPtr() const ;
    static BOOL IpAddrStringTo4Bytes(LPCSTR aIpStr, DWORD &aIpDword);
    static CAWString IpAddr4BytesToString(DWORD aIpDword);

#ifdef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
    BOOL IsResolved() const;

    const CAWString &GetHostName() const ;

    CAWResult TryResolve();
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME

public:
    static CAWInetAddr s_InetAddrAny();

private:
    sockaddr_in m_SockAddr;

#ifdef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
    // m_strHostName is empty that indicates resovled successfully,
    // otherwise it needs resolving.
    CAWString m_strHostName;
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
};


#endif // !CAWINETADDR_H
