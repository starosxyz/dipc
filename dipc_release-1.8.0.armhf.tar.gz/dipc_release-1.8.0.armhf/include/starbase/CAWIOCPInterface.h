#ifndef CAWPROACTORINTERFACE_H
#define CAWPROACTORINTERFACE_H

#include "CAWDefines.h"
#include "CAWThreadInterface.h"
#include "CAWInetAddr.h"

#define MAX_BUFFER_LEN					1024*16
typedef enum _IOType
{
	IOAccept,						 // ��־Ͷ�ݵ� Accept��ʼ������
	IOSend,							 // ��־Ͷ�ݵ��� ���Ͳ���(д)
	IORecv,							 // ��־Ͷ�ݵ��� ���ղ���(��)
	IOIdle					   	     // ���ڳ�ʼ����������
}IOType;
struct PER_IO_CONTEXT
{
	OVERLAPPED     m_ol;     
	WSABUF         m_wsaBuf;
	SOCKET         m_sock;	
	SOCKADDR_IN	   m_addr;
	char           m_szBuf[MAX_BUFFER_LEN];	
	IOType		   m_ioType;
	DWORD		   m_dwBytesSend;
	DWORD		   m_dwBytesRecv;

	void Clear()
	{
		ZeroMemory(&m_ol, sizeof(OVERLAPPED));
		ZeroMemory(m_szBuf, MAX_BUFFER_LEN);
		ZeroMemory(&m_addr, sizeof(SOCKADDR_IN));
		m_sock = INVALID_SOCKET;
		m_wsaBuf.buf = m_szBuf;
		m_wsaBuf.len = MAX_BUFFER_LEN;
		m_ioType = IOIdle;
		m_dwBytesSend = 0;
		m_dwBytesRecv = 0;
	}
};
class CAW_OS_EXPORT IAWIOCPProactorSink
{
public:
	virtual CAWResult OnConnected(PER_IO_CONTEXT *pcontext) = 0;
	virtual CAWResult OnDisconnected(PER_IO_CONTEXT *pcontext) = 0;
	virtual CAWResult OnSend(PER_IO_CONTEXT *pcontext) = 0;
	virtual CAWResult OnReceive(PER_IO_CONTEXT *pcontext) = 0;
protected:
	virtual ~IAWIOCPProactorSink() {}
};

class CAW_OS_EXPORT IAWIOCPProactor
{
public:
    /// Initialization.
    virtual CAWResult Open(IAWIOCPProactorSink *psink, CAWInetAddr &listenaddr) = 0;
    virtual CAWResult Close() = 0;
	virtual PER_IO_CONTEXT *AllocContext() = 0;
	virtual CAWResult PostSend(PER_IO_CONTEXT *pcontext) = 0;
	virtual CAWResult Disconnect(PER_IO_CONTEXT *pcontext) = 0;
	virtual CAWResult ScheduleTimer(IAWTimerHandler *aTh,
		LPVOID aArg,
		const CAWTimeValue &aInterval,
		DWORD aCount) = 0;
	virtual CAWResult CancelTimer(IAWTimerHandler *aTh) = 0;
	virtual CAWResult AssociateSocket(SOCKET sock) = 0;
	virtual CAWResult SendEvent(IAWEvent *aEvent) = 0;
	virtual CAWResult PostEvent(IAWEvent *aEvent) = 0;
    virtual ~IAWIOCPProactor() { }
};
extern "C"
{
	CAW_OS_EXPORT IAWIOCPProactor *CreateIOCP();
	CAW_OS_EXPORT void DestroyIOCP(IAWIOCPProactor *pproactor);
}
#endif//CMPROACTORINTERFACE_H

