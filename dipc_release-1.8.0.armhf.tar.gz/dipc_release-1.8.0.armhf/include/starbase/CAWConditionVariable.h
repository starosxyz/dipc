/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWCONDITIONVARIABLE_H
#define CAWCONDITIONVARIABLE_H

#include "CAWMutex.h"

#ifdef CAW_WIN32
  typedef HANDLE CAW_SEMAPHORE_T;
#else
  #include <semaphore.h>
  typedef sem_t CAW_SEMAPHORE_T;
#endif // CAW_WIN32

class CAW_OS_EXPORT CAWSemaphore
{
public:
    CAWSemaphore(LONG aInitialCount = 0, 
        LPCSTR aName = NULL, 
        LONG aMaximumCount = 0x7fffffff);

    virtual ~CAWSemaphore();

    /// Block the thread until the semaphore count becomes
    /// greater than 0, then decrement it.
    CAWResult Lock();

    /// Increment the semaphore by 1, potentially unblocking a waiting thread.
    CAWResult UnLock();

    CAWResult PostN(LONG aCount);

    CAW_SEMAPHORE_T& GetSemaphoreType() { return m_Semaphore;}
private:
    CAW_SEMAPHORE_T m_Semaphore;
};

class CAWTimeValue;

class CAW_OS_EXPORT CAWConditionVariableThread  
{
public:
    CAWConditionVariableThread(CAWMutexThread &aMutex);
    ~CAWConditionVariableThread();

    /// Block on condition.
    /// <aTimeout> is relative time.
    CAWResult Wait(CAWTimeValue *aTimeout = NULL);

    /// Signal one waiting hread.
    CAWResult Signal();

    /// Signal all waiting thread.
    CAWResult Broadcast();

    /// Return the underlying mutex.
    CAWMutexThread& GetUnderlyingMutex() { return m_MutexExternal; }

private:
    CAWMutexThread &m_MutexExternal;

#ifdef CAW_WIN32
    /// Number of waiting threads.
    long waiters_;
    /// Serialize access to the waiters count.
    CAWMutexThread waiters_lock_;
    /// Queue up threads waiting for the condition to become signaled.
    CAWSemaphore sema_;

    HANDLE waiters_done_;
    /// Keeps track of whether we were broadcasting or just signaling.
    size_t was_broadcast_;
#else
    pthread_cond_t m_Condition;
#endif // CAW_WIN32
};

class CAW_OS_EXPORT CAWEventThread
{
public:
    CAWEventThread(BOOL aManualReset = FALSE,
             BOOL aInitialState = FALSE,
             LPCSTR aName = NULL);

    ~CAWEventThread();

  /**
     * if MANUAL reset
     *    sleep till the event becomes signaled
     *    event remains signaled after wait() completes.
     * else AUTO reset
     *    sleep till the event becomes signaled
     *    event resets wait() completes.
     * <aTimeout> is relative time.
     */
    CAWResult Wait(CAWTimeValue *aTimeout = NULL);

   /**
     * if MANUAL reset
     *    wake up all waiting threads
     *    set to signaled state
     * else AUTO reset
     *    if no thread is waiting, set to signaled state
     *    if thread(s) are waiting, wake up one waiting thread and
     *    reset event
     */
    CAWResult Signal();

    /// Set to nonsignaled state.
    CAWResult Reset();

   /**
     * if MANUAL reset
     *    wakeup all waiting threads and
     *    reset event
     * else AUTO reset
     *    wakeup one waiting thread (if present) and
     *    reset event
     */
    CAWResult Pulse();

private:
#ifdef CAW_WIN32
    HANDLE handle_;
#else
    /// Protect critical section.
    CAWMutexThread lock_;

    /// Keeps track of waiters.
    CAWConditionVariableThread condition_;

    /// Specifies if this is an auto- or manual-reset event.
    int manual_reset_;

    /// "True" if signaled.
    int is_signaled_;

    /// Number of waiting threads.
    u_long waiting_threads_;
#endif
};

#endif // !CAWCONDITIONVARIABLE_H

