/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAW_BYTEORDER_H_
#define CAW_BYTEORDER_H_
#include "CAWDefines.h"

// Reading and writing of little and big-endian numbers from memory
//TODO: Optimized versions, with direct read/writes of
// integers in host-endian format, when the platform supports it.

inline void CAW_OS_EXPORT Set8(void* memory, size_t offset, uint8_t v) {
  static_cast<uint8_t*>(memory)[offset] = v;
}

inline uint8_t CAW_OS_EXPORT Get8(const void* memory, size_t offset) {
  return static_cast<const uint8_t*>(memory)[offset];
}

inline void CAW_OS_EXPORT SetBE16(void* memory, uint16_t v) {
  Set8(memory, 0, static_cast<uint8_t>(v >> 8));
  Set8(memory, 1, static_cast<uint8_t>(v >> 0));
}

inline void CAW_OS_EXPORT SetBE32(void* memory, uint32_t v) {
  Set8(memory, 0, static_cast<uint8_t>(v >> 24));
  Set8(memory, 1, static_cast<uint8_t>(v >> 16));
  Set8(memory, 2, static_cast<uint8_t>(v >> 8));
  Set8(memory, 3, static_cast<uint8_t>(v >> 0));
}

inline void CAW_OS_EXPORT SetBE64(void* memory, uint64_t v) {
  Set8(memory, 0, static_cast<uint8_t>(v >> 56));
  Set8(memory, 1, static_cast<uint8_t>(v >> 48));
  Set8(memory, 2, static_cast<uint8_t>(v >> 40));
  Set8(memory, 3, static_cast<uint8_t>(v >> 32));
  Set8(memory, 4, static_cast<uint8_t>(v >> 24));
  Set8(memory, 5, static_cast<uint8_t>(v >> 16));
  Set8(memory, 6, static_cast<uint8_t>(v >> 8));
  Set8(memory, 7, static_cast<uint8_t>(v >> 0));
}

inline uint16_t CAW_OS_EXPORT GetBE16(const void* memory) {
  return static_cast<uint16_t>((Get8(memory, 0) << 8) |
                             (Get8(memory, 1) << 0));
}

inline uint32_t CAW_OS_EXPORT GetBE32(const void* memory) {
  return (static_cast<uint32_t>(Get8(memory, 0)) << 24) |
      (static_cast<uint32_t>(Get8(memory, 1)) << 16) |
      (static_cast<uint32_t>(Get8(memory, 2)) << 8) |
      (static_cast<uint32_t>(Get8(memory, 3)) << 0);
}

inline uint64_t CAW_OS_EXPORT GetBE64(const void* memory) {
  return (static_cast<uint64_t>(Get8(memory, 0)) << 56) |
      (static_cast<uint64_t>(Get8(memory, 1)) << 48) |
      (static_cast<uint64_t>(Get8(memory, 2)) << 40) |
      (static_cast<uint64_t>(Get8(memory, 3)) << 32) |
      (static_cast<uint64_t>(Get8(memory, 4)) << 24) |
      (static_cast<uint64_t>(Get8(memory, 5)) << 16) |
      (static_cast<uint64_t>(Get8(memory, 6)) << 8) |
      (static_cast<uint64_t>(Get8(memory, 7)) << 0);
}

inline void CAW_OS_EXPORT SetLE16(void* memory, uint16_t v) {
  Set8(memory, 0, static_cast<uint8_t>(v >> 0));
  Set8(memory, 1, static_cast<uint8_t>(v >> 8));
}

inline void CAW_OS_EXPORT SetLE32(void* memory, uint32_t v) {
  Set8(memory, 0, static_cast<uint8_t>(v >> 0));
  Set8(memory, 1, static_cast<uint8_t>(v >> 8));
  Set8(memory, 2, static_cast<uint8_t>(v >> 16));
  Set8(memory, 3, static_cast<uint8_t>(v >> 24));
}

inline void CAW_OS_EXPORT SetLE64(void* memory, uint64_t v) {
  Set8(memory, 0, static_cast<uint8_t>(v >> 0));
  Set8(memory, 1, static_cast<uint8_t>(v >> 8));
  Set8(memory, 2, static_cast<uint8_t>(v >> 16));
  Set8(memory, 3, static_cast<uint8_t>(v >> 24));
  Set8(memory, 4, static_cast<uint8_t>(v >> 32));
  Set8(memory, 5, static_cast<uint8_t>(v >> 40));
  Set8(memory, 6, static_cast<uint8_t>(v >> 48));
  Set8(memory, 7, static_cast<uint8_t>(v >> 56));
}

inline uint16_t CAW_OS_EXPORT GetLE16(const void* memory) {
  return static_cast<uint16_t>((Get8(memory, 0) << 0) |
                             (Get8(memory, 1) << 8));
}

inline uint32_t CAW_OS_EXPORT GetLE32(const void* memory) {
  return (static_cast<uint32_t>(Get8(memory, 0)) << 0) |
      (static_cast<uint32_t>(Get8(memory, 1)) << 8) |
      (static_cast<uint32_t>(Get8(memory, 2)) << 16) |
      (static_cast<uint32_t>(Get8(memory, 3)) << 24);
}

inline uint64_t CAW_OS_EXPORT GetLE64(const void* memory) {
  return (static_cast<uint64_t>(Get8(memory, 0)) << 0) |
      (static_cast<uint64_t>(Get8(memory, 1)) << 8) |
      (static_cast<uint64_t>(Get8(memory, 2)) << 16) |
      (static_cast<uint64_t>(Get8(memory, 3)) << 24) |
      (static_cast<uint64_t>(Get8(memory, 4)) << 32) |
      (static_cast<uint64_t>(Get8(memory, 5)) << 40) |
      (static_cast<uint64_t>(Get8(memory, 6)) << 48) |
      (static_cast<uint64_t>(Get8(memory, 7)) << 56);
}

// Check if the current host is big endian.
inline bool CAW_OS_EXPORT IsHostBigEndian() {
  static const int number = 1;
  return 0 == *reinterpret_cast<const char*>(&number);
}

inline uint16_t CAW_OS_EXPORT HostToNetwork16(uint16_t n) {
  uint16_t result;
  SetBE16(&result, n);
  return result;
}

inline uint32_t CAW_OS_EXPORT HostToNetwork32(uint32_t n) {
  uint32_t result;
  SetBE32(&result, n);
  return result;
}

inline uint64_t CAW_OS_EXPORT HostToNetwork64(uint64_t n) {
  uint64_t result;
  SetBE64(&result, n);
  return result;
}

inline uint16_t CAW_OS_EXPORT NetworkToHost16(uint16_t n) {
  return GetBE16(&n);
}

inline uint32_t CAW_OS_EXPORT NetworkToHost32(uint32_t n) {
  return GetBE32(&n);
}

inline uint64_t CAW_OS_EXPORT NetworkToHost64(uint64_t n) {
  return GetBE64(&n);
}


#endif


