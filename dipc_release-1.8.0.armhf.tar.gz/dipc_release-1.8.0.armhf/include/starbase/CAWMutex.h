/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/
#ifndef CAWMUTEX_H
#define CAWMUTEX_H

#include "CAWDefines.h"
#include "CAWError.h"
#include "CAWUtilClasses.h"

#ifdef CAW_WIN32
  typedef CRITICAL_SECTION CAW_THREAD_MUTEX_T;
#else
  typedef pthread_mutex_t CAW_THREAD_MUTEX_T;
#endif // CAW_WIN32

class CAW_OS_EXPORT CAWMutexThreadBase
{
protected:
    CAWMutexThreadBase();
    ~CAWMutexThreadBase();

public:
    CAWResult Lock();
    CAWResult UnLock();
    CAWResult TryLock();

    CAW_THREAD_MUTEX_T& GetMutexType() { return m_Lock;}

protected:
    CAW_THREAD_MUTEX_T m_Lock;
};

/**
 * Mainly copyed from <ACE_Recursive_Thread_Mutex>.
 * <CAWMutexThreadRecursive> allows mutex locking many times in the same threads.
 */
class CAW_OS_EXPORT CAWMutexThreadRecursive : public CAWMutexThreadBase
{
public:
    CAWMutexThreadRecursive();
    ~CAWMutexThreadRecursive();

private:
    // = Prevent assignment and initialization.
    void operator = (const CAWMutexThreadRecursive&);
    CAWMutexThreadRecursive(const CAWMutexThreadRecursive&);
};

class CAW_OS_EXPORT CAWMutexThread : public CAWMutexThreadBase
{
public:
    CAWMutexThread();
    ~CAWMutexThread();

private:
    // = Prevent assignment and initialization.
    void operator = (const CAWMutexThread&);
    CAWMutexThread(const CAWMutexThread&);
};

/**
 *	<CAWMutexNullSingleThread> checks to ensure running on the same thread
 */
class CAW_OS_EXPORT CAWMutexNullSingleThread
{
public:
    CAWMutexNullSingleThread() 
    {
    }

    // this function may be invoked in the different thread.
    ~CAWMutexNullSingleThread() 
    {
    //		m_Est.EnsureSingleThread();
    }

    CAWResult Lock() 
    {
        m_Est.EnsureSingleThread();
        return CAW_OK;
    }

    CAWResult UnLock() 
    {
        m_Est.EnsureSingleThread();
        return CAW_OK;
    }

    CAWResult TryLock() 
    {
        m_Est.EnsureSingleThread();
        return CAW_OK;
    }

private:
    CAWEnsureSingleThread m_Est;

private:
    // = Prevent assignment and initialization.
    void operator = (const CAWMutexNullSingleThread&);
    CAWMutexNullSingleThread(const CAWMutexNullSingleThread&);
};

template <class MutexType>
class CAW_OS_EXPORT CAWMutexGuardT
{
public:
    CAWMutexGuardT(MutexType& aMutex)
        : m_Mutex(aMutex)
        , m_bLocked(FALSE)
    {
        Lock();
    }

    ~CAWMutexGuardT()
    {
        UnLock();
    }

    CAWResult Lock() 
    {
        CAWResult rv = m_Mutex.Lock();
        m_bLocked = CAW_SUCCEEDED(rv) ? TRUE : FALSE;
        return rv;
    }

    CAWResult UnLock() 
    {
        if (m_bLocked) {
            m_bLocked = FALSE;
            return m_Mutex.UnLock();
        }
        else {
            return CAW_OK;
        }
    }

private:
    MutexType& m_Mutex;
    BOOL m_bLocked;

private:
    // = Prevent assignment and initialization.
    void operator = (const CAWMutexGuardT&);
    CAWMutexGuardT(const CAWMutexGuardT&);
};

#endif // !CAWMUTEX_H

