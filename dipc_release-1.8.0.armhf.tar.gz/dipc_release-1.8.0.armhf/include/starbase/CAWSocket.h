/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CMSOCKET_H
#define CMSOCKET_H

#include "CAWDefines.h"
#include "CAWError.h"
#include "CAWInetAddr.h"

class CAW_OS_EXPORT CAWIPCBase
{
public:
    enum { NON_BLOCK };

    CAWIPCBase() : m_Handle(CAW_INVALID_HANDLE) { }

    CAW_HANDLE GetHandle() const;
    void SetHandle(CAW_HANDLE aNew);

    int Enable(int aValue) const ;
    int Disable(int aValue) const ;
    int Control(int aCmd, void *aArg) const;

protected:
    CAW_HANDLE m_Handle;
};


class CAW_OS_EXPORT CAWSocketBase : public CAWIPCBase
{
protected:
    CAWSocketBase();
    ~CAWSocketBase();

public:
    /// Wrapper around the BSD-style <socket> system call (no QoS).
    int Open(int aFamily, int aType, int aProtocol, BOOL aReuseAddr);

    /// Close down the socket handle.
    int Close();

    /// Wrapper around the <setsockopt> system call.
    int SetOption(int aLevel, int aOption, const void *aOptval, int aOptlen) const ;

    /// Wrapper around the <getsockopt> system call.
    int GetOption(int aLevel, int aOption, void *aOptval, int *aOptlen) const ;

    /// Return the address of the remotely connected peer (if there is
    /// one), in the referenced <aAddr>.
    int GetRemoteAddr(CAWInetAddr &aAddr) const;

    /// Return the local endpoint address in the referenced <aAddr>.
    int GetLocalAddr(CAWInetAddr &aAddr) const;

    /// Recv an <aLen> byte buffer from the connected socket.
    int Recv(char *aBuf, DWORD aLen, int aFlag = 0) const ;

    /// Recv an <aIov> of size <aCount> from the connected socket.
    int RecvV(iovec aIov[], DWORD aCount) const ;

    /// Send an <aLen> byte buffer to the connected socket.
    int Send(const char *aBuf, DWORD aLen, int aFlag = 0) const ;

    /// Send an <aIov> of size <aCount> from the connected socket.
    int SendV(const iovec aIov[], DWORD aCount) const ;
};


class CAW_OS_EXPORT CAWSocketTcp : public CAWSocketBase
{
public:
    CAWSocketTcp();
    ~CAWSocketTcp();

    int Open(BOOL aReuseAddr = FALSE);
    int Open(BOOL aReuseAddr, const CAWInetAddr &aLocal);
    int Close(CAWResult aReason = CAW_OK);
    int CloseWriter();
    int CloseReader();
};

class CAW_OS_EXPORT CAWSocketUdp : public CAWSocketBase
{
public:
    CAWSocketUdp();
    ~CAWSocketUdp();

    int Open(const CAWInetAddr &aLocal);

    int RecvFrom(char *aBuf, 
                DWORD aLen, 
                CAWInetAddr &aAddr, 
                int aFlag = 0) const ;

    int SendTo(const char *aBuf, 
                DWORD aLen, 
                const CAWInetAddr &aAddr, 
                int aFlag = 0) const ;

    int SendVTo(const iovec aIov[], 
                DWORD aCount,
                const CAWInetAddr &aAddr) const ;
};


// inline functions
inline CAW_HANDLE CAWIPCBase::GetHandle() const 
{
    return m_Handle;
}

inline void CAWIPCBase::SetHandle(CAW_HANDLE aNew)
{
    CAW_ASSERTE(m_Handle == CAW_INVALID_HANDLE || aNew == CAW_INVALID_HANDLE);
    m_Handle = aNew;
}

inline CAWSocketBase::CAWSocketBase()
{
}

inline CAWSocketBase::~CAWSocketBase()
{
    Close();
}

inline int CAWSocketBase::SetOption(int aLevel, int aOption, const void *aOptval, int aOptlen) const 
{
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    int nRet = ::setsockopt((CAW_SOCKET)m_Handle, aLevel, aOption, 
#ifdef CAW_WIN32
    static_cast<const char*>(aOptval), 
#else // !CAW_WIN32
    aOptval,
#endif // CAW_WIN32
    aOptlen);

#ifdef CAW_WIN32
    if (nRet == SOCKET_ERROR) {
    errno = ::WSAGetLastError();
    nRet = -1;
    }
#endif // CAW_WIN32
    return nRet;
}

inline int CAWSocketBase::GetOption(int aLevel, int aOption, void *aOptval, int *aOptlen) const 
{
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    int nRet = ::getsockopt((CAW_SOCKET)m_Handle, aLevel, aOption, 
#ifdef CAW_WIN32
    	static_cast<char*>(aOptval), 
    	aOptlen
#else // !CAW_WIN32
    	aOptval,
    	reinterpret_cast<socklen_t*>(aOptlen)
#endif // CAW_WIN32
    	);

#ifdef CAW_WIN32
    if (nRet == SOCKET_ERROR) {
    	errno = ::WSAGetLastError();
    	nRet = -1;
    }
#endif // CAW_WIN32
    return nRet;
}

inline int CAWSocketBase::Recv(char *aBuf, DWORD aLen, int aFlag) const
{
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    CAW_ASSERTE(aBuf);

    int nRet = ::recv((CAW_SOCKET)m_Handle, aBuf, aLen, aFlag);
#ifndef CAW_WIN32
    if (nRet == -1 && errno == EAGAIN)
    errno = EWOULDBLOCK;
#else // !CAW_WIN32
    if (nRet == SOCKET_ERROR) {
    errno = ::WSAGetLastError();
    nRet = -1;
    }
#endif // CAW_WIN32

    return nRet;
}

inline int CAWSocketBase::RecvV(iovec aIov[], DWORD aCount) const 
{
    int nRet;
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    CAW_ASSERTE(aIov);

#ifdef CAW_WIN32
    DWORD dwBytesReceived = 0;
    DWORD dwFlags = 0;
    nRet = ::WSARecv((CAW_SOCKET)m_Handle,
                  (WSABUF *)aIov,
                  aCount,
                  &dwBytesReceived,
                  &dwFlags,
                  0,
                  0);
    if (nRet == SOCKET_ERROR) {
    errno = ::WSAGetLastError();
    nRet = -1;
    }
    else {
    nRet = (int)dwBytesReceived;
    }
#else // !CAW_WIN32
    nRet = ::readv(m_Handle, aIov, aCount);
#endif // CAW_WIN32
    return nRet;
}

inline int CAWSocketBase::Send (const char *aBuf, DWORD aLen, int aFlag) const 
{
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    CAW_ASSERTE(aBuf);

    int nRet = ::send((CAW_SOCKET)m_Handle, aBuf, aLen, aFlag);
#ifndef CAW_WIN32
    if (nRet == -1 && errno == EAGAIN)
    	errno = EWOULDBLOCK;
#else // !CAW_WIN32
    if (nRet == SOCKET_ERROR) {
    	errno = ::WSAGetLastError();
    	nRet = -1;
    }
#endif // CAW_WIN32
	return nRet;
}

inline int CAWSocketBase::SendV(const iovec aIov[], DWORD aCount) const 
{
    int nRet;
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    CAW_ASSERTE(aIov);

#ifdef CAW_WIN32
    DWORD dwBytesSend = 0;
    nRet = ::WSASend((CAW_SOCKET)m_Handle,
                      (WSABUF *)aIov,
                      aCount,
                      &dwBytesSend,
                      0,
                      0,
                      0);
    if (nRet == SOCKET_ERROR) {
    	errno = ::WSAGetLastError();
    	nRet = -1;
    }
    else {
    	nRet = (int)dwBytesSend;
    }
#else // !CAW_WIN32
    nRet = ::writev(m_Handle, aIov, aCount);
#endif // CAW_WIN32
    return nRet;
}

inline CAWSocketTcp::CAWSocketTcp()
{
}

inline CAWSocketTcp::~CAWSocketTcp()
{
	Close();
}

inline int CAWSocketTcp::Open(BOOL aReuseAddr)
{
    return CAWSocketBase::Open(PF_INET, SOCK_STREAM, 0, aReuseAddr);
}

inline int CAWSocketTcp::Close(CAWResult aReason)
{
#ifdef CAW_WIN32
	// We need the following call to make things work correctly on
	// Win32, which requires use to do a <CloseWriter> before doing the
	// close in order to avoid losing data.  Note that we don't need to
	// do this on UNIX since it doesn't have this "feature".  Moreover,
	// this will cause subtle problems on UNIX due to the way that
	// fork() works.
	if (m_Handle != CAW_INVALID_HANDLE && CAW_SUCCEEDED(aReason))
		CloseWriter();
#endif // CAW_WIN32

    return CAWSocketBase::Close();
}

inline int CAWSocketTcp::CloseWriter()
{
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    int nRet = ::shutdown((CAW_SOCKET)m_Handle, CAW_SD_SEND);

#ifdef CAW_WIN32
	if (nRet == SOCKET_ERROR) {
		errno = ::WSAGetLastError();
		nRet = -1;
	}
#endif // CAW_WIN32
    return nRet;
}

inline int CAWSocketTcp::CloseReader()
{
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    int nRet = ::shutdown((CAW_SOCKET)m_Handle, CAW_SD_RECEIVE);

#ifdef CAW_WIN32
	if (nRet == SOCKET_ERROR) {
		errno = ::WSAGetLastError();
		nRet = -1;
	}
#endif // CAW_WIN32
    return nRet;
    }

inline CAWSocketUdp::CAWSocketUdp()
{
}

inline CAWSocketUdp::~CAWSocketUdp()
{
    Close();
}

inline int CAWSocketUdp::
RecvFrom(char *aBuf, DWORD aLen, CAWInetAddr &aAddr, int aFlag) const 
{
//	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);

	int nSize = (int)aAddr.GetSize();
	int nRet = ::recvfrom((CAW_SOCKET)m_Handle,
						  aBuf,
						  aLen,
						  aFlag,
						  reinterpret_cast<sockaddr *>(const_cast<sockaddr_in *>(aAddr.GetPtr())),
#ifdef CAW_WIN32
						  &nSize
#else // !CAW_WIN32
						  reinterpret_cast<socklen_t*>(&nSize)
#endif // CAW_WIN32
						   );

#ifdef CAW_WIN32
	if (nRet == SOCKET_ERROR) {
		errno = ::WSAGetLastError();
		nRet = -1;
	}
#endif // CAW_WIN32

	return nRet;
}

inline int CAWSocketUdp::
SendTo(const char *aBuf, DWORD aLen, const CAWInetAddr &aAddr, int aFlag) const 
{
//	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);

	int nRet = ::sendto((CAW_SOCKET)m_Handle,
						  aBuf,
						  aLen,
						  aFlag,
						  reinterpret_cast<const sockaddr *>(aAddr.GetPtr()),
#ifdef CAW_WIN32
						  aAddr.GetSize()
#else // !CAW_WIN32
						  static_cast<socklen_t>(aAddr.GetSize())
#endif // CAW_WIN32
						  );

#ifdef CAW_WIN32
	if (nRet == SOCKET_ERROR) {
		errno = ::WSAGetLastError();
		nRet = -1;
	}
#endif // CAW_WIN32
	
	return nRet;
}

inline int CAWSocketUdp::
SendVTo(const iovec aIov[], DWORD aCount, const CAWInetAddr &aAddr) const 
{
    int nRet;
    //	CAW_ASSERTE(m_Handle != CAW_INVALID_HANDLE);
    CAW_ASSERTE(aIov);

#ifdef CAW_WIN32
	DWORD dwBytesSend = 0;
	nRet = ::WSASendTo((CAW_SOCKET)m_Handle,
                      (WSABUF *)aIov,
                      aCount,
                      &dwBytesSend,
                      0,
                      reinterpret_cast<const sockaddr *>(aAddr.GetPtr()),
                      aAddr.GetSize(),
					  NULL,
					  NULL);
	if (nRet == SOCKET_ERROR) {
		errno = ::WSAGetLastError();
		nRet = -1;
	}
	else {
		nRet = (int)dwBytesSend;
	}
#else // !CAW_WIN32
    msghdr send_msg;
    send_msg.msg_iov = (iovec *)aIov;
    send_msg.msg_iovlen = aCount;
    send_msg.msg_name = (struct sockaddr *)aAddr.GetPtr();
    send_msg.msg_namelen = aAddr.GetSize();
    send_msg.msg_control = 0;
    send_msg.msg_controllen = 0;
    send_msg.msg_flags = 0;
    nRet = ::sendmsg(m_Handle, &send_msg, 0);
#endif // CAW_WIN32
    return nRet;
}


#endif // !CMSOCKET_H
