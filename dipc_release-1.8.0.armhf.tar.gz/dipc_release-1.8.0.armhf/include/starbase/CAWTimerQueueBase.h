/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTIMERQUEUEBASE_H
#define CAWTIMERQUEUEBASE_H

#include "CAWMutex.h"
#include "CAWTimeValue.h"
#include "CAWThreadInterface.h"

class IAWObserver;

class CAW_OS_EXPORT CAWTimerQueueBase : public IAWTimerQueue
{
public:
    struct CNode
    {
        CNode(IAWTimerHandler *aEh = NULL, LPVOID aToken = NULL) 
        : m_pEh(aEh), m_pToken(aToken), m_dwCount(0) 
        { }
        bool operator==(const CNode &other) const
        {
            if (m_pEh == other.m_pEh)
            {
                return true; 
            }
            else
            {
                return false;
            }
        }

        IAWTimerHandler *m_pEh;
        LPVOID m_pToken;
        CAWTimeValue m_tvExpired;
        CAWTimeValue m_tvInterval;
        DWORD m_dwCount;
    };


    CAWTimerQueueBase(IAWObserver *aObserver);
    virtual ~CAWTimerQueueBase();

    // interface IAWTimerQueue
    virtual CAWResult ScheduleTimer(IAWTimerHandler *aEh, 
                            LPVOID aToken, 
                            const CAWTimeValue &aInterval,
                            DWORD aCount);

    virtual CAWResult CancelTimer(IAWTimerHandler *aEh);


    /// if the queue is empty, return CAWTimeValue::s_tvMax.
    virtual CAWTimeValue GetEarliestTime();

    /// return the number of timer expired.
    /// and fill <aRemainTime> with the sub-value of earliest time and current time,
    /// if no timer items in the queue, fill <aRemainTime> with <CAWTimeValue::s_tvMax>.
    virtual int CheckExpire(CAWTimeValue *aRemainTime = NULL);

    virtual void Dump(){};

protected:
    /// the sub-classes of CAWTimerQueueBase always use STL contains that 
    /// we just let them manage the memery allocation of CNode

    /// the following motheds are all called after locked
    virtual int PushNode_l(const CNode &aPushNode) = 0;
    virtual int EraseNode_l(IAWTimerHandler *aEh) = 0;
    virtual int RePushNode_l(const CNode &aPushNode) = 0;
    virtual int PopFirstNode_l(CNode &aPopNode) = 0;
    virtual int GetEarliestTime_l(CAWTimeValue &aEarliest) const = 0;

    typedef CAWMutexNullSingleThread MutexType;
    MutexType m_Mutex;
    IAWObserver *m_pObserver;
};

#endif // !CAWTIMERQUEUEBASE_H

