/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWDNSMANAGER_H
#define CAWDNSMANAGER_H

#if defined(CAW_WIN32) && !defined(CAW_WIN32_DISABLE_AsyncGetHostByName)
  #define CAW_WIN32_ENABLE_AsyncGetHostByName
#endif // CAW_WIN32 && !CAW_WIN32_DISANABLE_AsyncGetHostByName

#include "CAWStdCpp.h"
#include "CAWReferenceControl.h"
#include "CAWUtilTemplates.h"
#include "CAWMutex.h"
#include "CAWThreadInterface.h"
#include "CAWObserver.h"
#include <map>
#include <vector>
#include <list>

class CAWThread;
class IAWObserver;
class CAWDnsRecord;

class CAW_OS_EXPORT CAWDnsManager : public IAWEvent
{
public:
    static CAWDnsManager* Instance();
    CAWResult AsyncResolve(
        CAWDnsRecord *&aRecord,
        const CAWString &aHostName,
        IAWObserver *aObserver = NULL,
        BOOL aBypassCache = FALSE,
        CAWThread *aThreadListener = NULL);

    /// <aObserver> will not notified after calling this function.
    CAWResult CancelResolve(IAWObserver *aObserver);

    /// Check <aObserver> is the observer list or not.
    CAWResult IsInObserverList(IAWObserver *aObserver);

    /// clear the <aHostName> in the cache and resolve it again.
    /// return CAW_ERROR_WOULD_BLOCK: is relsoving.
    /// return CAW_ERROR_FAILURE: relsove failed.
    CAWResult RefreshHost(const CAWString &aHostName);

    /// close and release any resoruce.
    CAWResult Shutdown();

    CAWResult SyncResolve(
        CAWDnsRecord *&aRecord, 
        const CAWString &aHostName,
        BOOL aBypassCache = FALSE);

    CAWResult GetLocalIps(CAWDnsRecord *&aRecord);

    // interface IAWEvent
    virtual CAWResult OnEventFire();
    virtual void OnDestorySelf();

private:
    CAWDnsManager();
    virtual ~CAWDnsManager();
    friend class CAWSingletonT<CAWDnsManager>;

    int BeginResolve_l(CAWDnsRecord *aRecord);
    int DoGetHostByName_l(CAWDnsRecord *aRecord);
    CAWResult TryAddObserver_l(IAWObserver *aObserver, CAWThread *aThreadListener);
    CAWResult Resolved_l(CAWDnsRecord *aRecord, int aError, BOOL aCallback = TRUE);
    CAWResult DoCallback_l(int aError);
    CAWResult FindInCache_l(CAWDnsRecord *&aRecord, const CAWString &aHostName);
    void CopyHostent_i(CAWDnsRecord *aRecord, struct hostent *aHostent);

#ifdef CAW_WIN32_ENABLE_AsyncGetHostByName
    CAWResult CreateDnsWindow();
    int DoAsyncHostByName_l(CAWDnsRecord *aRecord);
#else
    CAWResult SpawnDnsThread_l();
#endif // CAW_WIN32_ENABLE_AsyncGetHostByName

private:
    typedef std::map<CAWString, CAWAutoPtr<CAWDnsRecord> > CacheRecordsType;
    CacheRecordsType m_CacheRecords;
    typedef std::list<CAWAutoPtr<CAWDnsRecord> > PendingRecordsType;
    PendingRecordsType m_PendingRecords;

    class CAW_OS_EXPORT CObserverAndListener : public IAWEvent
    {
    public:
        CObserverAndListener(CAWDnsManager *aDnsManager, 
            IAWObserver *aObserver, 
            CAWThread *aThreadListener, 
            int aError)
                : m_pDnsManager(aDnsManager)
                , m_pObserver(aObserver)
                , m_pThreadListener(aThreadListener)
                , m_nError(aError)
        {
            CAW_ASSERTE(m_pDnsManager);
            CAW_ASSERTE(m_pObserver);
            CAW_ASSERTE(m_pThreadListener);
        }

        bool operator == (const CObserverAndListener &aRight)
        {
            return m_pObserver == aRight.m_pObserver;
        }

        bool operator == (IAWObserver *aObserver)
        {
            return m_pObserver == aObserver;
        }

        // interface IAWEvent
        virtual CAWResult OnEventFire();

        CAWDnsManager *m_pDnsManager;
        IAWObserver *m_pObserver;
        CAWThread *m_pThreadListener;
        int m_nError;
    };
    typedef std::vector<CObserverAndListener> ObserversType;
    ObserversType m_Observers;

    typedef CAWMutexThread MutexType;
    MutexType m_Mutex;

#ifdef CAW_WIN32_ENABLE_AsyncGetHostByName
    static LRESULT CALLBACK DnsEventWndProc(
    HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    HWND m_hwndDsnWindow;
#else
    CAWThread *m_pThreadDNS;
#endif // CAW_WIN32_ENABLE_AsyncGetHostByName
    CAWThread *m_pThreadNetwork;
};

#ifdef CAW_WIN32
  #define CAW_NETDB_BUF_SIZE MAXGETHOSTSTRUCT 
#else
  #define CAW_NETDB_BUF_SIZE 1024 
#endif // CAW_WIN32

class  CAW_OS_EXPORT CAWDnsRecordHostent
{
public:
    CAWDnsRecordHostent(
        int addrtype, 
        int length,
        char *ipaddr)
    {
        h_addrtype=addrtype;
        h_length=length;
        memcpy(m_ipaddr, ipaddr, length);
    }
    ~CAWDnsRecordHostent()
    {
    }

    int     h_addrtype;     /* host address type */
    int     h_length;       /* length of address */
    char   m_ipaddr[128];
};

class CAW_OS_EXPORT CAWDnsRecord : public CAWReferenceControlMutilThread 
{
public:
    CAWDnsRecord(const CAWString &aHostName);
    virtual ~CAWDnsRecord();
    CAWString GetHostName();
    DWORD GetFirstIPAddr();
    void AddHostent(CAWDnsRecordHostent *phost);
    void GetHostList(std::list<CAWDnsRecordHostent *> &listhost);
private:
    CAWString m_strHostName;
    enum {
        RSV_IDLE,
        RSV_PROCESSING,
        RSV_SUCCESS,
        RSV_FAILED,
    } m_State;
#ifdef CAW_WIN32_ENABLE_AsyncGetHostByName
    HANDLE m_HandleResolve;
#else
#endif // CAW_WIN32_ENABLE_AsyncGetHostByName
    // contains struct hostent.
    char m_szBuffer[CAW_NETDB_BUF_SIZE];
    std::list<CAWDnsRecordHostent *> m_list;
    typedef CAWMutexThread MutexType;
    MutexType m_Mutex;
    friend class CAWDnsManager;
};

#endif // !CAWDNSMANAGER_H