/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWFILE_H
#define CAWFILE_H
#include "CAWDefines.h"
#include "CAWString.h"
#include "CAWDebug.h"
#include "CAWMessageBlock.h"
#include "CAWError.h"
class CAW_OS_EXPORT CAWFile
{
public:

    CAWFile();
    ~CAWFile();
    size_t GetFileSize(const CAWString &name);
    CAWResult ReadFile(const CAWString &name, CAWMessageBlock &aData);
    CAWResult WriteFile(const CAWString &name, CAWMessageBlock &aData);
    CAWResult Mkdir(const CAWString &name);
    CAWResult DeleteFile(const CAWString &name);
    bool IsDir(const CAWString &path);
    CAWResult DeleteDir(const CAWString &name);
    static CAWString GetFileNameFromPath(const CAWString &strpath);
    static CAWResult mkdir(const CAWString &dirname);
private:
    char *filedata;
    size_t filedatasize;
};

CAW_OS_EXPORT size_t WFFileGetFileSize(const char * szFile);
CAW_OS_EXPORT int WFFileGetFileContent(const char * szFileName,
	char ** szBuff,
	size_t& size);
CAW_OS_EXPORT void WFFileFreeFileContent(char *pcontent);
CAW_OS_EXPORT bool IsDir(char *ppath);

#endif//CFILEOBJECT_H

