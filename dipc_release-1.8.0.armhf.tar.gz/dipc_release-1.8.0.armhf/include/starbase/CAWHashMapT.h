/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/

#ifndef CAWHASHMAPT_H
#define CAWHASHMAPT_H

#include "CAWStdCpp.h"
#include <vector>
#include <functional>
#include <unordered_map>

#define CAWHashMapT std::unordered_map

#endif // CAWHASHMAPT_H

