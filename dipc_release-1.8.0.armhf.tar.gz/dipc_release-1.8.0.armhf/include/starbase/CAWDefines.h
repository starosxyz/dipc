/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWDEFINES_H
#define CAWDEFINES_H
//////////////////////////////////////////////////////////////////////
// First definition: choose OS
//////////////////////////////////////////////////////////////////////

#ifdef WIN32
  #ifndef CAW_WIN32
    #define CAW_WIN32 1
  #endif // CAW_WIN32
#endif // WIN32

#ifdef UNIX
  #ifndef CAW_UNIX
    #define CAW_UNIX
  #endif // CAW_UNIX
    //#define CAW_USE_OPENSSL
#endif // UNIX

#ifdef LINUX
  #ifndef CAW_LINUX
    #define CAW_LINUX
    //#define CAW_USE_OPENSSL
  #endif // CAW_LINUX
  #ifndef CAW_UNIX
    #define CAW_UNIX
    //#define CAW_USE_OPENSSL 1
  #endif // CAW_UNIX
#endif // LINUX

//////////////////////////////////////////////////////////////////////
// C definition
//////////////////////////////////////////////////////////////////////

#ifdef CAW_WIN32
  #include <string.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <time.h>
  #include <limits.h>
  #include <stddef.h>
  #include <stdarg.h>
  #include <signal.h>
  #include <errno.h>
  #include <wchar.h>
  #include <stdint.h>
  #include <direct.h>
  #include <io.h>
  #include <fcntl.h>
  #include <crtdbg.h>
  #include <process.h>
  #define getpid _getpid
  #define snprintf _snprintf
  #define strcasecmp _stricmp
  #define strncasecmp _strnicmp
  #define vsnprintf _vsnprintf
#  if !defined (S_IRWXG)
#    define S_IRWXG 00070
#  endif /* S_IRWXG */
#  if !defined (S_IRGRP)
#    define S_IRGRP 00040
#  endif /* S_IRGRP */
#  if !defined (S_IWGRP)
#    define S_IWGRP 00020
#  endif /* S_IWGRP */
#  if !defined (S_IXGRP)
#    define S_IXGRP 00010
#  endif /* S_IXGRP */
#  if !defined (S_IRWXO)
#    define S_IRWXO 00007
#  endif /* S_IRWXO */
#  if !defined (S_IROTH)
#    define S_IROTH 00004
#  endif /* S_IROTH */
#  if !defined (S_IWOTH)
#    define S_IWOTH 00002
#  endif /* S_IWOTH */
#  if !defined (S_IXOTH)
#    define S_IXOTH 00001
#  endif /* S_IXOTH */
#endif // CAW_WIN32

#ifdef CAW_UNIX
  #include <stdint.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <unistd.h>
  #include <errno.h>
  #include <limits.h>
  #include <stdarg.h>
  #include <time.h>
  #include <signal.h>
  #include <sys/stat.h>
  #include <sys/fcntl.h>
  #include <pthread.h>
  #include <fcntl.h>
  #include <sys/types.h>
  #include <sys/ioctl.h>
  #include <sys/socket.h>
  #include <sys/time.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <netdb.h>
  #include <ctype.h>
  #include <sys/poll.h>
  #include <linux/unistd.h>
  #include <linux/types.h>
//#include <linux/sysctl.h>
  #include <sys/syscall.h>
  #include <dirent.h>
  #include <sys/wait.h>
  #define EWOULDBLOCK EAGAIN
 
  #include <assert.h>
#endif // CAW_UNIX


typedef long CAWResult;
typedef unsigned long long  WORD64;
typedef long long           SWORD64;
typedef unsigned int        WORD32;
typedef int                 SWORD32;
typedef unsigned short      WORD16;
typedef short               SWORD16;

#ifndef CAW_WIN32
typedef unsigned char       BYTE;
typedef char                CHAR;
#endif

//////////////////////////////////////////////////////////////////////
// OS API definition
//////////////////////////////////////////////////////////////////////

#ifdef CAW_WIN32
  #ifndef NOMINMAX
    #define NOMINMAX
  #endif // NOMINMAX

  // supports Windows NT 4.0 and later, not support Windows 95.
  // mainly for using winsock2 functions
  #ifndef _WIN32_WINNT
    //#define _WIN32_WINNT 0x0400
    #define _WIN32_WINNT 0x0403
   #endif // _WIN32_WINNT
  #define _WINSOCKAPI_    // stops windows.h including winsock.h
  #include <windows.h>
  #include <winsock2.h>
  #include <WS2tcpip.h>
  #undef min
  #undef max
  #undef SetPort

#undef EWOULDBLOCK
#undef EINPROGRESS
#undef EALREADY 
#undef ENOTSOCK
#undef EDESTADDRREQ 
#undef EMSGSIZE 
#undef EPROTOTYPE
#undef ENOPROTOOPT
#undef EPROTONOSUPPORT
#undef ESOCKTNOSUPPORT
#undef EOPNOTSUPP
#undef EPFNOSUPPORT
#undef EAFNOSUPPORT
#undef EADDRINUSE
#undef EADDRNOTAVAIL
#undef ENETDOWN
#undef ENETUNREACH
#undef ENETRESET
#undef ECONNABORTED
#undef ECONNRESET
#undef ENOBUFS
#undef EISCONN
#undef ENOTCONN
#undef ESHUTDOWN
#undef ETOOMANYREFS
#undef ETIMEDOUT
#undef ECONNREFUSED
#undef ELOOP
#undef EHOSTDOWN
#undef EHOSTUNREACH
#undef EPROCLIM
#undef EUSERS
#undef EDQUOT
#undef ESTALE
#undef EREMOTE


  #define EWOULDBLOCK             WSAEWOULDBLOCK
  #define EINPROGRESS             WSAEINPROGRESS
  #define EALREADY                WSAEALREADY
  #define ENOTSOCK                WSAENOTSOCK
  #define EDESTADDRREQ            WSAEDESTADDRREQ
  #define EMSGSIZE                WSAEMSGSIZE
  #define EPROTOTYPE              WSAEPROTOTYPE
  #define ENOPROTOOPT             WSAENOPROTOOPT
  #define EPROTONOSUPPORT         WSAEPROTONOSUPPORT
  #define ESOCKTNOSUPPORT         WSAESOCKTNOSUPPORT
  #define EOPNOTSUPP              WSAEOPNOTSUPP
  #define EPFNOSUPPORT            WSAEPFNOSUPPORT
  #define EAFNOSUPPORT            WSAEAFNOSUPPORT
  #define EADDRINUSE              WSAEADDRINUSE
  #define EADDRNOTAVAIL           WSAEADDRNOTAVAIL
  #define ENETDOWN                WSAENETDOWN
  #define ENETUNREACH             WSAENETUNREACH
  #define ENETRESET               WSAENETRESET
  #define ECONNABORTED            WSAECONNABORTED
  #define ECONNRESET              WSAECONNRESET
  #define ENOBUFS                 WSAENOBUFS
  #define EISCONN                 WSAEISCONN
  #define ENOTCONN                WSAENOTCONN
  #define ESHUTDOWN               WSAESHUTDOWN
  #define ETOOMANYREFS            WSAETOOMANYREFS
  #define ETIMEDOUT               WSAETIMEDOUT
  #define ECONNREFUSED            WSAECONNREFUSED
  #define ELOOP                   WSAELOOP
  #define EHOSTDOWN               WSAEHOSTDOWN
  #define EHOSTUNREACH            WSAEHOSTUNREACH
  #define EPROCLIM                WSAEPROCLIM
  #define EUSERS                  WSAEUSERS
  #define EDQUOT                  WSAEDQUOT
  #define ESTALE                  WSAESTALE
  #define EREMOTE                 WSAEREMOTE

    struct iovec
    {
        /// byte count to read/write
        u_long iov_len;
        /// data to be read/written
        char *iov_base;

        // WSABUF is a Winsock2-only type.
        operator WSABUF &(void) { return *((WSABUF *) this); }
    };
	# define S_ISDIR(mode)   ((mode&S_IFMT) == S_IFDIR)

#endif // CAW_WIN32

#ifdef CAW_WIN32
  typedef HANDLE CAW_HANDLE;
  typedef SOCKET CAW_SOCKET;
  #define CAW_INVALID_HANDLE INVALID_HANDLE_VALUE
  #define CAW_SD_RECEIVE SD_RECEIVE
  #define CAW_SD_SEND SD_SEND
  #define CAW_SD_BOTH SD_BOTH
#else // !CAW_WIN32
  typedef int CAW_HANDLE;
  typedef CAW_HANDLE CAW_SOCKET;
  #define CAW_INVALID_HANDLE -1
  #define CAW_SD_RECEIVE 0
  #define CAW_SD_SEND 1
  #define CAW_SD_BOTH 2
#endif // CAW_WIN32

#ifndef CAW_WIN32
  typedef long long           LONGLONG;
  typedef unsigned long       DWORD;
  typedef long                LONG;
  typedef int                 BOOL;
  typedef unsigned char       BYTE;
  typedef unsigned short        WORD;
  typedef float                 FLOAT;
  typedef int                   INT;
  typedef unsigned int          UINT;
  typedef FLOAT                *PFLOAT;
  typedef BOOL                 *LPBOOL;
  typedef int                  *LPINT;
  typedef WORD                 *LPWORD;
  typedef long                 *LPLONG;
  typedef DWORD                *LPDWORD;
  typedef unsigned int         *LPUINT;
  typedef void                 *LPVOID;
  typedef const void           *LPCVOID;
  typedef char                  CHAR;
  typedef char                  TCHAR;
  typedef unsigned short        WCHAR;
  typedef const char           *LPCSTR;
  typedef char                 *LPSTR;
  typedef const unsigned short *LPCWSTR;
  typedef unsigned short       *LPWSTR;
  typedef BYTE                 *LPBYTE;
  typedef const BYTE           *LPCBYTE;
  
  #ifndef FALSE
    #define FALSE 0
  #endif // FALSE
  #ifndef TRUE
    #define TRUE 1
  #endif // TRUE
#endif // !CAW_WIN32

#ifdef _MSC_VER
  #ifndef _MT
    #error Error: please use multithread version of C runtime library.
  #endif // _MT

  #pragma warning(disable: 4786) // identifier was truncated to '255' characters in the browser information(mainly brought by stl)
  #pragma warning(disable: 4355) // disable 'this' used in base member initializer list
  #pragma warning(disable: 4275) // deriving exported class from non-exported
  #pragma warning(disable: 4251) // using non-exported as public in exported
  #pragma warning(disable: 4244) // 
  #pragma warning(disable: 4819) // 
  #pragma warning(disable: 4200) // 
#endif // _MSC_VER

#ifdef CAW_WIN32

  #if defined (_LIB) || (CAW_OS_BUILD_LIB) 
    #define CAW_OS_EXPORT
  #else 
    #if defined (_USRDLL) || (CAW_OS_BUILD_DLL)
      #define CAW_OS_EXPORT __declspec(dllexport)
    #else 
      #define CAW_OS_EXPORT __declspec(dllimport)
    #endif // _USRDLL || CAW_OS_BUILD_DLL
  #endif // _LIB || CAW_OS_BUILD_LIB
#else
    #if defined (CAW_OS_BUILD_DLL)
		#if __GNUC__ >= 4
		  #define CAW_OS_EXPORT __attribute__ ((visibility("default")))
		#else
		  #define CAW_OS_EXPORT
		#endif
	#else
	  #define CAW_OS_EXPORT
    #endif
#endif // !CAW_WIN32

#if defined (CAW_WIN32)
  #define CAW_OS_SEPARATE '\\'
#elif defined (CAW_UNIX)
  #define CAW_OS_SEPARATE '/'
#endif

#define CAW_BIT_ENABLED(dword, bit) (((dword) & (bit)) != 0)
#define CAW_BIT_DISABLED(dword, bit) (((dword) & (bit)) == 0)
#define CAW_BIT_CMP_MASK(dword, bit, mask) (((dword) & (bit)) == mask)
#define CAW_SET_BITS(dword, bits) (dword |= (bits))
#define CAW_CLR_BITS(dword, bits) (dword &= ~(bits))


#ifdef CAW_WIN32
  #define CAW_IOV_MAX 64
#else
  // This is defined by XOPEN to be a minimum of 16.  POSIX.1g
  // also defines this value.  platform-specific config.h can
  // override this if need be.
  #if !defined (IOV_MAX)
    #define IOV_MAX 16
  #endif // !IOV_MAX
  #define CAW_IOV_MAX IOV_MAX
#endif // CAW_WIN32

#ifdef CAW_WIN32
  typedef DWORD CAW_THREAD_ID;
  typedef HANDLE CAW_THREAD_HANDLE;
  typedef DWORD CAW_PID;
#else // !CAW_WIN32
  typedef pthread_t CAW_THREAD_ID;
  typedef CAW_THREAD_ID CAW_THREAD_HANDLE;
  typedef pid_t CAW_PID;
#endif // CAW_WIN32
  
//////////////////////////////////////////////////////////////////////
// Assert
//////////////////////////////////////////////////////////////////////

#ifdef CAW_WIN32
  #include <crtdbg.h>
  #ifdef _DEBUG
	#ifndef CAW_DEBUG
		#define CAW_DEBUG
	#endif
  #endif // _DEBUG

  #if defined (CAW_DEBUG)
    #define CAW_ASSERTE _ASSERTE
  #endif // CAW_DEBUG
#endif // CAW_WIN32

#if defined (CAW_UNIX) || defined(CAW_LINUX)
  #include <assert.h>
  #if defined (CAW_DEBUG) && !defined (CAW_DISABLE_ASSERTE)
    #define CAW_ASSERTE assert
  #endif // CAW_DEBUG
#endif // CAW_UNIX

#ifdef CAW_DISABLE_ASSERTE
  #include "CAWDebug.h"
  #define CAW_ASSERTE(expr) \
    do { \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ':' << __LINE__ << " Assert failed: " << #expr); \
        } \
    } while (0)
#endif // CAW_DISABLE_ASSERTE

#ifndef CAW_ASSERTE
  #define CAW_ASSERTE(expr) 
#endif // CAW_ASSERTE

//#define CAW_ASSERTE_THROW CAW_ASSERTE

#ifdef CAW_DISABLE_ASSERTE
  #define CAW_ASSERTE_RETURN(expr, rv) \
    do { \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ":" << __LINE__ << " Assert failed: " << #expr); \
            return rv; \
        } \
    } while (0)

  #define CAW_ASSERTE_RETURN_VOID(expr) \
    do { \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ":" << __LINE__ << " Assert failed: " << #expr); \
            return; \
        } \
    } while (0)
#else
  #define CAW_ASSERTE_RETURN(expr, rv) \
    do { \
        CAW_ASSERTE((expr)); \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ":" << __LINE__ << " Assert failed: " << #expr); \
            return rv; \
        } \
    } while (0)

  #define CAW_ASSERTE_RETURN_VOID(expr) \
    do { \
        CAW_ASSERTE((expr)); \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ":" << __LINE__ << " Assert failed: " << #expr); \
            return; \
        } \
    } while (0)

#endif // CAW_DISABLE_ASSERTE

#ifndef CAW_WIN32
#ifndef UINT_MAX
#define	UINT_MAX	4294967295U
#endif

#ifndef UINT32_MAX
#define	UINT32_MAX	4294967295U
#endif

#endif

static inline uint64_t
caw_htonll(uint64_t n)
{
    return htonl(1) == 1 ? n : ((uint64_t) htonl(n) << 32) | htonl(n >> 32);
}

static inline uint64_t
caw_ntohll(uint64_t n)
{ 
    return htonl(1) == 1 ? n : ((uint64_t) ntohl(n) << 32) | ntohl(n >> 32);
}

#if defined (ghs) || defined (__GNUC__) || defined (__hpux) || defined (__sgi) || defined (__DECCXX) || defined (__KCC) || defined (__rational__) || defined (__USLC__) || defined (CAW_RM544)
// Some compilers complain about "statement with no effect" with (a).
// This eliminates the warnings, and no code is generated for the null
// conditional statement.  NOTE: that may only be true if -O is enabled,
// such as with GreenHills (ghs) 1.8.8.
#define CAW_UNUSED_ARG(a) do {/* null */} while (&a == 0)
#else /* ghs || __GNUC__ || ..... */
#define CAW_UNUSED_ARG(a) (a)
#endif /* ghs || __GNUC__ || ..... */

template<class T> inline T caw_min(T a, T b) { return (a > b) ? b : a; }
template<class T> inline T caw_max(T a, T b) { return (a < b) ? b : a; }

#define DISALLOW_ASSIGN(TypeName) \
  void operator=(const TypeName&)

// A macro to disallow the evil copy constructor and operator= functions
// This should be used in the private: declarations for a class.
// Undefine this, just in case. Some third-party includes have their own
// version.
#undef DISALLOW_COPY_AND_ASSIGN
#define DISALLOW_COPY_AND_ASSIGN(TypeName)    \
  TypeName(const TypeName&);                    \
  DISALLOW_ASSIGN(TypeName)

// Alternative, less-accurate legacy name.
#define DISALLOW_EVIL_CONSTRUCTORS(TypeName) \
  DISALLOW_COPY_AND_ASSIGN(TypeName)

// A macro to disallow all the implicit constructors, namely the
// default constructor, copy constructor and operator= functions.
//
// This should be used in the private: declarations for a class
// that wants to prevent anyone from instantiating it. This is
// especially useful for classes containing only static methods.
#define DISALLOW_IMPLICIT_CONSTRUCTORS(TypeName) \
  TypeName();                                    \
  DISALLOW_EVIL_CONSTRUCTORS(TypeName)

// Note that we are using PATH_MAX instead of _POSIX_PATH_MAX, since
// _POSIX_PATH_MAX is the *minimun* maximum value for PATH_MAX and is
// defined by POSIX as 256.
#if !defined (PATH_MAX)
#  if defined (_MAX_PATH)
#    define PATH_MAX _MAX_PATH
#  elif defined (MAX_PATH)
#    define PATH_MAX MAX_PATH
#  else /* !_MAX_PATH */
#    define PATH_MAX 1024
#  endif /* _MAX_PATH */
#endif /* !PATH_MAX */

// Leaving this for backward compatibility, but PATH_MAX should always be
// used directly.
#if !defined (MAXPATHLEN)
#  define MAXPATHLEN  PATH_MAX
#endif /* !MAXPATHLEN */

// This is defined by XOPEN to be a minimum of 16.  POSIX.1g
// also defines this value.  platform-specific config.h can
// override this if need be.
#if !defined (IOV_MAX)
#  define IOV_MAX 16
#endif /* IOV_MAX */

#endif // !CAWDEFINES_H

