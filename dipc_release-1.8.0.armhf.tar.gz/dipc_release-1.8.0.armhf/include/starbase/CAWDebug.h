/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWDEBUG_H
#define CAWDEBUG_H
#include "CAWDefines.h"
#include "CAWString.h"

typedef enum Ordix
{
    formator_hex     = 0,
    formator_decimal = 1
} Ordix;

class CAW_OS_EXPORT Text_Formator
{
public :
    Text_Formator(char* lpszBuf, unsigned long dwBufSize);
    virtual ~Text_Formator();
public :
    void reset();
    Text_Formator& operator << (char ch);
    Text_Formator& operator << (unsigned char ch);
    Text_Formator& operator << (short s);
    Text_Formator& operator << (unsigned short s);
    Text_Formator& operator << (int i);
    Text_Formator& operator << (unsigned int i);
    Text_Formator& operator << (long l);
    Text_Formator& operator << (long long l);
    Text_Formator& operator << (unsigned long long l);
    Text_Formator& operator << (unsigned long l);
    Text_Formator& operator << (float f);
    Text_Formator& operator << (double d);
    Text_Formator& operator << (const char* lpsz);
    Text_Formator& operator << (void* lpv);
    Text_Formator& operator << (Ordix ordix);
    Text_Formator& operator << (const CAWString& str);
    operator char*();
private :
    void set_hex_flag(unsigned char bValue);
    unsigned char get_hex_flag();
    void advance(const char* lpsz);
private :
    char*  m_lpszBuf;
    unsigned long  m_dwSize;
    unsigned long  m_dwPos;
    unsigned char m_bHex;
};

class CAW_OS_EXPORT IAWTraceManager 
{
public:
    static IAWTraceManager &Instance();
    virtual void TraceString(unsigned long dwMask, char* lpsz)=0;
    virtual void FatalTraceString(unsigned long dwMask, char* lpsz)=0;
protected:
    virtual ~IAWTraceManager(){};
};

#define CAW_TRACE(mask, str)\
{ \
    char achFormatBuf[2048];\
    Text_Formator formator(achFormatBuf, 2048); \
    IAWTraceManager::Instance().TraceString(mask, formator<< str); \
}


#ifndef CAW_DISABLE_TRACE
#if (defined (CAW_WIN32) && !defined (CAW_DEBUG))
#define CAW_ERROR_TRACE(str)      CAW_TRACE(1, str)
#define CAW_WARNING_TRACE(str)    CAW_TRACE(2, str)
#define CAW_INFO_TRACE(str)       CAW_TRACE(3, str)
#else
#define CAW_ERROR_TRACE(str)      CAW_TRACE(1, str)
#define CAW_WARNING_TRACE(str)    CAW_TRACE(11, str)
#define CAW_INFO_TRACE(str)       CAW_TRACE(21, str)
#endif //for client trace
#define CAW_ERROR_TRACE_THIS(str)    CAW_ERROR_TRACE(str << " this=" << this)
#define CAW_WARNING_TRACE_THIS(str)  CAW_WARNING_TRACE(str << " this=" << this)
#define CAW_INFO_TRACE_THIS(str)     CAW_INFO_TRACE(str << " this=" << this)
#define CAW_INFO_TRACE_FUNC(str)     CAW_INFO_TRACE(__func__ << "(): " << str)
#else//!CAW_DISABLE_TRACE

#define CAW_ERROR_TRACE(str) 
#define CAW_WARNING_TRACE(str) 
#define CAW_INFO_TRACE(str) 


///////////////////////////////////////////////////
#define CAW_ERROR_TRACE_THIS(str) 
#define CAW_WARNING_TRACE_THIS(str) 
#define CAW_INFO_TRACE_THIS(str) 
#define CAW_INFO_TRACE_FUNC(str)
#endif // CAW_DISABLE_TRACE

//#define CAW_FATAL_TRACE(str)        CAW_TRACE(0, str)
//#define CAW_FATAL_TRACE_THIS(str)   CAW_FATAL_TRACE(str << " this=" << this)

#define FATAL_TRACE(mask, str)\
{ \
    char achFormatBuf[2048];\
    Text_Formator formator(achFormatBuf, 2048); \
    IAWTraceManager::Instance().FatalTraceString(mask, formator<< str); \
}

#define CAW_FATAL_TRACE(str)        FATAL_TRACE(0, str)
#define CAW_FATAL_TRACE_THIS(str)   CAW_FATAL_TRACE(str << " this=" << this)


#endif // CAWDEBUG_H


