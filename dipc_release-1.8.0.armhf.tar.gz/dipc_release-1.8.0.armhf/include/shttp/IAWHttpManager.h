/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IMINIHTTPMANAGER_H
#define IMINIHTTPMANAGER_H

#include "CAWACEWrapper.h"


class IAWChannel;
  class IAWChannelHttpClient;
  class IAWChannelHttpServer;
class IAWChannelSink;
class IAWChannelServerAcceptor;
class IAWChannelServerSink;

class CAW_OS_EXPORT IAWWebSocketSink 
{
public:
    virtual void OnWebSocketOpen() = 0;
    virtual void OnWebSocketReceive(CAWMessageBlock &aData) = 0;
    virtual void OnWebSocketDisconnect(const CAWString &reason) = 0;
protected:
    virtual ~IAWWebSocketSink() {}
};

class CAW_OS_EXPORT IAWHttpManager
{
public:
    static IAWHttpManager* Instance();
    virtual ~IAWHttpManager(){}
    /// Create <IAWChannelHttpClient> for HTTP client.
    virtual CAWResult CreateChannelHttpClient(
                IAWChannelHttpClient *&aClient,
                const CAWString &strURL) = 0;

    /// Create <IAWAcceptor> for HTTP server.
    virtual CAWResult CreateHttpAcceptor(IAWChannelServerAcceptor *&aAcceptor) = 0;
    virtual CAWResult CreateChannelHttpsClient(
                IAWChannelHttpClient *&aClient,
                const CAWString &strURL) = 0;

    /// Create <IAWAcceptor> for HTTP server.
    virtual CAWResult CreateHttpsAcceptor(IAWChannelServerAcceptor *&aAcceptor,
        const CAWString &cerfile,
        const CAWString &keyfile) = 0;

};

class CAW_OS_EXPORT IAWChannel : public IAWTransport
{
public:
    /// Begin SendPrivateData().
    virtual CAWResult AsyncOpen(IAWChannelSink *aSink) = 0;
    /// Get URL such as 'http://...'
    virtual CAWResult GetUrlPath(CAWString &strURLPath) = 0;
    
    virtual void BasicAuthenInfo(const CAWString &usernmae, const CAWString &password) = 0;
protected:
    virtual ~IAWChannel() { }
};

class CAW_OS_EXPORT IAWChannelSink : public IAWTransportSink
{
public:
    /// Channel is connected.
    virtual void OnConnect(CAWResult aReason, IAWChannel *aChannelId) = 0;
protected:
    virtual ~IAWChannelSink() { }
};

class CAW_OS_EXPORT IAWChannelHttpClient : public IAWChannel
{
public:
    /// Set request info before sending request.
    virtual CAWResult SetOrAddRequestHeader(
        const CAWString &aHeader, 
        const CAWString &aValue) = 0;

    /// Set request info before sending request.
    virtual CAWResult SetRequestMethod(const CAWString &aMethod) = 0;

    /// Get request info after SetRequestMethod.
    virtual CAWResult GetRequestMethod(CAWString &aMethod) = 0;

    /// Get response info after IAWChannelSink::OnStartChannel.
    virtual CAWResult GetResponseStatus(LONG &aStatus) = 0;

    /// Get response info after IAWChannelSink::OnStartChannel.
    virtual CAWResult GetResponseHeader(
        const CAWString &aHeader, 
        CAWString &aValue) = 0;

    virtual CAWResult ConnectWebSocket(IAWWebSocketSink *aWebsocketSink) = 0;
    virtual CAWResult SendWebSocketText(CAWMessageBlock &aData) = 0;
    virtual CAWResult SendWebSocketBinary(CAWMessageBlock &aData) = 0;

    virtual CAWResult CloseWebSocket() = 0;
protected:
    virtual ~IAWChannelHttpClient() { }
};

class CAW_OS_EXPORT IAWChannelHttpServer : public IAWTransport
{
public:
    virtual CAWResult EnableKeepAlive(bool keepalive)=0;
    virtual CAWResult ClearResponseHeader() =0;
    /// Set response info before sending response.
    virtual CAWResult SetOrAddResponseHeader(
        const CAWString &aHeader, 
        const CAWString &aValue) = 0;

    /// Set response info before sending response.
    virtual CAWResult SetResponseStatus(
        DWORD aStatus, 
        const CAWString &aText) = 0;

    /// Get request info after IAWChannelSink::OnDataArrival.
    virtual CAWResult GetRequestMethod(CAWString &aMethod) = 0;

    /// Get request info after IAWChannelSink::OnDataArrival.
    virtual CAWResult GetRequestHeader(
        const CAWString &aHeader, 
        CAWString &aValue) = 0;

    /// Get request info after IAWChannelSink::OnDataArrival.
    virtual CAWResult GetRequestPath(CAWString &aPath) = 0;

    virtual IAWTransport* GetTcpTransport() = 0;
    virtual CAWResult AcceptWebSocketRequest(IAWWebSocketSink *psink) = 0;
    virtual CAWResult SendWebSocketText(CAWMessageBlock &aData) = 0;
    virtual CAWResult SendWebSocketBinary(CAWMessageBlock &aData) = 0;
protected:
    virtual ~IAWChannelHttpServer() { }
};

class CAW_OS_EXPORT IAWChannelServerAcceptor : public IAWReferenceControl
{
public:
    virtual CAWResult StartListen(
        IAWChannelServerSink *aSink,
        const CAWInetAddr &aAddrListen) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

protected:
    virtual ~IAWChannelServerAcceptor() {}
};

class CAW_OS_EXPORT IAWChannelServerSink
{
public:
    /// Channel of server is created.
    /// You should invoke AsyncOpen() in this function.
    virtual void OnServerCreation(IAWChannelHttpServer *aServer) = 0;

protected:
    virtual ~IAWChannelServerSink() { }
};

#endif // IMINIHTTPINTERFACE_H
