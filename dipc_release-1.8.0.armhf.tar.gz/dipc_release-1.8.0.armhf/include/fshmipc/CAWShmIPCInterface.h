/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWSHMIPCINTERFACE_H
#define CAWSHMIPCINTERFACE_H

#include "CAWDefines.h"
#include "CAWReferenceControl.h"
#include "CAWUtilTemplates.h"
#include "CAWMutex.h"
#include "CAWShmIPCAddr.h"

class CAWTimeValue;
class CAWMessageBlock;

class IAWShmIPCAcceptorConnectorSink;
class IAWShmIPCTransportSink;
class IAWReferenceControl;
  class IAWShmIPCTransport;
  class IAWShmIPCAcceptorConnectorId;
    class IAWShmIPCConnector;
    class IAWShmIPCAcceptor;

class CAW_OS_EXPORT CAWShmIPCManager
{
public:
    static CAWShmIPCManager* Instance();
    virtual ~CAWShmIPCManager(){}
    virtual CAWResult SetSHMSize(size_t shmsize) = 0;
    virtual size_t GetSHMSize()=0;
    virtual void SetShmIPCSystemDir(const CAWString &dirname)=0;
    virtual CAWString GetShmIPCSystemDir()=0;
    virtual CAWResult CreateShmIPCClient(CAWAutoPtr<IAWShmIPCConnector> &aConClient) = 0;
    virtual CAWResult CreateShmIPCServer(CAWAutoPtr<IAWShmIPCAcceptor> &aAcceptor) = 0;
};

class CAW_OS_EXPORT CAWShmIPCTransportParameter
{
public:
    CAWShmIPCTransportParameter()
        : m_dwHaveSent(0)
    {
    }

    DWORD m_dwHaveSent;
};

/// the sink classes don't need ReferenceControl
class CAW_OS_EXPORT IAWShmIPCAcceptorConnectorSink 
{
public:
    virtual void OnShmIPCConnectIndication(
        CAWResult aReason,
        IAWShmIPCTransport *aTrpt,
        IAWShmIPCAcceptorConnectorId *aRequestId) = 0;

protected:
    virtual ~IAWShmIPCAcceptorConnectorSink() {}
};

class CAW_OS_EXPORT IAWShmIPCTransportSink 
{
public:
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWShmIPCTransport *aTrptId,
        CAWShmIPCTransportParameter *aPara = NULL) = 0;

    virtual void OnSend(
        IAWShmIPCTransport *aTrptId,
        CAWShmIPCTransportParameter *aPara = NULL) = 0;

    virtual void OnDisconnect(
    CAWResult aReason,
    IAWShmIPCTransport *aTrptId) = 0;

protected:
    virtual ~IAWShmIPCTransportSink() {}
};

class CAW_OS_EXPORT IAWShmIPCTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWShmIPCTransportSink *aSink) = 0;

    virtual IAWShmIPCTransportSink* GetSink() = 0;

    virtual CAWResult SendData(CAWMessageBlock &aData, CAWShmIPCTransportParameter *aPara = NULL) = 0;
    virtual CAWResult SendData(const char *msg,
                                size_t msgsize,
                                CAWShmIPCTransportParameter *aPara=NULL) =0;

    /** \brief get transport peer ip address
    * @param peeraddr  output peeraddr
     * @return  void
     */
    virtual void GetShmIPCPeerAddr(CAWShmIPCAddr &peeraddr) = 0;
    
    /** \brief get transport local ip address
    * @param peeraddr  output localaddr
     * @return  void
     */
    virtual void GetShmIPCLocalAddr(CAWShmIPCAddr &peeraddr) = 0;


    /// Disconnect the connection, and will not callback <IAWTransportSink> longer.
    virtual CAWResult Disconnect(CAWResult aReason) = 0;
    virtual CAW_HANDLE GetTransportHandle() const = 0;

protected:
    virtual ~IAWShmIPCTransport() {}
};


class CAW_OS_EXPORT IAWShmIPCAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWShmIPCAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWShmIPCConnector : public IAWShmIPCAcceptorConnectorId
{
public:
    virtual void AsycConnect(
        IAWShmIPCAcceptorConnectorSink *aSink,
        const CAWShmIPCAddr &aAddrPeer, 
        CAWTimeValue *aTimeout = NULL,
        CAWShmIPCAddr *aAddrLocal=NULL) = 0;

    virtual void CancelConnect() = 0;

protected:
    virtual ~IAWShmIPCConnector() {}
};

class CAW_OS_EXPORT IAWShmIPCAcceptor : public IAWShmIPCAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IAWShmIPCAcceptorConnectorSink *aSink,const CAWShmIPCAddr &aAddrListen) = 0;
    virtual CAWResult StopListen(CAWResult aReason) = 0;
protected:
    virtual ~IAWShmIPCAcceptor() {}
};

class CAW_OS_EXPORT IAWShmIPCConnectorInternal
{
public:
    virtual int Connect(const CAWShmIPCAddr &aAddr, CAWShmIPCAddr *aAddrLocal = NULL) = 0;
    virtual int Close() = 0;
    virtual ~IAWShmIPCConnectorInternal() { }
};


#endif // CAWSHMIPCINTERFACE_H

