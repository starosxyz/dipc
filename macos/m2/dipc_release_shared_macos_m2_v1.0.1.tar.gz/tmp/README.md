DIPC
===================
# 分布式进程间通信

关于DIPC
DIPC作为基于python库的一个异步事件驱动的模型
DIPC当初被设计多进程之间的数据同步架构，用于可扩展的网络应用。
在下面的 “TCPServer” 示例中，可以并发处理许多连接，
每一个连接都会触发一个事件回调，当没有事件，DIPC会处于等待状态。
例如：
<?xml version="1.0" encoding="UTF-8"?>
<starlang xmlns="http://www.staros.xyz/starcore" scope="application">
	<string name="teststring2" value="'ssssss'"/>
	<function name="TCPServer">
		<log>TCPServer</log>
		<function name="TransportStartServer">
			<parameters>
				<string name="ip" in="'0.0.0.0'"/>
				<string name="port" in="'2223'"/>
				<string name="protocol" in="'tcp'"/>
				<string name="dataevent" in="'TCPServer.Recive.Event'"/>
				<string name="cerfile" in="''"/>
				<string name="keyfile" in="''"/>
				<string name="disconnectevent" in="'TCPServer.Disconnect.Event'"/>
				<string name="connectedevent" in="'TCPServer.Connected.Event'"/>
				<string name="resultevent" in="'TCPServer.result'"/>
			</parameters>
		</function>
	</function>
	<events>
		<onevent event="TCPServer.result">
			<log>TCPServer.result</log>
			<log><![CDATA[
				result <%=event.getParam('result').toString()%>
			]]> </log>
		</onevent>
		<onevent event="TCPServer.Recive.Event">
			<log>TCPServer.Recive.Event</log>
			<messageblock name="msgblockparam"/>
			<messageblock name="msgblockparam2" size="8"/>
			<messageblock name="msgblockparam3" size="8"/>
			<messageblock name="msgblockparam4" size="20"/>
			<messageblock name="sssssssssss" size="context.teststring2.toString().length"/>
			<uint32 name="data32"/>
			<uint16 name="data16"/>
			<uint16 name="data16_2"/>
			<function>
				<log>TCPServer.Recive.Event</log>
				<set name="msgblockparam" value="event.getMessageBlock()"/>
				<log><![CDATA[context.teststring2.size <%=context.teststring2.toString().length%>]]> </log>
				<log><![CDATA[TCPServer.Recive getChainedLength <%=context.msgblockparam.getChainedLength().toString()%>]]> </log>
				<log><![CDATA[msgblockparam4 size <%=context.msgblockparam4.getChainedCapacity().toString()%>]]> </log>
				<log><![CDATA[TCPServer.Recive sssssssssss size <%=context.sssssssssss.getChainedLength().toString()%>]]> </log>
				<log><![CDATA[TCPServer.Recive sssssssssss size <%=context.sssssssssss.getChainedCapacity().toString()%>]]> </log>
				<read from="msgblockparam" name="context.msgblockparam3"/>
				<read from="msgblockparam" name="context.sssssssssss"/>
				<streamfrom from="msgblockparam3" name="context.data32"/>
				<streamfrom from="msgblockparam3" name="context.data16"/>
				<streamfrom from="msgblockparam3" name="context.data16_2"/>
				<streamto to="msgblockparam2" name="context.data32"/>
				<streamto to="msgblockparam2" name="context.data16"/>
				<streamto to="msgblockparam2" name="context.data16_2"/>
				<log><![CDATA[TCPServer.Recive event <%=event.getName().toString()%>]]> </log>
				<log><![CDATA[TCPServer.Recive Data <%=context.data32.toString()%>]]> </log>
				<log><![CDATA[TCPServer.Recive Data <%=context.data16.toString()%>]]> </log>
				<log><![CDATA[TCPServer.Recive Data <%=context.data16_2.toString()%>]]> </log>
				<log><![CDATA[TCPServer.Recive Data <%=context.sssssssssss.toString()%>]]> </log>
				<log><![CDATA[TCPServer.Recive transportid '<%=event.getParam("transportid").toString()%>']]></log>
				<write to="msgblockparam4" name="context.msgblockparam2"/>
				<log>TCPData.Recive.Event2</log>
				<write to="msgblockparam4" name="context.sssssssssss"/>
				<log>TCPData.Recive.Event3</log>
				<function name="TransportSendData">
					<parameters>
						<string name="objectid" in="event.getParam('objectid')"/>
						<string name="transportid" in="event.getParam('transportid')"/>
						<messageblock name="msgdata" in="context.msgblockparam4" reference="true"/>
					</parameters>
				</function>
			</function>
		</onevent>
		<onevent event="TCPServer.Disconnect.Event">
			<function>
				<log>TCPData.Disconnect.Event</log>
				<log><![CDATA[TCPData.Disconnect event <%=event.getName()%>]]> </log>
				<log><![CDATA[TCPData.Disconnect transportid '<%=event.getParam("transportid").toString()%>']]></log>
			</function>
		</onevent>
		<onevent event="TCPServer.Connected.Event">
			<function>
				<log>TCPData.Connected.Event</log>
				<log><![CDATA[TCPServer.Connected event <%=event.getName()%>]]> </log>
				<log><![CDATA[TCPServer.Connected transportid '<%=event.getParam("transportid").toString()%>']]></log>
			</function>
		</onevent>
	</events>
</starlang>
整个网络是通过事件异步方式，你用担心多进程死锁。
