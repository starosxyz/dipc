/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef DIPCNODE_H
#define DIPCNODE_H
#include "CAWACEWrapper.h"
#include "json/jsoncpp.h"

class CAW_OS_EXPORT CDIPCNode
{
public:
    CDIPCNode():m_localcid(0),m_localdid(0),m_peercid(0),m_peerdid(0),m_localip(0),m_peerip(0),m_localport(0),m_peerport(0),m_status(false)
    {
        
    }
    ~CDIPCNode(){}
    CDIPCNode(const CDIPCNode &right)
    {
        (*this)=right;
    }
    CDIPCNode& operator=(const CDIPCNode& right)
    {
        m_localcid=right.m_localcid;
        m_localdid=right.m_localdid;
        m_peercid=right.m_peercid;
        m_peerdid=right.m_peerdid;
        m_localip=right.m_localip;
        m_peerip=right.m_peerip;
        m_localport=right.m_localport;
        m_peerport=right.m_peerport;
        m_status=right.m_status;

        return *this;

    }

    inline uint32_t GetLocalCID() const {return m_localcid;}
    inline uint32_t GetLocalDID() const {return m_localdid;}

    inline uint32_t GetPeerCID() const {return m_peercid;}
    inline uint32_t GetPeerDID() const {return m_peerdid;}
    inline uint32_t GetLocalIP() const {return m_localip;}
    inline uint32_t GetPeerIP() const {return m_peerip;}
    inline uint16_t GetLocalPort() const {return m_localport;}
    inline uint16_t GetPeerPort() const {return m_peerport;}
    inline bool GetStatus() const {return m_status;}

public:
    uint32_t m_localcid;
    uint32_t m_localdid;
    uint32_t m_peercid;
    uint32_t m_peerdid;
    uint32_t m_localip;
    uint32_t m_peerip;
    uint16_t m_localport;
    uint16_t m_peerport;
    bool m_status;
};


#endif//DIPCPROCESS_H

