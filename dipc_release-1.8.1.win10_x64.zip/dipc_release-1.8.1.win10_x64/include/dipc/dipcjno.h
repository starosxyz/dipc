/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef DIPC_JNO_H
#define DIPC_JNO_H
#include <stdint.h>
/////////////////////////////////////////////////////////////////////
#define DIPCJNO_INVALID             (uint16_t)(0x0000)
#define DIPCJNO_START               (uint16_t)(0x0001)
#define DIPCJNO_END                 (uint16_t)(0xffff)
#define DIPCJNO_DIPCSERVICE         (uint16_t)(DIPCJNO_START+0)
#define DIPCJNO_DIPCCLI		        (uint16_t)(DIPCJNO_START+1)
#define DIPCJNO_WEBSERVER		    (uint16_t)(DIPCJNO_START+2)
#define DIPCJNO_PLATFORM_START      (uint16_t)(DIPCJNO_START+3)
#define DIPCJNO_PLATFORM_END        (uint16_t)(DIPCJNO_START+100)
#define DIPCJNO_USER_BASE           (uint16_t)(DIPCJNO_START+101)
#endif