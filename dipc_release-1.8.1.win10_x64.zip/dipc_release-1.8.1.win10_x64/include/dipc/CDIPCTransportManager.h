/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef CDIPCTRANSPORTMANAGER_H
#define CDIPCTRANSPORTMANAGER_H
#include "CAWACEWrapper.h"

#include "CDIPCTransportBase.h"
#include "DIPCPDUBase.h"

class CAW_OS_EXPORT CDIPCTransportManager 
{
public:
    CDIPCTransportManager();
    virtual ~CDIPCTransportManager();
    virtual void AddTransport(CDIPCTransportBase *transport);
    virtual void RemoveTransport(CDIPCTransportBase *transport);

    virtual CAWResult SendToAllTransport(uint16_t type, 
        uint32_t xid, 
        const char *msg, 
        size_t msgsize);
    virtual void DisconnectAllHA();
private:
    CAWMutexThread m_Mutex;
    std::list<CAWAutoPtr<CDIPCTransportBase>> m_list;
};


#endif//CDIPCTRANSPORTMANAGER_H
