/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/

#ifndef CCONFIGFILE_H
#define CCONFIGFILE_H
#include <stdlib.h>
#include <stdint.h>
#include <string>
#include <list>
#include "CAWDefines.h"
#include "CAWStdCpp.h"
#include "CAWString.h"
class CAW_OS_EXPORT CConfigFile
{
public:
    CConfigFile();
    ~CConfigFile();
    static CConfigFile &Instance();
    int Open(const CAWString &aFileName);
    void Close();
    int GetIntParam(
        const CAWString  &aGroup, 
        const CAWString  &aKey,
        int aDefault = 0);

    CAWString GetStringParam(
        const CAWString  &aGroup, 
        const CAWString  &aKey,
        CAWString  aDefault = CAWString());

    bool GetBoolParam(
        const CAWString  &aGroup, 
        const CAWString  &aKey,
        bool aDefault = false);
private:
    static CConfigFile g_configfile;
};

#endif


