/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CIDALLOCATOR_H
#define CIDALLOCATOR_H
#include <list>
#include "CAWDefines.h"
#include "CAWMutex.h"

using namespace::std;

class CAW_OS_EXPORT CAWIDAllocator
{
public:
    CAWIDAllocator();
    ~CAWIDAllocator();
    CAWResult Init(uint32_t startID=1,uint32_t endID=8000);
    uint32_t AllocID();
    bool FreeID(uint32_t id);
    size_t GetAvaiableIDCount();
private:
    CAWMutexThread m_mutex;
    std::list<uint32_t> m_idlist;
    uint32_t m_startID;
    uint32_t m_endID;
};

#endif//CIDALLOCATOR_H


