/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTHREADTASK_H
#define CAWTHREADTASK_H

#include "CAWThread.h"
#include "CAWEventQueueBase.h"
#include "CAWUtilClasses.h"
#include "CAWObserver.h"

class CAWTimerQueueBase;
class CAWTimeValue;

template <class QueueType>
class CAW_OS_EXPORT CAWEventStopT : public IAWEvent
{
public:
    CAWEventStopT(QueueType *aQueue)
        : m_pQueue(aQueue)
    {
        CAW_ASSERTE(m_pQueue);
    }

    virtual ~CAWEventStopT()
    {
    }

    virtual CAWResult OnEventFire()
    {
    if (m_pQueue)
        m_pQueue->SetStopFlag();
        return CAW_OK;
    }

    static CAWResult PostStopEvent(QueueType *aQueue)
    {
        CAWEventStopT<QueueType> *pEvent = new CAWEventStopT<QueueType>(aQueue);
        if (!pEvent)
            return CAW_ERROR_OUT_OF_MEMORY;
        return aQueue->GetEventQueue()->PostEvent(pEvent);
    }

private:
    QueueType *m_pQueue;
};

class CAW_OS_EXPORT CAWEventQueueUsingConditionVariable: public CAWEventQueueBase 
{
public:
    CAWEventQueueUsingConditionVariable();
    virtual ~CAWEventQueueUsingConditionVariable();

    // interface IAWEventQueue
    virtual CAWResult PostEvent(IAWEvent *aEvent, EPriority aPri = EPRIORITY_NORMAL);

    // Pop <aMaxCount> pending events in the queue, 
    // if no events are pending, wait <aTimeout>.
    CAWResult PopOrWaitPendingEvents(
            CAWEventQueueBase::EventsType &aEvents, 
            CAWTimeValue *aTimeout = NULL,
            DWORD aMaxCount = MAX_GET_ONCE);

private:
    typedef CAWMutexThread MutexType;
    MutexType m_Mutex;
    CAWConditionVariableThread m_Condition;
};

class CAW_OS_EXPORT CAWThreadTaskWithEventQueueOnly 
    : public CAWThread
    , public CAWStopFlag
{
public:
    CAWThreadTaskWithEventQueueOnly();
    virtual ~CAWThreadTaskWithEventQueueOnly();

    // interface CAWThread
    virtual CAWResult Stop(CAWTimeValue* aTimeout = NULL);
    virtual void OnThreadInit();
    virtual void OnThreadRun();
    virtual IAWEventQueue* GetEventQueue();

protected:
    CAWEventQueueUsingConditionVariable m_EventQueue;

    friend class CAWEventStopT<CAWThreadTaskWithEventQueueOnly>;
};

class CAW_OS_EXPORT CAWThreadTask : public CAWThreadTaskWithEventQueueOnly
{
public:
    CAWThreadTask();
    virtual ~CAWThreadTask();

    // interface CAWThread
    virtual void OnThreadInit();
    virtual void OnThreadRun();
    virtual IAWTimerQueue* GetTimerQueue();

protected:
    CAWTimerQueueBase *m_pTimerQueue;
};


class CAW_OS_EXPORT CAWThreadHeartBeat : public CAWThread
{
public:
    CAWThreadHeartBeat();
    virtual ~CAWThreadHeartBeat();

    // interface CAWThread
    virtual CAWResult Stop(CAWTimeValue* aTimeout = NULL);
    virtual void OnThreadInit();
    virtual void OnThreadRun();
    virtual IAWEventQueue* GetEventQueue();
    virtual IAWTimerQueue* GetTimerQueue();

    CAWResult DoHeartBeat();

protected:
    CAWEventQueueUsingMutex m_EventQueue;
    CAWTimerQueueBase *m_pTimerQueue;
};

#endif // !CAWTHREADTASK_H

