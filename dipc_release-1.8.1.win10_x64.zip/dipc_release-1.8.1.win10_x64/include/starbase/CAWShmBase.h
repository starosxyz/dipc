/***********************************************************************
 * Copyright (C) 2016-2018, Nanjing StarOS Technology Co., Ltd 
**********************************************************************/

#ifndef __CAWSHMBASE_H__
#define __CAWSHMBASE_H__

#include "CAWDefines.h"


#ifndef CAW_WIN32
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/sem.h>
#include <sys/shm.h>

#else 

#include <Windows.h>
#include <string>
#include <process.h>
#endif

#define px_ipc_name(x) x
#define SVSM_MODE 0644
#define  MAX_HOSTNAME_LEN      		512	
#define  MAX_SHM_FILENAME_LEN		1024

// Error code
#define ERR_SHM_OK                 	0x0000

#define ERR_SHM_MIN			0x1001
#define ERR_SHM_CREATE_IPC		0x1001
#define ERR_SHM_GET_MAP             	0x1002
#define ERR_SHM_INVALID_CMD         	0x1003
#define ERR_SHM_NO_RESOURCE         	0x1004
#define ERR_SHM_INACTIVE_SERVER     	0x1005
#define ERR_SHM_BUF_TOO_SMALL       	0x1006
#define ERR_SHM_IDLE_CMD            	0x1007
#define ERR_SHM_NULL_SERVER         	0x1008
#define ERR_SHM_CANNOT_OPEN         	0x1009
#define ERR_SHM_NO_ENVVAR           	0x1010
#define ERR_SHM_NO_SHMDIR           	0x1011
#define ERR_SHM_NOT_SUPPORTED		0x1012
#define ERR_SHM_ALREADY_REGISTERED  	0x1013
#define ERR_SHM_NOT_AVAILABLE		0x1014
#define ERR_SHM_WRONG_ACTION		0x1015
#define ERR_SHM_WRONG_PARAMETER		0x1016

#define ERR_SHM_MAX			0x1016

//////////////////////////////////////////////////////////////////////////////
// User need to provide the trace function.
//
void shm_trace(const char * format, ...);

//////////////////////////////////////////////////////////////////////////////
// CATShared
//
class CAW_OS_EXPORT CAWShmBase
{
public:
    CAWShmBase();

	virtual ~CAWShmBase();

    int Create(const char* lpszFileName, unsigned int dwSize, unsigned short wFlag);

    int Open(const char* lpszFileName, unsigned int dwSize, unsigned short wFlag);

    void Close(int bRemove = FALSE);

    void* GetViewData() { return m_pViewData; }

    void* MemLock();

    void MemUnlock();

    static unsigned int GetTickCount();

protected :
#ifndef CAW_WIN32
    int             m_sem_id;
    int             m_shm_id;
    struct sembuf   m_waitop[2];
    struct sembuf   m_postop[1];
#else 
	HANDLE m_hLock;
	HANDLE m_hFileMap;
#endif
    void*			m_pViewData;
    char			m_szFileName[MAX_SHM_FILENAME_LEN + 1];
	char			m_szFileLockName[MAX_SHM_FILENAME_LEN + 1];
    unsigned short  m_wFlag;
	int g_nLock;
	int g_nUnlock;
};

#endif //__CAWSHMBASE_H__
