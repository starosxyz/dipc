/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/
#ifndef CIPADDRESS_H
#define CIPADDRESS_H
#include "CAWDefines.h"

class CAW_OS_EXPORT CAWIPAddress
{
public:
    CAWIPAddress( const char *inaddr = "");
    CAWIPAddress( const CAWIPAddress  &ipaddr);
    virtual ~CAWIPAddress();
    CAWIPAddress& operator=( const CAWIPAddress &ipaddress);
    const char *ResolveHostname(int& was_found);
    virtual const char *ToString() ;
    void Mask( const CAWIPAddress& ipaddr);
    void SetIPAddr(unsigned int ipaddress);
    int IsLoopback() const;
    int IsMultiCast() const;
    int IsBroadCast() const;
    int IsPrivate() const;
    virtual void ToOctet(unsigned char octet[4]) const;
    int Valid() const;
private:
    virtual int ParseAddress( const char *inaddr);
    virtual void FormatOutput();
    int ParseDottedIPString( const char *inaddr);
    int AddrToFriendly();
    static int ResolveToAddress(const char *hostname, in_addr& quad_addr);
    static int ResolveToHostname(const in_addr& quad_addr, char *hostname);
protected:
    int valid_flag;
    char output_buffer[64];           // output buffer
    unsigned char address_buffer[4];
    char iv_friendly_name_[64];
    int  iv_friendly_name_status_;

};

#endif//CIPADDRESS_H

