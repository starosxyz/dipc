/*
 *  Copyright 2004 The WebRTC Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_BASE_STRINGUTILS_H__
#define WEBRTC_BASE_STRINGUTILS_H__

#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <vector>

#if defined(WEBRTC_WIN)
#include <malloc.h>
#include <wchar.h>
#define alloca _alloca
#endif  // WEBRTC_WIN 

#if defined(WEBRTC_POSIX)
#ifdef BSD
#include <stdlib.h>
#else  // BSD
#include <alloca.h>
#endif  // !BSD
#endif  // WEBRTC_POSIX

#include <string>

#include "webrtc/base/basictypes.h"

///////////////////////////////////////////////////////////////////////////////
// Generic string/memory utilities
///////////////////////////////////////////////////////////////////////////////

#define STACK_ARRAY(TYPE, LEN) static_cast<TYPE*>(::alloca((LEN)*sizeof(TYPE)))

namespace rtc {

// Complement to memset.  Verifies memory consists of count bytes of value c.
WEBRTC_DLLEXPORT bool memory_check(const void* memory, int c, size_t count);

// Determines whether the simple wildcard pattern matches target.
// Alpha characters in pattern match case-insensitively.
// Asterisks in pattern match 0 or more characters.
// Ex: string_match("www.TEST.GOOGLE.COM", "www.*.com") -> true
WEBRTC_DLLEXPORT bool string_match(const char* target, const char* pattern);

}  // namespace rtc

///////////////////////////////////////////////////////////////////////////////
// Rename a bunch of common string functions so they are consistent across
// platforms and between char and wchar_t variants.
// Here is the full list of functions that are unified:
//  strlen, strcmp, stricmp, strncmp, strnicmp
//  strchr, vsnprintf, strtoul, tolowercase
// tolowercase is like tolower, but not compatible with end-of-file value
//
// It's not clear if we will ever use wchar_t strings on unix.  In theory,
// all strings should be Utf8 all the time, except when interfacing with Win32
// APIs that require Utf16.
///////////////////////////////////////////////////////////////////////////////

inline char tolowercase(char c) {
  return static_cast<char>(tolower(c));
}

#if defined(WEBRTC_WIN)

inline size_t strlen(const wchar_t* s) {
  return wcslen(s);
}
inline int strcmp(const wchar_t* s1, const wchar_t* s2) {
  return wcscmp(s1, s2);
}
inline int stricmp(const wchar_t* s1, const wchar_t* s2) {
  return _wcsicmp(s1, s2);
}
inline int strncmp(const wchar_t* s1, const wchar_t* s2, size_t n) {
  return wcsncmp(s1, s2, n);
}
inline int strnicmp(const wchar_t* s1, const wchar_t* s2, size_t n) {
  return _wcsnicmp(s1, s2, n);
}
inline const wchar_t* strchr(const wchar_t* s, wchar_t c) {
  return wcschr(s, c);
}
inline const wchar_t* strstr(const wchar_t* haystack, const wchar_t* needle) {
  return wcsstr(haystack, needle);
}
#ifndef vsnprintf
inline int vsnprintf(wchar_t* buf, size_t n, const wchar_t* fmt, va_list args) {
  return _vsnwprintf(buf, n, fmt, args);
}
#endif // !vsnprintf
inline unsigned long strtoul(const wchar_t* snum, wchar_t** end, int base) {
  return wcstoul(snum, end, base);
}
inline wchar_t tolowercase(wchar_t c) {
  return static_cast<wchar_t>(towlower(c));
}

#endif  // WEBRTC_WIN 

#if defined(WEBRTC_POSIX)

inline int _stricmp(const char* s1, const char* s2) {
  return strcasecmp(s1, s2);
}
inline int _strnicmp(const char* s1, const char* s2, size_t n) {
  return strncasecmp(s1, s2, n);
}

#endif // WEBRTC_POSIX

///////////////////////////////////////////////////////////////////////////////
// Traits simplifies porting string functions to be CTYPE-agnostic
///////////////////////////////////////////////////////////////////////////////

namespace rtc {

const size_t SIZE_UNKNOWN = static_cast<size_t>(-1);

template<class CTYPE>
struct Traits {
  // STL string type
  //typedef XXX string;
  // Null-terminated string
  //inline static const CTYPE* empty_str();
};

///////////////////////////////////////////////////////////////////////////////
// String utilities which work with char or wchar_t
///////////////////////////////////////////////////////////////////////////////

template<class CTYPE>
inline const CTYPE* nonnull(const CTYPE* str, const CTYPE* def_str = NULL) {
  return str ? str : (def_str ? def_str : Traits<CTYPE>::empty_str());
}

template<class CTYPE>
const CTYPE* strchr(const CTYPE* str, const CTYPE* chs) {
  for (size_t i=0; str[i]; ++i) {
    for (size_t j=0; chs[j]; ++j) {
      if (str[i] == chs[j]) {
        return str + i;
      }
    }
  }
  return 0;
}

template<class CTYPE>
const CTYPE* strchrn(const CTYPE* str, size_t slen, CTYPE ch) {
  for (size_t i=0; i<slen && str[i]; ++i) {
    if (str[i] == ch) {
      return str + i;
    }
  }
  return 0;
}

template<class CTYPE>
size_t strlenn(const CTYPE* buffer, size_t buflen) {
  size_t bufpos = 0;
  while (buffer[bufpos] && (bufpos < buflen)) {
    ++bufpos;
  }
  return bufpos;
}

// Safe versions of strncpy, strncat, snprintf and vsnprintf that always
// null-terminate.

template<class CTYPE>
size_t strcpyn(CTYPE* buffer, size_t buflen,
               const CTYPE* source, size_t srclen = SIZE_UNKNOWN) {
  if (buflen <= 0)
    return 0;

  if (srclen == SIZE_UNKNOWN) {
    srclen = strlenn(source, buflen - 1);
  } else if (srclen >= buflen) {
    srclen = buflen - 1;
  }
  memcpy(buffer, source, srclen * sizeof(CTYPE));
  buffer[srclen] = 0;
  return srclen;
}

template<class CTYPE>
size_t strcatn(CTYPE* buffer, size_t buflen,
               const CTYPE* source, size_t srclen = SIZE_UNKNOWN) {
  if (buflen <= 0)
    return 0;

  size_t bufpos = strlenn(buffer, buflen - 1);
  return bufpos + strcpyn(buffer + bufpos, buflen - bufpos, source, srclen);
}

// Some compilers (clang specifically) require vsprintfn be defined before
// sprintfn.
template<class CTYPE>
size_t vsprintfn(CTYPE* buffer, size_t buflen, const CTYPE* format,
                 va_list args) {
  int len = vsnprintf(buffer, buflen, format, args);
  if ((len < 0) || (static_cast<size_t>(len) >= buflen)) {
    len = static_cast<int>(buflen - 1);
    buffer[len] = 0;
  }
  return len;
}

template<class CTYPE>
size_t sprintfn(CTYPE* buffer, size_t buflen, const CTYPE* format, ...);
template<class CTYPE>
size_t sprintfn(CTYPE* buffer, size_t buflen, const CTYPE* format, ...) {
  va_list args;
  va_start(args, format);
  size_t len = vsprintfn(buffer, buflen, format, args);
  va_end(args);
  return len;
}

///////////////////////////////////////////////////////////////////////////////
// Allow safe comparing and copying ascii (not UTF-8) with both wide and
// non-wide character strings.
///////////////////////////////////////////////////////////////////////////////

inline int asccmp(const char* s1, const char* s2) {
  return strcmp(s1, s2);
}
inline int ascicmp(const char* s1, const char* s2) {
  return _stricmp(s1, s2);
}
inline int ascncmp(const char* s1, const char* s2, size_t n) {
  return strncmp(s1, s2, n);
}
inline int ascnicmp(const char* s1, const char* s2, size_t n) {
  return _strnicmp(s1, s2, n);
}
inline size_t asccpyn(char* buffer, size_t buflen,
                      const char* source, size_t srclen = SIZE_UNKNOWN) {
  return strcpyn(buffer, buflen, source, srclen);
}

#if defined(WEBRTC_WIN)

typedef wchar_t(*CharacterTransformation)(wchar_t);
inline wchar_t identity(wchar_t c) { return c; }
int ascii_string_compare(const wchar_t* s1, const char* s2, size_t n,
                         CharacterTransformation transformation);

inline int asccmp(const wchar_t* s1, const char* s2) {
  return ascii_string_compare(s1, s2, static_cast<size_t>(-1), identity);
}
inline int ascicmp(const wchar_t* s1, const char* s2) {
  return ascii_string_compare(s1, s2, static_cast<size_t>(-1), tolowercase);
}
inline int ascncmp(const wchar_t* s1, const char* s2, size_t n) {
  return ascii_string_compare(s1, s2, n, identity);
}
inline int ascnicmp(const wchar_t* s1, const char* s2, size_t n) {
  return ascii_string_compare(s1, s2, n, tolowercase);
}
size_t asccpyn(wchar_t* buffer, size_t buflen,
               const char* source, size_t srclen = SIZE_UNKNOWN);

#endif  // WEBRTC_WIN 

///////////////////////////////////////////////////////////////////////////////
// Traits<char> specializations
///////////////////////////////////////////////////////////////////////////////

template<>
struct Traits<char> {
  typedef std::string string;
  inline static const char* empty_str() { return ""; }
};

///////////////////////////////////////////////////////////////////////////////
// Traits<wchar_t> specializations (Windows only, currently)
///////////////////////////////////////////////////////////////////////////////

#if defined(WEBRTC_WIN)

template<>
struct Traits<wchar_t> {
  typedef std::wstring string;
  inline static const wchar_t* empty_str() { return L""; }
};

#endif  // WEBRTC_WIN 

class WEBRTC_DLLEXPORT rtcstring
{
public:
	rtcstring();
	rtcstring(const rtcstring& str);
	rtcstring(const rtcstring& str, size_t pos, size_t len = std::string::npos);
	rtcstring(const char* s);
	rtcstring(const char* s, size_t n);
	rtcstring(size_t n, char c);

    ~rtcstring();

    rtcstring& operator=(const rtcstring &str);

    rtcstring& operator+= (const rtcstring& str);  
    rtcstring& operator+= (const char* s); 
    rtcstring& operator+= (char c);

    
    bool operator==(const rtcstring &str);
    bool operator==(const char *str);
    char& operator[] (size_t pos);
    const char& operator[] (size_t pos) const;

    size_t length() const;
    size_t size() const;
    void clear();
    const char *c_str() const;
    const char *data() const;
    rtcstring substr (size_t pos = 0, size_t len = std::string::npos) const;

    rtcstring& append (const rtcstring& str);
    rtcstring& append (const rtcstring& str, size_t subpos, size_t sublen);
    rtcstring& append (const char* s);
    rtcstring& append (const char* s, size_t n); 
    rtcstring& append (size_t n, char c);
	rtcstring& append(const char* s, const char* l);
    rtcstring& assign (const rtcstring& str);
    rtcstring& assign (const rtcstring& str, size_t subpos, size_t sublen); 
    rtcstring& assign (const char* s);
    rtcstring& assign (const char* s, size_t n); 
    rtcstring& assign (size_t n, char c);

    rtcstring& insert (size_t pos, const rtcstring& str); 
    rtcstring& insert (size_t pos, const rtcstring& str,
                          size_t subpos, size_t sublen);  
    rtcstring& insert (size_t pos, const char* s);
    rtcstring& insert (size_t pos, const char* s, size_t n);  
    rtcstring& insert (size_t pos, size_t n, char c);

    rtcstring& erase (size_t pos = 0, size_t len = std::string::npos);

    rtcstring& replace (size_t pos, size_t len, const rtcstring& str);
    rtcstring& replace (size_t pos, size_t len, const rtcstring& str,
                           size_t subpos, size_t sublen); 
    rtcstring& replace (size_t pos, size_t len, const char* s);
    rtcstring& replace (size_t pos, size_t len, const char* s, size_t n); 
    rtcstring& replace (size_t pos, size_t len, size_t n, char c);

    void swap (rtcstring& str);
    void pop_back();
    size_t copy (char* s, size_t len, size_t pos = 0) const;

       
    size_t find (const rtcstring& str, size_t pos = 0) const;  
    size_t find (const char* s, size_t pos = 0) const;
    size_t find (const char* s, size_t pos, size_t n) const; 
    size_t find (char c, size_t pos = 0) const;

	size_t rfind (const rtcstring& str, size_t pos = std::string::npos) const;
	size_t rfind (const char* s, size_t pos = std::string::npos) const;
	size_t rfind (const char* s, size_t pos, size_t n) const;
	size_t rfind (char c, size_t pos = std::string::npos) const;

    size_t find_first_of (const rtcstring& str, size_t pos = 0) const;  
    size_t find_first_of (const char* s, size_t pos = 0) const;
    size_t find_first_of (const char* s, size_t pos, size_t n) const; 
    size_t find_first_of (char c, size_t pos = 0) const;

    size_t find_last_of (const rtcstring& str, size_t pos = std::string::npos) const;
    size_t find_last_of (const char* s, size_t pos = std::string::npos) const;
    size_t find_last_of (const char* s, size_t pos, size_t n) const; 
    size_t find_last_of (char c, size_t pos = std::string::npos) const;

    size_t find_first_not_of (const rtcstring& str, size_t pos = 0) const;   
    size_t find_first_not_of (const char* s, size_t pos = 0) const;
    size_t find_first_not_of (const char* s, size_t pos, size_t n) const; 
    size_t find_first_not_of (char c, size_t pos = 0) const;

    size_t find_last_not_of (const rtcstring& str, size_t pos = std::string::npos) const;
    size_t find_last_not_of (const char* s, size_t pos = std::string::npos) const;
    size_t find_last_not_of (const char* s, size_t pos, size_t n) const; 
    size_t find_last_not_of (char c, size_t pos = std::string::npos) const;

    int compare (const rtcstring& str) const;
    int compare (size_t pos, size_t len, const rtcstring& str) const;
    int compare (size_t pos, size_t len, const rtcstring& str,
                 size_t subpos, size_t sublen) const;  
    int compare (const char* s) const;
    int compare (size_t pos, size_t len, const char* s) const;  
    int compare (size_t pos, size_t len, const char* s, size_t n) const;

    void resize (size_t n);
    void resize (size_t n, char c);

	bool empty() const;
    operator const char *() {return m_string.c_str();}
    void push_back(char ch);
    void reserve(size_t len);
    size_t capacity();
    char at (size_t pos);
	const char &at (size_t pos) const;

    char & back();
    const char& back() const;
    char& front();
    const char& front() const;
    
    const std::string &GetRawData() const;
    std::string &GetRawData();
    friend WEBRTC_DLLEXPORT rtcstring operator+ (const rtcstring& lhs, const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT rtcstring operator+ (const rtcstring& lhs, const char* rhs);
    friend WEBRTC_DLLEXPORT rtcstring operator+ (const char* lhs, const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT rtcstring operator+ (const rtcstring& lhs, char rhs);
    friend WEBRTC_DLLEXPORT rtcstring operator+ (char lhs, const rtcstring& rhs);

    friend WEBRTC_DLLEXPORT bool operator== (const rtcstring& lhs,
        const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT bool operator== (const char* lhs, const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT bool operator== (const rtcstring& lhs, const char* rhs);

    friend WEBRTC_DLLEXPORT bool operator!= (const rtcstring& lhs,
    	const rtcstring& rhs);

    friend WEBRTC_DLLEXPORT bool operator!= (const char* lhs, const rtcstring& rhs);

    friend WEBRTC_DLLEXPORT bool operator!= (const rtcstring& lhs, const char* rhs);


    friend WEBRTC_DLLEXPORT bool operator<  (const rtcstring& lhs,
        const rtcstring& rhs);

    friend WEBRTC_DLLEXPORT bool operator<  (const char* lhs, const rtcstring& rhs);

    friend WEBRTC_DLLEXPORT bool operator<  (const rtcstring& lhs, const char* rhs);

    friend WEBRTC_DLLEXPORT bool operator<= (const rtcstring& lhs,
        const rtcstring& rhs);

    friend WEBRTC_DLLEXPORT bool operator<= (const char* lhs, const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT bool operator<= (const rtcstring& lhs, const char* rhs);

    friend WEBRTC_DLLEXPORT bool operator>  (const rtcstring& lhs,
        const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT bool operator>  (const char* lhs, const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT bool operator>  (const rtcstring& lhs, const char* rhs);
    friend WEBRTC_DLLEXPORT bool operator>= (const rtcstring& lhs,
    	const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT bool operator>= (const char* lhs, const rtcstring& rhs);
    friend WEBRTC_DLLEXPORT bool operator>= (const rtcstring& lhs, const char* rhs);
public:
    void Tolower();
private:
    std::string m_string;
};

WEBRTC_DLLEXPORT std::ostream& operator<< (std::ostream& os,const rtcstring& str);

WEBRTC_DLLEXPORT rtcstring operator+ (const rtcstring& lhs, const rtcstring& rhs);
WEBRTC_DLLEXPORT rtcstring operator+ (const rtcstring& lhs, const char* rhs);
WEBRTC_DLLEXPORT rtcstring operator+ (const char* lhs, const rtcstring& rhs);
WEBRTC_DLLEXPORT rtcstring operator+ (const rtcstring& lhs, char rhs);
WEBRTC_DLLEXPORT rtcstring operator+ (char lhs, const rtcstring& rhs);
WEBRTC_DLLEXPORT bool operator== (const rtcstring& lhs,
	const rtcstring& rhs);
WEBRTC_DLLEXPORT bool operator== (const char* lhs, const rtcstring& rhs);
WEBRTC_DLLEXPORT bool operator== (const rtcstring& lhs, const char* rhs);

WEBRTC_DLLEXPORT bool operator!= (const rtcstring& lhs,
	const rtcstring& rhs);

WEBRTC_DLLEXPORT bool operator!= (const char* lhs, const rtcstring& rhs);

WEBRTC_DLLEXPORT bool operator!= (const rtcstring& lhs, const char* rhs);


WEBRTC_DLLEXPORT bool operator<  (const rtcstring& lhs,
    const rtcstring& rhs);

WEBRTC_DLLEXPORT bool operator<  (const char* lhs, const rtcstring& rhs);

WEBRTC_DLLEXPORT bool operator<  (const rtcstring& lhs, const char* rhs);

WEBRTC_DLLEXPORT bool operator<= (const rtcstring& lhs,
    const rtcstring& rhs);

WEBRTC_DLLEXPORT bool operator<= (const char* lhs, const rtcstring& rhs);
WEBRTC_DLLEXPORT bool operator<= (const rtcstring& lhs, const char* rhs);

WEBRTC_DLLEXPORT bool operator>  (const rtcstring& lhs,
    const rtcstring& rhs);
WEBRTC_DLLEXPORT bool operator>  (const char* lhs, const rtcstring& rhs);
WEBRTC_DLLEXPORT bool operator>  (const rtcstring& lhs, const char* rhs);
WEBRTC_DLLEXPORT bool operator>= (const rtcstring& lhs,
    const rtcstring& rhs);
WEBRTC_DLLEXPORT bool operator>= (const char* lhs, const rtcstring& rhs);
WEBRTC_DLLEXPORT bool operator>= (const rtcstring& lhs, const char* rhs);

class WEBRTC_DLLEXPORT StringVector
{
public:
    StringVector();
    StringVector (const StringVector& x);
    ~StringVector();
    StringVector& operator= (const StringVector& x);
    size_t size() const;
    void clear();
    void resize (size_t n, rtcstring val = rtcstring());
    size_t capacity() const;
    bool empty() const;
    void reserve (size_t n);
    rtcstring &operator[] (size_t n);
    const rtcstring &operator[] (size_t n) const;
    rtcstring &at (size_t n);
    const rtcstring &at (size_t n) const;

    rtcstring &front();
    const rtcstring &front() const;

    rtcstring &back();
    const rtcstring &back() const;

    rtcstring* data() noexcept;
    const rtcstring* data() const noexcept;

    void assign (size_t n, const rtcstring& val);

    void push_back (const rtcstring& val);
    void pop_back();
    const std::vector<rtcstring> &GetVector() const;
    std::vector<rtcstring> &GetVector();
private:
    std::vector<rtcstring> m_strvector;
};


// Replaces all occurrences of "search" with "replace".
WEBRTC_DLLEXPORT void replace_substrs(const char *search,
                     size_t search_len,
                     const char *replace,
                     size_t replace_len,
                     rtcstring *s);

// True iff s1 starts with s2.
WEBRTC_DLLEXPORT bool starts_with(const char *s1, const char *s2);

// True iff s1 ends with s2.
WEBRTC_DLLEXPORT bool ends_with(const char *s1, const char *s2);

// Remove leading and trailing whitespaces.
WEBRTC_DLLEXPORT rtcstring string_trim(const rtcstring& s);

}  // namespace rtc

#endif // WEBRTC_BASE_STRINGUTILS_H__
