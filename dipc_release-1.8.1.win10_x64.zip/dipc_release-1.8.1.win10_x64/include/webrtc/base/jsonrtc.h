/*
 *  Copyright 2004 The WebRTC Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_BASE_JSON_H_
#define WEBRTC_BASE_JSON_H_
#include "webrtc/base/basictypes.h"
#include <string>
#include <vector>
#include "webrtc/base/stringutils.h"
#include "json/jsoncpp.h"

namespace rtc {

///////////////////////////////////////////////////////////////////////////////
// JSON Helpers
///////////////////////////////////////////////////////////////////////////////

// Robust conversion operators, better than the ones in JsonCpp.
WEBRTC_DLLEXPORT bool GetIntFromJson(const Json::Value& in, int* out);
WEBRTC_DLLEXPORT bool GetUIntFromJson(const Json::Value& in, unsigned int* out);
WEBRTC_DLLEXPORT bool GetStringFromJson(const Json::Value& in, rtcstring* out);
WEBRTC_DLLEXPORT bool GetBoolFromJson(const Json::Value& in, bool* out);
WEBRTC_DLLEXPORT bool GetDoubleFromJson(const Json::Value& in, double* out);

// Pull values out of a JSON array.
WEBRTC_DLLEXPORT bool GetValueFromJsonArray(const Json::Value& in, size_t n,
                           Json::Value* out);
WEBRTC_DLLEXPORT bool GetIntFromJsonArray(const Json::Value& in, size_t n,
                         int* out);
WEBRTC_DLLEXPORT bool GetUIntFromJsonArray(const Json::Value& in, size_t n,
                          unsigned int* out);
WEBRTC_DLLEXPORT bool GetStringFromJsonArray(const Json::Value& in, size_t n,
	Json::jsonstring* out);
WEBRTC_DLLEXPORT bool GetBoolFromJsonArray(const Json::Value& in, size_t n,
                          bool* out);
WEBRTC_DLLEXPORT bool GetDoubleFromJsonArray(const Json::Value& in, size_t n,
                            double* out);

// Convert json arrays to std::vector
WEBRTC_DLLEXPORT bool JsonArrayToValueVector(const Json::Value& in,
                            std::vector<Json::Value>* out);
WEBRTC_DLLEXPORT bool JsonArrayToIntVector(const Json::Value& in,
                          std::vector<int>* out);
WEBRTC_DLLEXPORT bool JsonArrayToUIntVector(const Json::Value& in,
                           std::vector<unsigned int>* out);
WEBRTC_DLLEXPORT bool JsonArrayToStringVector(const Json::Value& in,
                             std::vector<Json::jsonstring>* out);
WEBRTC_DLLEXPORT bool JsonArrayToBoolVector(const Json::Value& in,
                           std::vector<bool>* out);
WEBRTC_DLLEXPORT bool JsonArrayToDoubleVector(const Json::Value& in,
                             std::vector<double>* out);

// Convert std::vector to json array
WEBRTC_DLLEXPORT Json::Value ValueVectorToJsonArray(const std::vector<Json::Value>& in);
WEBRTC_DLLEXPORT Json::Value IntVectorToJsonArray(const std::vector<int>& in);
WEBRTC_DLLEXPORT Json::Value UIntVectorToJsonArray(const std::vector<unsigned int>& in);
WEBRTC_DLLEXPORT Json::Value StringVectorToJsonArray(const std::vector<Json::jsonstring>& in);
WEBRTC_DLLEXPORT Json::Value BoolVectorToJsonArray(const std::vector<bool>& in);
WEBRTC_DLLEXPORT Json::Value DoubleVectorToJsonArray(const std::vector<double>& in);

// Pull values out of a JSON object.
WEBRTC_DLLEXPORT bool GetValueFromJsonObject(const Json::Value& in, const Json::jsonstring& k,
                            Json::Value* out);
WEBRTC_DLLEXPORT bool GetIntFromJsonObject(const Json::Value& in, const Json::jsonstring& k,
                          int* out);
WEBRTC_DLLEXPORT bool GetUIntFromJsonObject(const Json::Value& in, const Json::jsonstring& k,
                           unsigned int* out);
WEBRTC_DLLEXPORT bool GetStringFromJsonObject(const Json::Value& in, const Json::jsonstring& k,
	Json::jsonstring* out);
WEBRTC_DLLEXPORT bool GetBoolFromJsonObject(const Json::Value& in, const Json::jsonstring& k,
                           bool* out);
WEBRTC_DLLEXPORT bool GetDoubleFromJsonObject(const Json::Value& in, const Json::jsonstring& k,
                             double* out);

// Writes out a Json value as a string.
WEBRTC_DLLEXPORT rtcstring JsonValueToString(const Json::Value& json);

}  // namespace rtc

#endif  // WEBRTC_BASE_JSON_H_
