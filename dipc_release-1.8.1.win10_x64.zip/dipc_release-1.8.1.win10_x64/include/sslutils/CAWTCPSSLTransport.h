/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTCPSSLTRANSPORT_H
#define CAWTCPSSLTRANSPORT_H
#include "CAWACEWrapper.h"
#include "CAWInetAddr.h"
#include "CAWConnectionInterface.h"
#include "CAWUtilTemplates.h"
#include "CAWMessageBlock.h"
#include "IAWSSLUtils.h"
#include <mutex>

class CAW_OS_EXPORT CAWTCPSSLTransport : public IAWSSLTransportSink
{ 
public: 
    CAWTCPSSLTransport();
    virtual ~CAWTCPSSLTransport();

    virtual void OnSSLDataReceive(CAWMessageBlock &aData, IAWSSLTransport *ptrans);
    virtual void OnSSLDisconnect(CAWResult aReason, IAWSSLTransport *ptrans);
    virtual void OnSSLDataSend(IAWSSLTransport *ptrans);


    virtual CAWResult SendSSLMessage(CAWMessageBlock &aData);

    virtual WORD16 HandleSSLMessage(CAWMessageBlock &aData) = 0;
    virtual void OnPeerSSLDisconnect(CAWResult aReason) = 0;
    
    virtual CAWResult SetSSLTransportHandle(CAWAutoPtr<IAWSSLTransport> &pTransport);

    virtual CAWResult Disconnect(CAWResult reason);

    void SetSendBufferSize(WORD32 bufferSize);
    void SetRcvBufferSize(WORD32 bufferSize);

    void GetPeerIP(CAWString &ip);
    
    void GetLocalIP(CAWString &ip);
    
    WORD16 GetPeerPort();
    
    WORD16 GetLocalPort();
    
    const CAWInetAddr &GetPeerAddr() const;
    const CAWInetAddr &GetLocalAddr() const;
    
protected:
    CAWAutoPtr<IAWSSLTransport> m_pTransport;
    CAWMessageBlock *           m_pBlocks;
    CAWMessageBlock *           m_pMbSendBuf;
    WORD32                      m_dwSendBufMaxLen;
    WORD32                      m_dwRcvBufMaxLen;
    CAWInetAddr                 m_addrPeer;
    CAWInetAddr                 m_addrLocal;
};


#endif /* CAWTCPTransport */

