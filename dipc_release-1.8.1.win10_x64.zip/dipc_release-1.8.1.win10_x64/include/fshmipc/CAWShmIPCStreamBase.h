/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWSHMIPCSTREAMBASE_H
#define CAWSHMIPCSTREAMBASE_H
#include "CAWACEWrapper.h"
#include "CAWIPCAddr.h"
#include "CAWShmIPCInterface.h"
#include "CAWUtilTemplates.h"
#include "CAWMessageBlock.h"

class CAW_OS_EXPORT CAWShmIPCStreamBase : public IAWShmIPCTransportSink,
                        public IAWShmIPCAcceptorConnectorSink,
                        public CAWReferenceControlSingleThread
{ 
public: 
    CAWShmIPCStreamBase();
    virtual ~CAWShmIPCStreamBase();

    virtual void OnShmIPCConnectIndication(
        CAWResult aReason,
        IAWShmIPCTransport *aTrpt,
        IAWShmIPCAcceptorConnectorId *aRequestId);

    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWShmIPCTransport *aTrptId,
        CAWShmIPCTransportParameter *aPara = NULL);

    virtual void OnSend(
        IAWShmIPCTransport *aTrptId,
        CAWShmIPCTransportParameter *aPara = NULL);

    virtual void OnDisconnect(
        CAWResult aReason,
        IAWShmIPCTransport *aTrptId);

    virtual CAWResult Connect(const CAWShmIPCAddr &peerAddr, CAWShmIPCAddr *aAddrLocal = NULL);

    virtual CAWResult SendMessage(CAWMessageBlock &aData);
    virtual CAWResult SendMessage(const char *data, size_t datasize);

    virtual size_t HandleMessage(const char *data, size_t datasize) = 0;
    virtual void OnPeerDisconnect(CAWResult aReason) = 0;
    virtual void OnConnected(CAWResult aReason) = 0;
	virtual void OnClose() = 0;
	virtual void OnConnectFailure(CAWResult aReason) = 0;
    virtual void OnRcvBufferOverFlow(WORD32 buffersize) = 0;

    bool IsClient(){return m_bIsClient;}

    virtual CAWResult SetTransportHandle(CAWAutoPtr<IAWShmIPCTransport> &pTransport);

    virtual CAWResult Close(CAWResult reason);

    void SetSendBufferSize(WORD32 bufferSize);
    void SetRcvBufferSize(WORD32 bufferSize);
    
    const CAWShmIPCAddr &GetPeerAddr() const;
    const CAWShmIPCAddr &GetLocalAddr() const;
    bool IsClosed();
protected:
    CAWAutoPtr<IAWShmIPCTransport> m_pTransport;
    CAWAutoPtr<IAWShmIPCConnector> m_pConnector;
    CAWMessageBlock *m_pMbSendBuf;
    CAWMessageBlock *m_pMbRcvBuf;
    bool                        m_bConnected;
    bool                        m_bIsClient;
    WORD32                      m_dwSendBufMaxLen;
    WORD32                      m_dwRcvBufMaxLen;
    CAWShmIPCAddr                 m_addrPeer;
    CAWShmIPCAddr                 m_addrLocal;
    bool m_bisoverbuffer;
    bool                        m_isClose;
};


#endif /* CAWIPCSTREAMBASE_H */

