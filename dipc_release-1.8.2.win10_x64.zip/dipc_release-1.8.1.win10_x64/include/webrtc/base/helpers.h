/*
 *  Copyright 2004 The WebRTC Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_BASE_HELPERS_H_
#define WEBRTC_BASE_HELPERS_H_

#include <string>
#include "webrtc/base/basictypes.h"
#include "webrtc/base/stringutils.h"

namespace rtc {

// For testing, we can return predictable data.
WEBRTC_DLLEXPORT void SetRandomTestMode(bool test);

// Initializes the RNG, and seeds it with the specified entropy.
WEBRTC_DLLEXPORT bool InitRandom(int seed);
WEBRTC_DLLEXPORT bool InitRandom(const char* seed, size_t len);

// Generates a (cryptographically) random string of the given length.
// We generate base64 values so that they will be printable.
// WARNING: could silently fail. Use the version below instead.
WEBRTC_DLLEXPORT rtcstring CreateRandomString(size_t length);

// Generates a (cryptographically) random string of the given length.
// We generate base64 values so that they will be printable.
// Return false if the random number generator failed.
WEBRTC_DLLEXPORT bool CreateRandomString(size_t length, rtcstring* str);

// Generates a (cryptographically) random string of the given length,
// with characters from the given table. Return false if the random
// number generator failed.
WEBRTC_DLLEXPORT bool CreateRandomString(size_t length, const rtcstring& table,
                        rtcstring* str);

// Generates a (cryptographically) random UUID version 4 string.
WEBRTC_DLLEXPORT rtcstring CreateRandomUuid();

// Generates a random id.
WEBRTC_DLLEXPORT uint32_t CreateRandomId();

// Generates a 64 bit random id.
WEBRTC_DLLEXPORT uint64_t CreateRandomId64();

// Generates a random id > 0.
WEBRTC_DLLEXPORT uint32_t CreateRandomNonZeroId();

// Generates a random double between 0.0 (inclusive) and 1.0 (exclusive).
WEBRTC_DLLEXPORT double CreateRandomDouble();

}  // namespace rtc

#endif  // WEBRTC_BASE_HELPERS_H_
