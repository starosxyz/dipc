/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IAWSTARSSH2MANAGER_H
#define IAWSTARSSH2MANAGER_H

#include "CAWACEWrapper.h"

class IAWSSH2Transport;
class IAWSSH2ChannelSink;
class IAWSSH2Client;
class IAWSSH2Server;
class IAWSSH2CallHomeServerAcceptor;
class IAWSSH2CallHomeServerConnector;
class IAWChannelSSH2ServerSink;

class CAW_OS_EXPORT IAWStarSSH2Manager
{
public:
    static IAWStarSSH2Manager* Instance();
    virtual ~IAWStarSSH2Manager(){}
    virtual CAWResult CreateSSH2Client(CAWAutoPtr<IAWSSH2Client> &aClient) = 0;
    virtual CAWResult CreateSSH2CallHomeAcceptor(CAWAutoPtr<IAWSSH2CallHomeServerAcceptor> &aAcceptor) = 0;
    virtual CAWResult CreateSSH2Server(CAWAutoPtr<IAWSSH2Server> &aServer) = 0;
    virtual CAWResult CreateSSH2CallHomeConnector(CAWAutoPtr<IAWSSH2CallHomeServerConnector> &aConnector) = 0;

    // Set the preferred cipher/hmac, call multiple times to set the order
    // use getSupportedCipher/Hmac to get the list of possibilities
    static bool setPreferredCipher(const char* prefCipher);
    static bool setPreferredHmac(const char* prefHmac);
    // Call with ciphers or hmacs==NULL to get the length of the returned string
    // Then call again with a properly sized string as an argument, and it
    // will be filled with a coma separated list of ciphers.
    static size_t getSupportedCiphers(char* ciphers);
    static size_t getSupportedHmacs(char* hmacs);
};

class CAW_OS_EXPORT IAWSSH2Client : public IAWReferenceControl
{
public:
    virtual void AsycSSH2Connect(
        IAWChannelSSH2ServerSink *aSink,
        const CAWInetAddr &aAddrListen,
        const CAWString &username,
        const CAWString &password,
        const CAWString &privKeyFile,
        const bool keepAlives=true) = 0;
    virtual void CancelSSH2Connect() = 0;
protected:
    virtual ~IAWSSH2Client() { }
};

class CAW_OS_EXPORT IAWSSH2CallHomeServerAcceptor : public IAWReferenceControl
{
public:
    virtual CAWResult StartListen(
        IAWChannelSSH2ServerSink *aSink,
        const CAWInetAddr &aAddrListen,
        const CAWString &username,
        const CAWString &password,
        const CAWString &privKeyFile,
        const bool keepAlives=true) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

protected:
    virtual ~IAWSSH2CallHomeServerAcceptor() {}
};

class CAW_OS_EXPORT IAWSSH2Server : public IAWReferenceControl
{
public:
    virtual CAWResult AddHostKey(const CAWString &hostkeyfile) = 0;
    virtual CAWResult SetCACertificateFile(const CAWString &cafile) = 0;
    virtual CAWResult SetCACertificatePath(const CAWString &capath) = 0;
    virtual CAWResult AuthorizedKeysFile(const CAWString &keyfilehome) = 0;
    virtual CAWResult StartListen(
        IAWChannelSSH2ServerSink *aSink,
        const CAWInetAddr &aAddrListen) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

protected:
    virtual ~IAWSSH2Server() { }
};

class CAW_OS_EXPORT IAWSSH2CallHomeServerConnector : public IAWReferenceControl
{
public:
    virtual CAWResult AddHostKey(const CAWString &hostkeyfile) = 0;
    virtual CAWResult SetCACertificateFile(const CAWString &cafile) = 0;
    virtual CAWResult SetCACertificatePath(const CAWString &capath) = 0;
    virtual CAWResult AuthorizedKeysFile(const CAWString &keyfilehome) = 0;
    virtual CAWResult AsycSSH2Connect(
        IAWChannelSSH2ServerSink *aSink,
        const CAWInetAddr &aAddrListen) = 0;

    virtual CAWResult CancelSSH2Connect(CAWResult aReason) = 0;

protected:
    virtual ~IAWSSH2CallHomeServerConnector() { }
};


class CAW_OS_EXPORT IAWChannelSSH2ServerSink
{
public:
    virtual void OnSSH2ServerCreation(CAWResult result, IAWSSH2Transport *aServer) = 0;
protected:
    virtual ~IAWChannelSSH2ServerSink() { }
};

class CAW_OS_EXPORT IAWSSH2ChannelSink 
{
public:
    virtual void OnChannelOpenSuccess(uint32_t channelid)=0;
    virtual void OnChannelOpenFailure(uint32_t code, const CAWString&reason)=0;
    virtual void OnChannelDataReceive(CAWMessageBlock &aData) = 0;
    virtual void OnChannelClose(const CAWString &aReason) = 0;
    virtual void OnChannelSuccess() = 0;
    virtual void OnChannelFailure() = 0;
    virtual void OnChannelEof()=0;
    virtual void OnChannelExecRequest(const CAWString &command)=0;
    virtual void OnChannelShellRequest()=0;
    virtual void OnChannelSubsystemRequest(const CAWString& subsystem) = 0;
    virtual void OnChannelPtyRequest(const CAWString &term, 
                                                uint32_t width, 
                                                uint32_t height, 
                                                uint32_t widthp, 
                                                uint32_t heightp,
                                                char *mode,
                                                size_t modesize) = 0;
    virtual void OnWindowChange(const uint32_t cols, const uint32_t rows) = 0;
protected:
    virtual ~IAWSSH2ChannelSink() {}
};

class CAW_OS_EXPORT IAWSSH2TransportSink 
{
public:
    virtual void OnTransportDisconnect(const CAWString &reason) = 0;
    virtual void OnAuthenticateRequest(const CAWString &username, const CAWString &password) = 0;
    virtual void OnChannelOpenRequest(const CAWString &channelname, uint32_t channelid) = 0;
protected:
    virtual ~IAWSSH2TransportSink() {}
};


class CAW_OS_EXPORT IAWSSH2Transport : public IAWReferenceControl
{
public:
    virtual CAWResult SendAuthResultOK() = 0;
    virtual CAWResult SendAuthResultFailure() = 0;
    virtual CAWResult OpenWithSink(IAWSSH2TransportSink *psink) = 0;
    virtual CAWResult SSH2Disconnect(CAWResult aReason) = 0;
    virtual CAWResult SendChannelData(uint32_t channelid, CAWMessageBlock &aData) = 0;
    virtual CAWResult CloseChannel(uint32_t channelid, CAWResult aReason) = 0;
    virtual CAWResult DoChannelRequest(uint32_t channelid, 
                                        const CAWString& req, 
                                        const CAWString& reqdata,
                                        bool wantReply)=0;
    virtual CAWResult OpenChannel(const CAWString &channelname, IAWSSH2ChannelSink *aSink)=0;
    virtual CAWResult ChannelOpenWithSink(uint32_t channelid, IAWSSH2ChannelSink *aSink) = 0;
    virtual CAWResult DoPtyRequest(uint32_t channelid,
                            const CAWString &term, 
                            uint32_t width, 
                            uint32_t height, 
                            uint32_t widthp, 
                            uint32_t heightp,
                            char *mode,
                            size_t modesize) = 0;
    virtual void WindowChange(uint32_t channelid, 
                                    const uint32_t cols, 
                                    const uint32_t rows) = 0;
    virtual CAWResult SSH2ChannelSubsystem(uint32_t channelid, const CAWString &subsystem)=0; 
    virtual CAWResult SSH2ChannelExec(uint32_t channelid, const CAWString &command)=0;
    virtual CAWResult SSH2ChannelShell(uint32_t channelid)=0;
    virtual CAWResult SendEof(uint32_t channelid)=0;
    virtual CAWResult EnableKeepAlive(uint32_t intervalsec, bool wantreply)=0;
    virtual CAWResult DisableKeepAlive() = 0;
    virtual CAWResult SetChannelTimerOut(uint32_t timeoutmsec)=0;
    virtual uint32_t GetChannelTimerOut()=0;
    virtual CAW_HANDLE GetTransportHandle() const = 0;
protected:
    virtual ~IAWSSH2Transport() {}
};

#endif // IAWSTARSSH2MANAGER_H
