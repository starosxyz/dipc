/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWEVENTSYNCHRONOUS_H
#define CAWEVENTSYNCHRONOUS_H

#include "CAWReactorInterface.h"

class CAW_OS_EXPORT CAWEventSynchronous : public IAWEvent
{
public:
    CAWEventSynchronous(IAWEvent *aEventPost);
    // interface IAWEvent
    virtual CAWResult OnEventFire();
    CAWResult WaitForResult();
protected:
    virtual ~CAWEventSynchronous();
private:
    IAWEvent *m_pEventPost;
};

class CAW_OS_EXPORT CAWEventQueueSynchronous : public IAWEventQueue
{
public:
    CAWEventQueueSynchronous();
    virtual ~CAWEventQueueSynchronous();
    virtual CAWResult SendEvent(IAWEvent *aEvent);
};

#endif // !CAWEVENTSYNCHRONOUS_H

