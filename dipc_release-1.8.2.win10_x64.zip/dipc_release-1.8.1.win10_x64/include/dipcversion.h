#ifndef DIPC_VERSION_H
#define DIPC_VERSION_H


/////////////////////////////////////
#define DIPC_MAJOR_VERSION 1
#define DIPC_MINOR_VERSION 8
#define DIPC_BETA_VERSION 2
///////////////////////////////////////////


#endif
