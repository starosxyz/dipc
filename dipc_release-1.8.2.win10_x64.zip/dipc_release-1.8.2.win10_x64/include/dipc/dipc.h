﻿/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef IDIPC_H
#define IDIPC_H

#include "CAWACEWrapper.h"
#include "dipcjno.h"
#include "dipcprocess.h"
#include "dipcnode.h"
#include <functional>
#include "CAWShmIPCInterface.h"
#include "CAWIPCInterface.h"

/**
* @mainpage StarOS DIPC Library API Reference
*
* <dl>
* <dt>Abstract Base Classes<dd>
*        IDIPCProcess, IDIPCProcessSink, IDIPCAcceptorConnectorSink, CDIPCTransportParameter, IDIPCTransportSink,
*        IDIPCTransport, IDIPCAcceptorConnectorId, IDIPCConnector, IDIPCAcceptor
* 分布式进程通信平台
*====================================
* ### 什么是DIPC
*DIPC是南京北星极网络科技有限公司研发的新一代分布式进程通信平台中间件，屏蔽了底层操作系统的物理位置为应用层软件进程提供.
*目前广泛应用北星极的控制器和DPDK项目中。
*###功能列表
*解耦合上层应用之间关系
*单机进程间采用内存共享方式的消息通信/夸机器进程间采用可靠消息通信
*采用动态xml配置方式，Xml脚本配置定制进程启动。灵活方便, 可以自定义参数
*进程保护机制，支持单进程重启，自动重启
*一系列库的形式发布
*支持跨语言通信，C/C++,JAVA和Python写的程序之间利用DIPC可以相互通信
*进程之间通信无需知道对方的物理位置,DIPC屏蔽了底层操作系统的物理位置
*支持功能的增删、重启和升级
*
*###适用范围
** 服务器端多进程软件
** 数通领域多进程软件
** DPDK集成软件
* </dl>
*/

class IDIPCTransportSink;
  class IDIPCTransport;
  class IDIPCShareMemory;
  class IDIPCAcceptorConnectorId;
    
//////////////////////////////////////////////////////////////////////////////////

typedef std::function<void(CAWResult result)> ResponseHandler;
typedef std::function<void(const CDIPCProcess &process)> DumpProcessCallBack;
typedef std::function<void(const CDIPCNode &process)> DumpPeerNodeCallBack;

typedef enum {
    DIPC_CLUSTER_STATE_NONE,
    DIPC_CLUSTER_STATE_FOLLOWER,
    DIPC_CLUSTER_STATE_CANDIDATE,
    DIPC_CLUSTER_STATE_LEADER
} dipc_cluster_state_e;


/** \brief The main object of DIPC Process。
 */
class CAW_OS_EXPORT IDIPCProcess
{
public:
    /** \brief Create shm memory
    * @param shdpath     shm path
    * @return      pmemory 
    */
    virtual CAWResult CreateMemory(CAWAutoPtr<IDIPCShareMemory> &sharemm, const CAWString &shdpath, size_t mmsize) = 0;

    /** \brief Create ShmIPC Client
    * @param aConClient     pointer to the output DIPC Client Object
    * @return      CAW_OK is success
    */
    virtual CAWResult CreateShmIPCClient(CAWAutoPtr<IAWShmIPCConnector> &aConClient) = 0;

    /** \brief Create ShmIPC Server
    * @param aAcceptor     pointer to the output DIPC Server Object
    * @return      CAW_OK is success
    */
    virtual CAWResult CreateShmIPCServer(CAWAutoPtr<IAWShmIPCAcceptor> &aAcceptor) = 0;
    /** \brief Create ShmIPC Client
    * @param aConClient     pointer to the output DIPC Client Object
    * @return      CAW_OK is success
    */
    virtual CAWResult CreateIPCClient(CAWAutoPtr<IAWIPCConnector> &aConClient) = 0;

    /** \brief Create ShmIPC Server
    * @param aAcceptor     pointer to the output DIPC Server Object
    * @return      CAW_OK is success
    */
    virtual CAWResult CreateIPCServer(CAWAutoPtr<IAWIPCAcceptor> &aAcceptor) = 0;

    /** \brief kill a dipc process
    * @param otherProcessName     dipc process name
    * @param handler     pointer to the response handler
    * @return      CAW_OK is success
    */
    virtual CAWResult KillProcess(const CAWString &otherProcessName, ResponseHandler handler=NULL) = 0;

    /** \brief start a dipc process
    * @param otherProcessName     dipc process name
    * @param handler     pointer to the response handler
    * @return      CAW_OK is success
    */
    virtual CAWResult StartProcess(const CAWString &otherProcessName, ResponseHandler handler=NULL) = 0;
    
    /** \brief restart a dipc process
    * @param otherProcessName     dipc process name
    * @param handler     pointer to the response handler
    * @return      CAW_OK is success
    */
    virtual CAWResult RestartProcess(const CAWString &otherProcessName, ResponseHandler handler=NULL) = 0;

    /** \brief Get String parameter
    * @param paramName     parameter name
    * @param aDefault     output parameter value
    * @return      CAW_OK is success
    */
    virtual CAWString GetStringParam(const CAWString &paramName, CAWString  aDefault = CAWString()) = 0;

    /** \brief Get Int parameter
    * @param paramName     parameter name
    * @param aDefault     output parameter value
    * @return      CAW_OK is success
    */
    virtual int GetIntParam(const CAWString &paramName, int aDefault=0) = 0;
    
    /** \brief Boolean Int parameter
    * @param paramName     parameter name
    * @param aDefault     output parameter value
    * @return      CAW_OK is success
    */
    virtual bool GetBoolParam(const CAWString &paramName, bool aDefault=false) = 0;

    /** \brief Notify the process is start
    * @return      CAW_OK is success
    */
    virtual CAWResult ProcessRunFinishNotify() = 0;
    
    /** \brief Get All of the DIPC Process
    * @param list     output list contain the process information
    */
    virtual void GetProcessList(DumpProcessCallBack callback) = 0;
    /** \brief Get Process Size
    * @return      process size
    */
    virtual size_t GetProcessSize() = 0;

    /** \brief Get Cluster Id
    * @return      cluster Id
    */
    virtual uint32_t GetClusterId() = 0;

    /** \brief Get DataCenter Id
    * @return      DataCenter Id
    */
    virtual uint32_t GetDataCenterId() = 0;

    /** \brief Get Process name by pno
    * @param processname     process name
    * @param pno     dipc pno
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult GetProcessNameByPno(uint16_t pno, CAWString &processname)=0;
    /** \brief Get DataCenter Id
    * @param strProcessName     process name
    * @param pno     dipc pno
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult GetPnoByProcessName(const CAWString &strProcessName, uint16_t &pno)=0;
    /** \brief Get Peers
    * @param outpeers     process name
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult GetPeerNodes(DumpPeerNodeCallBack callback)=0;
    /** \brief Get Peers
    * @param outpeers     process name
    * @return  CAWResult--   CAW_OK is success
    */
    virtual size_t GetPeerNodesSize()=0;

    /** \brief Set Peer
    * @param peerip     Peer Ip address
    * @param port       port no
    * @return  CAWResult--   CAW_OK is success
    */

    virtual CAWResult AddPeerNode(const CAWString &peerip, uint16_t port, uint32_t clusterid, uint32_t datacenterid)=0;
    /** \brief Remove Peer
    * @param peerip     Peer Ip address
    * @param port       port no
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult RemovePeerNode(const CAWString &peerip)=0;
    /** \brief SendPacket
    * @param msg     SendPacket to peer jno
    * @param tojno       port no
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult SendPacket(CAWMessageBlock &msg, uint16_t tojno)=0;

    /** \brief , uint16_t fromjno
    * @param msg     SendPacket to peer jno
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult SendPacketToPeerNode(CAWMessageBlock &msg)=0;

    /** \brief , Stop discovery
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult StopDiscovery()=0;

    /** \brief , Start discovery
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult StartDiscovery()=0;

    /** \brief , 获取监听地址
    * @param listenip     监听地址
    * @param port       端口
    * @param result     结果
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult GetPeerNodeListen(CAWString &listenip, uint16_t &port, bool &result) = 0;

    virtual CAWString GetSettings() = 0;
    /** \brief , 获取集群状态
    * @return  CAWResult--   CAW_OK is success
    */
    virtual dipc_cluster_state_e GetState() = 0;

    /** \brief , 获取本地JNO
    * @return  uint16_t--   jno
    */
    virtual uint16_t GetLocalJno() = 0;
    /** \brief 获取持久数据
    * @param urlpath  数据路径
    * @return  CAWString 数据
    */
    virtual CAWString GetPersistentData(const CAWString &urlpath) = 0;
    /** \brief 存储持久数据
    * @param urlpath  数据路径
    * @param strdata  数据
    * @return  void
    */
    virtual CAWResult SetPersistentData(const CAWString &urlpath, const CAWString &strdata) = 0;
    /** \brief 存储持久数据
    * @param urlpath  数据路径
    * @param strdata  数据
    * @return  void
    */
    virtual CAWResult UpdatePersistentData(const CAWString &urlpath, const CAWString &strdata)=0;
    /** \brief 订阅存储持久数据
    * @param urlpath  数据路径
    * @param strdata  数据
    * @return  void
    */
    virtual CAWResult PersistentDataSubscriber(const CAWString &urlpath) = 0;

protected:
    virtual ~IDIPCProcess() {}
};

/** \brief The main object of DIPC Process callback
 */
class CAW_OS_EXPORT IDIPCProcessSink
{
public:
    /** \brief When Other Process Information update, will callback this function
    * @param updateprocess Update Information
    * @return  void
    */
    virtual void OnProcessUpdateState(const CDIPCProcess &updateprocess) = 0;
    /** \brief 所以进程关闭回调
    * @return  void
    */
    virtual void OnProcessShutdown()=0;

    /** \brief 所以进程启动结束后回调
    * @return  void
    */
    virtual void OnBootOK()=0;

    /** \brief 当当前进程启动结束后，回调
    * @param argc  参数个数
    * @param argv  参数
    * @param dipcProcess  指向DIPCProcess的指针
    * @return  void
    */

    virtual void OnProcessRun(int argc, char** argv, IDIPCProcess *dipcProcess) = 0;

    /** \brief when peer process is connected to the cluster.
    * 			同步规则1)在同一个集群内的节点，互相可以同步数据。也就是clusterid相等。
    * 			同步规则2)在同一个集群内的节点，datacenterid值大向小的方向同步数据。
    * 			同步规则2)在同一个集群内的节点，datacenterid值相等的时候，互相同步数据。
    * @param nPeerClusterId  peer cluster id
    * @param nPeerDataCenterId  peer datacenter id
    * @param transport  pointer the the transport
    * @return  void
    */
    virtual void OnHAProcessConnected(uint32_t nPeerClusterId, 
                                            uint32_t nPeerDataCenterId, 
                                            CAWAutoPtr<IDIPCTransport> &transport) = 0;
    virtual void OnHAProcessDisconnect(uint32_t nPeerClusterId, 
                                            uint32_t nPeerDataCenterId,
                                            uint32_t peeripaddr)=0;

    /** \brief 当另一个进程传过来的数据
    * @param msg  数据结构
	* @param fromjno  进程jno
    * @return  void
    */
    virtual void OnPacketRcv(CAWMessageBlock &msg, uint16_t fromjno) = 0;
    /** \brief 当集群对端传过来的数据
    * @param msg  数据结构
    * @return  void
    */
    virtual void OnPacketRcvFromPeerNode(CAWMessageBlock &msg) = 0;
    /** \brief 数据变化
    * @param msg  数据结构
    * @return  void
    */
    virtual void OnPersistentdataChange(const CAWString &strurl)=0;
protected:
    virtual ~IDIPCProcessSink(){}
};

class CAW_OS_EXPORT CDIPCTransportParameter
{
public:
    CDIPCTransportParameter()
        : m_nHaveSent(0)
    {
    }
    size_t m_nHaveSent;
};

/** \brief DIPC transport callback object
 */
class CAW_OS_EXPORT IDIPCTransportSink
{
public:
    /** \brief DIPC receive data
    * @param aData  messageblock
    * @param aTrptId  pointer to the transport
    * @return  void
    */
    virtual void OnReceive(CAWMessageBlock &aData,
                            IDIPCTransport *aTrptId) = 0;
    /** \brief disconnect
    * @param aReason  the reason of the disconnect
    * @param aTrptId  pointer to the transport
    * @return  void
    */
    virtual void OnDisconnect(CAWResult aReason,
                    IDIPCTransport *aTrptId) = 0;

    /** \brief when send buffer is avaiable
    * @param aTrptId  pointer to the transport
    * @return  void
    */
    virtual void OnSend(IDIPCTransport *aTrptId) = 0;
protected:
    virtual ~IDIPCTransportSink() {}
};

class CAW_OS_EXPORT IDIPCShareMemory : public IAWReferenceControl
{
public:
    virtual void* MemLock() = 0;
    virtual void MemUnlock() = 0;
protected:
    virtual ~IDIPCShareMemory() {}
};


/** \brief DIPC Transport
 */
class CAW_OS_EXPORT IDIPCTransport : public IAWReferenceControl
{
public:
    /** \brief DIPC transport
    * @param aSink  pointer to transport callback object
    * @return  CAW_OK or CAW_ERROR_FAILURE
    */
    virtual CAWResult OpenWithSink(IDIPCTransportSink *aSink) = 0;

    /** \brief get transport callback object
    * @return  pointer to transport callback object
    */
    virtual IDIPCTransportSink* GetSink() = 0;

    /** \brief Send data to peer, this will delivery packet to peer side process
    * @param msg  pointer to message buffer.
    * @param msgsize  message buffer size.
    * @param aPara  parameter of transport.
    * @return  CAW_OK or CAW_ERROR_FAILURE
    */
    virtual CAWResult SendData(const char *msg,
                                size_t msgsize,
                                CDIPCTransportParameter *aPara=NULL) = 0;

    /** \brief Send data to peer, this will delivery packet to peer side process
    * @param aData  messageblock object.
    * @param aPara  parameter of transport.
    * @return  CAW_OK or CAW_ERROR_FAILURE
    */
    virtual CAWResult SendData(CAWMessageBlock &aData, CDIPCTransportParameter *aPara = NULL) = 0;

    /** \brief disconnect the transport.
    * @return  void
    */
    virtual void Disconnect() = 0;

    /** \brief get transport peer ip address
    * @param peeraddr  output peeraddr
     * @return  void
     */
    virtual void GetDIPCPeerAddr(CAWInetAddr &peeraddr) = 0;
    
    /** \brief get transport local ip address
    * @param peeraddr  output localaddr
     * @return  void
     */
    virtual void GetDIPCLocalAddr(CAWInetAddr &peeraddr) = 0;

    /** \brief get peer cluster id
    * @param clusterid  output clusterid
     * @return  void
     */
    virtual void GetPeerClusterId(uint32_t &clusterid) = 0;

    /** \brief get peer datacenter id
    * @param datacenterid  output datacenterid
     * @return  void
     */
    virtual void GetPeerDataCenterId(uint32_t &datacenterid) = 0;

    virtual CAW_HANDLE GetTransportHandle() const = 0;

protected:
    virtual ~IDIPCTransport() {}
};

/***********************************************************************************/
//First Init
CAW_OS_EXPORT CAWResult DIPCProcessInit(int argc, char** argv);
//Second run loop
CAW_OS_EXPORT CAWResult DIPCProcessLoop(IDIPCProcessSink *psink, uint16_t jno);
//Detach run dipc loop
CAW_OS_EXPORT CAWResult DIPCProcessDetachRun(IDIPCProcessSink *psink, uint16_t jno);

/***********************************************************************************/

//All in One run dipc process
inline CAWResult DIPCProcessRun(int argc, char** argv, IDIPCProcessSink *psink,uint16_t jno)
{
    if (DIPCProcessInit(argc,argv) != CAW_OK)
    {
        printf("DIPCProcessInit failure\n");
        return CAW_ERROR_FAILURE;
    }

    return DIPCProcessLoop(psink,jno);
}

/***********************************************************************************/

#endif // IDICP_H

