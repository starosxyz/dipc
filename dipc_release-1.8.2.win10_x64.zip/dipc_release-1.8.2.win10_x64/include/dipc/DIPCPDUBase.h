/***********************************************************************
    Copyright (C) 2018-2019 南京北星极网络科技有限公司
**********************************************************************/
#ifndef CDIPCPDUBASE_H
#define CDIPCPDUBASE_H

#include <stdint.h>

struct DIPCPDUBaseHead 
{
    uint16_t pdutype;
    uint16_t version;
    uint32_t pdulenth;
    uint32_t xid;
};

struct DIPCPDUBase
{
    struct DIPCPDUBaseHead head;
    uint32_t messagesize;
};


#endif//CDIPCPDU_H

