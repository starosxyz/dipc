/***********************************************************************
    Copyright (C) 2013-2015 Nanjing StarOS Technology Co., Ltd 
**********************************************************************/
#ifndef ISTARLANG_H
#define ISTARLANG_H
#include "IXmlEngine.h"


class CAW_OS_EXPORT IStarLangSink
{
public:
    virtual void OnStarLangInitOK() = 0;
    virtual void OnCreateApp(uint64_t sessionid, const CAWString &strpage) = 0;
    virtual void OnEvent(uint64_t sessionid, 
                                uint64_t objectid,
                                const CAWString & method,
                                XMLParams &params,
                                CAWMessageBlock &pmsgblock)=0;
protected:
    virtual ~IStarLangSink(){}
};

class CAW_OS_EXPORT IStarLang
{
public:
    static IStarLang &Instance();
    virtual CAWResult Init(IDIPCProcess *pprocess,IStarLangSink *psink) = 0;
    virtual CAWResult Close() = 0;
    virtual CAWResult CreateStarLangAPP(const CAWString &strDefPage, 
                                            XMLParams &params) = 0;
    virtual CAWResult DestroyStarLangAPP(uint64_t sessionid)=0;
    virtual CAWResult RegistEvent(const CAWString & method) = 0;
    virtual CAWResult PostEvent(uint64_t sessionid, 
                                uint64_t objectid,
                                const CAWString & eventname, 
                                XMLParams &params,
                                CAWMessageBlock &pmsgblock) = 0;
protected:
    virtual ~IStarLang(){}
};


#endif//ISTARLANG_H

