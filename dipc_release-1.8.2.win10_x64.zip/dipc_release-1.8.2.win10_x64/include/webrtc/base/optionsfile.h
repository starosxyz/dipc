/*
 *  Copyright 2008 The WebRTC Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_BASE_OPTIONSFILE_H_
#define WEBRTC_BASE_OPTIONSFILE_H_

#include <map>
#include <string>
#include "webrtc/base/basictypes.h"
#include "webrtc/base/stringutils.h"
namespace rtc {

// Implements storage of simple options in a text file on disk. This is
// cross-platform, but it is intended mostly for Linux where there is no
// first-class options storage system.
class WEBRTC_DLLEXPORT OptionsFile {
 public:
  OptionsFile(const rtcstring &path);
  ~OptionsFile();

  // Loads the file from disk, overwriting the in-memory values.
  bool Load();
  // Saves the contents in memory, overwriting the on-disk values.
  bool Save();

  bool GetStringValue(const rtcstring& option, rtcstring* out_val) const;
  bool GetIntValue(const rtcstring& option, int* out_val) const;
  bool SetStringValue(const rtcstring& option, const rtcstring& val);
  bool SetIntValue(const rtcstring& option, int val);
  bool RemoveValue(const rtcstring& option);

 private:
  typedef std::map<rtcstring, rtcstring> OptionsMap;

  static bool IsLegalName(const rtcstring &name);
  static bool IsLegalValue(const rtcstring &value);

  rtcstring path_;
  OptionsMap options_;
};

}  // namespace rtc

#endif  // WEBRTC_BASE_OPTIONSFILE_H_
