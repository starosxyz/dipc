/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/
#ifndef CAWOBSERVER_H
#define CAWOBSERVER_H

class CAW_OS_EXPORT IAWObserver
{
public:
    virtual void OnObserve(LPCSTR aTopic, LPVOID aData = NULL) = 0;

protected:
    virtual ~IAWObserver() { }
};

#endif // !CAWOBSERVER_H

