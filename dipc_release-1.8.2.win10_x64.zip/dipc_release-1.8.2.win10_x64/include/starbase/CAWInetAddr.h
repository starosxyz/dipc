/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWINETADDR_H
#define CAWINETADDR_H

#include "CAWStdCpp.h"
#include "CAWString.h"
#include "CAWError.h"
#ifndef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
  #define CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME 1
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME

/// The concept of <CAWInetAddr> is mainly copyed by <ACE_INET_Addr>
/// http://www.cs.wustl.edu/~schmidt/ACE.html
class CAW_OS_EXPORT CAWInetAddr  
{
public:
    CAWInetAddr();
    CAWInetAddr(int type);
    CAWInetAddr(sockaddr_in* addr);
    CAWInetAddr(sockaddr_in6* addr);
    CAWInetAddr(const CAWInetAddr &right);
    CAWInetAddr& operator=(const CAWInetAddr& right);

    /// Creates an <CAWInetAddr> from a <aPort> and the remote
    /// <aHostName>. The port number is assumed to be in host byte order.
    CAWInetAddr(LPCSTR aHostName, WORD aPort);

    /**
        * Initializes an <CAWInetAddr> from the <aIpAddrAndPort>, which can be
        * "ip-number:port-number" (e.g., "tango.cs.wustl.edu:1234" or
        * "128.252.166.57:1234").  If there is no ':' in the <address> it
        * is assumed to be a port number, with the IP address being
        * INADDR_ANY.
        */
    CAWInetAddr(LPCSTR aIpAddrAndPort);

    CAWResult Set(LPCSTR aHostName, WORD aPort);
    CAWResult Set(LPCSTR aIpAddrAndPort);

    CAWResult SetIpAddrByString(LPCSTR aIpAddr);
    CAWResult SetIpAddrBy4Bytes(DWORD aIpAddr, BOOL aIsNetworkOrder = TRUE);
    CAWResult SetIp6AddrBy16Bytes(char ipv6addr[16]);
    CAWResult SetPort(WORD aPort);

    /// Compare two addresses for equality.  The addresses are considered
    /// equal if they contain the same IP address and port number.
    bool operator == (const CAWInetAddr &aRight) const;
    bool operator != (const CAWInetAddr &aRight) const;

    /**
        * Returns true if <this> is less than <aRight>.  In this context,
        * "less than" is defined in terms of IP address and TCP port
        * number.  This operator makes it possible to use <ACE_INET_Addr>s
        * in STL maps.
        */
    bool operator < (const CAWInetAddr &aRight) const;

    CAWString GetIpDisplayName() const;

    WORD GetPort() const;

    DWORD GetIpAddrIn4Bytes() const;
    CAWResult GetIp6AddrIn16Bytes(char ipv6addr[16]);

    DWORD GetSize() const;

    DWORD GetType() const;

    DWORD GetInetAddrSize() const;

    void* GetPtr() const ;
    static BOOL IpAddrStringTo4Bytes(LPCSTR aIpStr, DWORD &aIpDword);
    static CAWString IpAddr4BytesToString(DWORD aIpDword);
    static BOOL Ip6AddrStringTo16Bytes(LPCSTR aIpStr, char ipv6addr[16]);
    static CAWString IpAddr6BytesToString(char ip6addr[16]);

#ifdef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
    BOOL IsResolved() const;

    const CAWString &GetHostName() const ;

    CAWResult TryResolve();
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME

public:
    static CAWInetAddr s_InetAddrAny();
public:
      /// Return the size of the address.
  int get_size (void) const;

  /// Sets the size of the address.
  void set_size (int size);

  // = Get/set the type of the address.

  /// Get the type of the address.
  int get_type (void) const;

  /// Set the type of the address.
  void set_type (int type);
  void *GetIpAddrPointer (void) const;
  int GeIPAddrSize (void) const;
  DWORD get_ip_address (void) const;
  uint32_t hash (void) const;
  /**
   * Return the "dotted decimal" Internet address representation of
   * the hostname storing it in the @a addr (which is assumed to be
   * @a addr_size bytes long).  This version is reentrant.
   */
  const char *GetHostAddr (char *addr, int addr_size) const;

  /**
   * Return the "dotted decimal" Internet address representation of
   * the hostname.  This version is non-reentrant since it returns a
   * pointer to a static data area.  You should therefore either
   * (1) do a "deep copy" of the address returned by get_host_addr(), e.g.,
   * using strdup() or (2) use the "reentrant" version of
   * get_host_addr() described above.
   */
  const char *GetHostAddr(void) const;
  void base_set (int type, int size);
private:
    /// e.g., AF_UNIX, AF_INET, AF_SPIPE, etc.
    int addr_type_;
    
    /// Number of bytes in the address.
    int addr_size_;
    union ip46
    {
        sockaddr_in  in4_;
        sockaddr_in6 in6_;
    } inet_addr_;
    
#ifdef CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
    // m_strHostName is empty that indicates resovled successfully,
    // otherwise it needs resolving.
    CAWString m_strHostName;
#endif // CAW_SUPPORT_ASYNC_RESOLVE_HOSTNAME
};

/// Return the size of the address.
inline int
CAWInetAddr::get_size (void) const
{
  return this->addr_size_;
}

/// Sets the size of the address.
inline void
CAWInetAddr::set_size (int size)
{
  this->addr_size_ = size;
}

/// Return the type of the address.
inline int
CAWInetAddr::get_type (void) const
{
  return this->addr_type_;
}

/// Set the type of the address.
inline void
CAWInetAddr::set_type (int type)
{
  this->addr_type_ = type;
}

#endif // !CAWINETADDR_H
