/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/

#ifndef CAWREFERENCECONTROL_H
#define CAWREFERENCECONTROL_H

#include "CAWDefines.h"
#include "CAWAtomicOperationT.h"
#include <iostream>
class CAW_OS_EXPORT IAWReferenceControl
{
public:
    virtual DWORD AddReference() = 0;
    virtual DWORD ReleaseReference() = 0;

protected:
    virtual ~IAWReferenceControl() {}
};

template <class MutexType> class CAW_OS_EXPORT CAWReferenceControlT  
{
public:
    CAWReferenceControlT()
    {
    }

    virtual ~CAWReferenceControlT()
    {
    }

    DWORD AddReference()
    {
        return ++m_Atomic;
    }

    DWORD ReleaseReference()
    {
        DWORD dwRef = --m_Atomic;
        if (dwRef == 0) 
        OnReferenceDestory();
         return dwRef;
    }

    DWORD GetReference()
    {
        return m_Atomic.GetValue();
    }

    protected:
    virtual void OnReferenceDestory()
    {
        delete this;
    }

    CAWAtomicOperationT<MutexType> m_Atomic;
};

typedef CAWReferenceControlT<CAWMutexNullSingleThread> CAWReferenceControlSingleThread;
typedef CAWReferenceControlT<CAWMutexThread> CAWReferenceControlMutilThread;

template <class T> class CAW_OS_EXPORT CAWAutoPtr
{
public:
    CAWAutoPtr(T *aPtr = NULL) 
    : m_pRawPtr(aPtr)
    {
        if (m_pRawPtr)
            m_pRawPtr->AddReference();
    }

    CAWAutoPtr(const CAWAutoPtr& aAutoPtr) 
    : m_pRawPtr(aAutoPtr.m_pRawPtr)
    {
        if (m_pRawPtr)
        m_pRawPtr->AddReference();
    }

    ~CAWAutoPtr() 
    {
        if (m_pRawPtr)
            m_pRawPtr->ReleaseReference();
    }

    CAWAutoPtr& operator = (const CAWAutoPtr& aAutoPtr) 
    {
        return (*this = aAutoPtr.m_pRawPtr);
    }

    bool operator< (const CAWAutoPtr& aAutoPtr) const
    {
        if ((m_pRawPtr == NULL)||(aAutoPtr.m_pRawPtr == NULL))
        {
            return false;
        }
        return *m_pRawPtr<*aAutoPtr.m_pRawPtr;
    }

    CAWAutoPtr& operator = (T* aPtr) 
    {
        if (m_pRawPtr == aPtr)
            return *this;

        if (aPtr)
            aPtr->AddReference();
        if (m_pRawPtr)
            m_pRawPtr->ReleaseReference();
        m_pRawPtr = aPtr;
        return *this;
    }

    operator void* () const 
    {
        return m_pRawPtr;
    }

    T* operator -> () const 
    {
        CAW_ASSERTE(m_pRawPtr);
        return m_pRawPtr;
    }

    T* Get() const 
    {
        return m_pRawPtr;
    }

    T* ParaIn() const 
    {
        return m_pRawPtr;
    }

    T*& ParaOut() 
    {
        if (m_pRawPtr) {
            m_pRawPtr->ReleaseReference();
            m_pRawPtr = NULL;
        }
        return static_cast<T*&>(m_pRawPtr);
    }

    T*& ParaInOut() 
    {
        return static_cast<T*&>(m_pRawPtr);
    }

    T& operator * () const 
    {
        CAW_ASSERTE(m_pRawPtr);
        return *m_pRawPtr;
    }

private:
    T *m_pRawPtr;
};

#endif // !CAWREFERENCECONTROL_H

