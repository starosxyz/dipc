/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/

#ifndef CAWTHREADPROXYMANAGER_H
#define CAWTHREADPROXYMANAGER_H

#include "CAWThreadManager.h"
#include "CAWThreadInterface.h"
#include "CAWThread.h"

class CAW_OS_EXPORT CAWThreadProxyBase
{
public:
    explicit CAWThreadProxyBase(CAWThreadManager::TType aType);
    explicit CAWThreadProxyBase(CAWThread *aThread);
    ~CAWThreadProxyBase();

    CAWResult PostEvent_i(IAWEvent* aEvent);
    CAWResult SendEvent_i(IAWEvent* aEvent);

protected:
    IAWEventQueue *m_pEventQueue;
};

class CAW_OS_EXPORT CAWThreadProxyManager  
{
public:
    ~CAWThreadProxyManager();
    CAWThreadProxyManager* Instance();
private:
    CAWThreadProxyManager();
};

#endif // !CAWTHREADPROXYMANAGER_H

