/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CCMFIFOBUFFER_H
#define CCMFIFOBUFFER_H
#include "CAWDefines.h"
#include "CAWMutex.h"

enum StreamState {SS_CLOSED, SS_OPENING, SS_OPEN};

// Stream read/write methods return this value to indicate various success
// and failure conditions described below.
enum StreamResult {SR_ERROR, SR_SUCCESS, SR_BLOCK, SR_EOS};

class CAW_OS_EXPORT CAWFifoBuffer 
{
public:

    // Creates a FIFO buffer with the specified capacity.
    explicit CAWFifoBuffer(size_t length);
    virtual ~CAWFifoBuffer();
    // Gets the amount of data currently readable from the buffer.
    bool GetBuffered(size_t* data_len);
    // Resizes the buffer to the specified capacity. Fails if data_length_ > size
    bool SetCapacity(size_t length);

    // Read into |buffer| with an offset from the current read position, offset
    // is specified in number of bytes.
    // This method doesn't adjust read position nor the number of available
    // bytes, user has to call ConsumeReadData() to do this.
    StreamResult ReadOffset(void* buffer, size_t bytes, size_t offset,
              size_t* bytes_read);

    // Write |buffer| with an offset from the current write position, offset is
    // specified in number of bytes.
    // This method doesn't adjust the number of buffered bytes, user has to call
    // ConsumeWriteBuffer() to do this.
    StreamResult WriteOffset(const void* buffer, size_t bytes, size_t offset,
               size_t* bytes_written);

    // StreamInterface methods
    virtual StreamState GetState() const;
    virtual StreamResult Read(void* buffer, size_t bytes,
                size_t* bytes_read, int* error);
    virtual StreamResult Write(const void* buffer, size_t bytes,
                 size_t* bytes_written, int* error);
    virtual void Close();
    virtual const void* GetReadData(size_t* data_len);
    virtual void ConsumeReadData(size_t used);
    virtual void* GetWriteBuffer(size_t* buf_len);
    virtual void ConsumeWriteBuffer(size_t used);
    virtual bool GetWriteRemaining(size_t* size);

private:
    // Helper method that implements ReadOffset. Caller must acquire a lock
    // when calling this method.
    StreamResult ReadOffsetLocked(void* buffer, size_t bytes, size_t offset,
                    size_t* bytes_read);

    // Helper method that implements WriteOffset. Caller must acquire a lock
    // when calling this method.
    StreamResult WriteOffsetLocked(const void* buffer, size_t bytes,
                     size_t offset, size_t* bytes_written);

    StreamState state_;  // keeps the opened/closed state of the stream
    char *buffer_;  // the allocated buffer
    size_t buffer_length_;  // size of the allocated buffer
    size_t data_length_;  // amount of readable data in the buffer
    size_t read_position_;  // offset to the readable data
    //mutable CriticalSection crit_;  // object lock
    CAWMutexThread crit_;
    DISALLOW_EVIL_CONSTRUCTORS(CAWFifoBuffer);
};

#endif

