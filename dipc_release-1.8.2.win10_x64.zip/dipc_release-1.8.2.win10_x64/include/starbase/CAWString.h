/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/

#ifndef CAWSTRING_H
#define CAWSTRING_H

#include "CAWDefines.h"
#include <iostream>
#include <string>
#include <functional>

class CAW_OS_EXPORT CAWString
{
public:
	CAWString();
	CAWString(const CAWString& str);
	CAWString(const CAWString& str, size_t pos, size_t len = std::string::npos);
	CAWString(const char* s);
	CAWString(const char* s, size_t n);
	CAWString(size_t n, char c);

    ~CAWString();

    CAWString& operator=(const CAWString &str);

    CAWString& operator+= (const CAWString& str);  
    CAWString& operator+= (const char* s); 
    CAWString& operator+= (char c);

    
    bool operator==(const CAWString &str);
    bool operator==(const char *str);
    char& operator[] (size_t pos);
    const char& operator[] (size_t pos) const;

    size_t length() const;
    size_t size() const;
    void clear();
    const char *c_str() const;
    const char *data() const;
    CAWString substr (size_t pos = 0, size_t len = std::string::npos) const;

    CAWString& append (const CAWString& str);
    CAWString& append (const CAWString& str, size_t subpos, size_t sublen);
    CAWString& append (const char* s);
    CAWString& append (const char* s, size_t n); 
    CAWString& append (size_t n, char c);
	CAWString& append(const char* s, const char* l);
    CAWString& assign (const CAWString& str);
    CAWString& assign (const CAWString& str, size_t subpos, size_t sublen); 
    CAWString& assign (const char* s);
    CAWString& assign (const char* s, size_t n); 
    CAWString& assign (size_t n, char c);

    CAWString& insert (size_t pos, const CAWString& str); 
    CAWString& insert (size_t pos, const CAWString& str,
                          size_t subpos, size_t sublen);  
    CAWString& insert (size_t pos, const char* s);
    CAWString& insert (size_t pos, const char* s, size_t n);  
    CAWString& insert (size_t pos, size_t n, char c);

    CAWString& erase (size_t pos = 0, size_t len = std::string::npos);

    CAWString& replace (size_t pos, size_t len, const CAWString& str);
    CAWString& replace (size_t pos, size_t len, const CAWString& str,
                           size_t subpos, size_t sublen); 
    CAWString& replace (size_t pos, size_t len, const char* s);
    CAWString& replace (size_t pos, size_t len, const char* s, size_t n); 
    CAWString& replace (size_t pos, size_t len, size_t n, char c);

    void swap (CAWString& str);
    void pop_back();
    size_t copy (char* s, size_t len, size_t pos = 0) const;

       
    size_t find (const CAWString& str, size_t pos = 0) const;  
    size_t find (const char* s, size_t pos = 0) const;
    size_t find (const char* s, size_t pos, size_t n) const; 
    size_t find (char c, size_t pos = 0) const;

	size_t rfind (const CAWString& str, size_t pos = std::string::npos) const;
	size_t rfind (const char* s, size_t pos = std::string::npos) const;
	size_t rfind (const char* s, size_t pos, size_t n) const;
	size_t rfind (char c, size_t pos = std::string::npos) const;

    size_t find_first_of (const CAWString& str, size_t pos = 0) const;  
    size_t find_first_of (const char* s, size_t pos = 0) const;
    size_t find_first_of (const char* s, size_t pos, size_t n) const; 
    size_t find_first_of (char c, size_t pos = 0) const;

    size_t find_last_of (const CAWString& str, size_t pos = std::string::npos) const;
    size_t find_last_of (const char* s, size_t pos = std::string::npos) const;
    size_t find_last_of (const char* s, size_t pos, size_t n) const; 
    size_t find_last_of (char c, size_t pos = std::string::npos) const;

    size_t find_first_not_of (const CAWString& str, size_t pos = 0) const;   
    size_t find_first_not_of (const char* s, size_t pos = 0) const;
    size_t find_first_not_of (const char* s, size_t pos, size_t n) const; 
    size_t find_first_not_of (char c, size_t pos = 0) const;

    size_t find_last_not_of (const CAWString& str, size_t pos = std::string::npos) const;
    size_t find_last_not_of (const char* s, size_t pos = std::string::npos) const;
    size_t find_last_not_of (const char* s, size_t pos, size_t n) const; 
    size_t find_last_not_of (char c, size_t pos = std::string::npos) const;

    int compare (const CAWString& str) const;
    int compare (size_t pos, size_t len, const CAWString& str) const;
    int compare (size_t pos, size_t len, const CAWString& str,
                 size_t subpos, size_t sublen) const;  
    int compare (const char* s) const;
    int compare (size_t pos, size_t len, const char* s) const;  
    int compare (size_t pos, size_t len, const char* s, size_t n) const;

    void resize (size_t n);
    void resize (size_t n, char c);

	bool empty() const;
    operator const char *() {return m_string.c_str();}
    void push_back(char ch);
    void reserve(size_t len);
    size_t capacity();
    char at (size_t pos);
	const char &at (size_t pos) const;

    char & back();
    const char& back() const;
    char& front();
    const char& front() const;
    
	const std::string &GetRawData() const;
	std::string &GetRawData();
	friend CAW_OS_EXPORT CAWString operator+ (const CAWString& lhs, const CAWString& rhs);
	friend CAW_OS_EXPORT CAWString operator+ (const CAWString& lhs, const char* rhs);
	friend CAW_OS_EXPORT CAWString operator+ (const char* lhs, const CAWString& rhs);
	friend CAW_OS_EXPORT CAWString operator+ (const CAWString& lhs, char rhs);
	friend CAW_OS_EXPORT CAWString operator+ (char lhs, const CAWString& rhs);

	friend CAW_OS_EXPORT bool operator== (const CAWString& lhs,
		const CAWString& rhs);
	friend CAW_OS_EXPORT bool operator== (const char* lhs, const CAWString& rhs);
	friend CAW_OS_EXPORT bool operator== (const CAWString& lhs, const char* rhs);

	friend CAW_OS_EXPORT bool operator!= (const CAWString& lhs,
		const CAWString& rhs);

	friend CAW_OS_EXPORT bool operator!= (const char* lhs, const CAWString& rhs);

	friend CAW_OS_EXPORT bool operator!= (const CAWString& lhs, const char* rhs);


	friend CAW_OS_EXPORT bool operator<  (const CAWString& lhs,
		const CAWString& rhs);

	friend CAW_OS_EXPORT bool operator<  (const char* lhs, const CAWString& rhs);

	friend CAW_OS_EXPORT bool operator<  (const CAWString& lhs, const char* rhs);

	friend CAW_OS_EXPORT bool operator<= (const CAWString& lhs,
		const CAWString& rhs);

	friend CAW_OS_EXPORT bool operator<= (const char* lhs, const CAWString& rhs);
	friend CAW_OS_EXPORT bool operator<= (const CAWString& lhs, const char* rhs);

	friend CAW_OS_EXPORT bool operator>  (const CAWString& lhs,
		const CAWString& rhs);
	friend CAW_OS_EXPORT bool operator>  (const char* lhs, const CAWString& rhs);
	friend CAW_OS_EXPORT bool operator>  (const CAWString& lhs, const char* rhs);
	friend CAW_OS_EXPORT bool operator>= (const CAWString& lhs,
		const CAWString& rhs);
	friend CAW_OS_EXPORT bool operator>= (const char* lhs, const CAWString& rhs);
	friend CAW_OS_EXPORT bool operator>= (const CAWString& lhs, const char* rhs);
public:
    void Tolower();
private:
    std::string m_string;
};

CAW_OS_EXPORT std::ostream& operator<< (std::ostream& os,const CAWString& str);

CAW_OS_EXPORT CAWString operator+ (const CAWString& lhs, const CAWString& rhs);
CAW_OS_EXPORT CAWString operator+ (const CAWString& lhs, const char* rhs);
CAW_OS_EXPORT CAWString operator+ (const char* lhs, const CAWString& rhs);
CAW_OS_EXPORT CAWString operator+ (const CAWString& lhs, char rhs);
CAW_OS_EXPORT CAWString operator+ (char lhs, const CAWString& rhs);
CAW_OS_EXPORT bool operator== (const CAWString& lhs,
	const CAWString& rhs);
CAW_OS_EXPORT bool operator== (const char* lhs, const CAWString& rhs);
CAW_OS_EXPORT bool operator== (const CAWString& lhs, const char* rhs);

CAW_OS_EXPORT bool operator!= (const CAWString& lhs,
	const CAWString& rhs);

CAW_OS_EXPORT bool operator!= (const char* lhs, const CAWString& rhs);

CAW_OS_EXPORT bool operator!= (const CAWString& lhs, const char* rhs);


CAW_OS_EXPORT bool operator<  (const CAWString& lhs,
	const CAWString& rhs);

CAW_OS_EXPORT bool operator<  (const char* lhs, const CAWString& rhs);

CAW_OS_EXPORT bool operator<  (const CAWString& lhs, const char* rhs);

CAW_OS_EXPORT bool operator<= (const CAWString& lhs,
	const CAWString& rhs);

CAW_OS_EXPORT bool operator<= (const char* lhs, const CAWString& rhs);
CAW_OS_EXPORT bool operator<= (const CAWString& lhs, const char* rhs);

CAW_OS_EXPORT bool operator>  (const CAWString& lhs,
	const CAWString& rhs);
CAW_OS_EXPORT bool operator>  (const char* lhs, const CAWString& rhs);
CAW_OS_EXPORT bool operator>  (const CAWString& lhs, const char* rhs);
CAW_OS_EXPORT bool operator>= (const CAWString& lhs,
	const CAWString& rhs);
CAW_OS_EXPORT bool operator>= (const char* lhs, const CAWString& rhs);
CAW_OS_EXPORT bool operator>= (const CAWString& lhs, const char* rhs);


struct CAWStringHash
{
    size_t operator()(const CAWString &str) const
    {
        std::hash<std::string> hash_fn;
        
        size_t hash = hash_fn(str.c_str());

        return hash;
    }
};

class CAW_OS_EXPORT CAWIsSpace
{
public:
    int operator() (const char c) {
        return c == ' ';
    }
};

template<class IS> 
void LTrimString(CAWString &aTrim, IS aIs)
{
    const char *pStart = aTrim.c_str();
    const char *pMove = pStart;

    for ( ; *pMove; ++pMove) {
        if (!aIs(*pMove)) {
            if (pMove != pStart) {
                size_t nLen = strlen(pMove);
                aTrim.replace(0, nLen, pMove, nLen);
                aTrim.resize(nLen);
            }
            return;
        }
    }
};

template<class IS> 
void RTrimString(CAWString &aTrim, IS aIs)
{
    if (aTrim.empty())
        return;

    const char * pStart = aTrim.c_str();
    const char * pEnd = pStart + aTrim.length() - 1;
    const char * pMove = pEnd;

    for ( ; pMove >= pStart; --pMove) {
    if (!aIs(*pMove)) {
    if (pMove != pEnd)
        aTrim.resize(pMove - pStart + 1);
    return;
    }
    }
};

template<class IS> 
void TrimString(CAWString &aTrim, IS aIs)
{
    LTrimString(aTrim, aIs);
    RTrimString(aTrim, aIs);
};


#endif // !CMSTRING_H
