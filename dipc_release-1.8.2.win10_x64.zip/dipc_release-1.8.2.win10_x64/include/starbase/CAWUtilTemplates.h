/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWUTILTEMPLATES_H
#define CAWUTILTEMPLATES_H
#include "CAWThread.h"
#include "CAWThreadManager.h"
#include "CAWReferenceControl.h"
#include "CAWTimerWrapperID.h"
#include "CAWTimeValue.h"

template <class Type> 
class CAW_OS_EXPORT CAWSingletonT : public CAWCleanUpBase
{
public:
    static Type* Instance() 
    {
        static CAWSingletonT<Type> *s_pInstance = NULL;
        if (!s_pInstance) {
            MutexType *pMutex = NULL;
            CAWThreadManager::Instance()->GetSingletonMutex(pMutex);
            if (pMutex) {
                CAWMutexGuardT<MutexType> theGuard(*pMutex);
                if (!s_pInstance) {
                    s_pInstance = new CAWSingletonT<Type>();
                }
            }
            CAW_ASSERTE(s_pInstance);
        }
        return &s_pInstance->m_Instance;
    }

protected:
    CAWSingletonT() { }
    virtual ~CAWSingletonT() { }
    Type m_Instance;

private:
    typedef CAWMutexThreadRecursive MutexType;

    // = Prevent assignment and initialization.
    void operator = (const CAWSingletonT&);
    CAWSingletonT(const CAWSingletonT&);
};

template <class DeleteType>
class CAW_OS_EXPORT CAWEventDeleteT : public IAWEvent
{
public:
    CAWEventDeleteT(DeleteType *aDelete)
    : m_pDeleteType(aDelete)
    , m_bHaveDeleted(FALSE)
    , m_bHaveLaunched(FALSE)
    {
        CAW_ASSERTE(m_pDeleteType);
        CAW_ASSERTE(static_cast<void*>(aDelete) != static_cast<void*>(this));
    }

    virtual ~CAWEventDeleteT() 
    {
        if (!m_bHaveDeleted) {
            m_bHaveDeleted = TRUE;
            delete m_pDeleteType;
        }
    }

    CAWResult Launch(CAWThread* aThread)
    {
        CAW_ASSERTE_RETURN(aThread, CAW_ERROR_INVALID_ARG);
        CAW_ASSERTE_RETURN(!m_bHaveLaunched, CAW_ERROR_ALREADY_INITIALIZED);
        m_bHaveLaunched = TRUE;

        CAWResult rv = CAW_ERROR_NULL_POINTER;
        IAWEventQueue *pEq = aThread->GetEventQueue();
        if (pEq) {
            rv = pEq->PostEvent(this);
        }
        
        if (CAW_FAILED(rv)) {
            CAW_ERROR_TRACE("CAWEventDeleteT::Launch, PostEvent() failed! rv=" << rv);
        }
        return rv;
    }

    virtual CAWResult OnEventFire()
    {
        CAW_ASSERTE(m_bHaveLaunched);

        CAW_ASSERTE(!m_bHaveDeleted);
        m_bHaveDeleted = TRUE;
        delete m_pDeleteType;
        return CAW_OK;
    }

private:
    DeleteType *m_pDeleteType;
    BOOL m_bHaveDeleted;
    BOOL m_bHaveLaunched;
};

template <class DeleteType>
class CAW_OS_EXPORT CAWTimerDeleteT : public IAWTimerHandler
{
public:
    CAWTimerDeleteT(DeleteType *aDelete)
        : m_pDeleteType(aDelete)
        , m_bHaveLaunched(FALSE)
    {
        CAW_ASSERTE(m_pDeleteType);
        CAW_ASSERTE(static_cast<void*>(aDelete) != static_cast<void*>(this));
    }

    virtual ~CAWTimerDeleteT() 
    {
    }

    CAWResult Launch()
    {
        CAW_ASSERTE_RETURN(!m_bHaveLaunched, CAW_ERROR_ALREADY_INITIALIZED);
        m_bHaveLaunched = TRUE;

        IAWTimerQueue *pTimerQueue = NULL;
        CAWThread* pThread = 
        CAWThreadManager::Instance()->GetThread(CAWThreadManager::TT_CURRENT);
        if (pThread)
            pTimerQueue = pThread->GetTimerQueue();

        CAWResult rv = CAW_ERROR_NULL_POINTER;
        if (pTimerQueue) {
            // can't use CAWTimeValue::s_tvZero due to it is not exported. strange!
            rv = pTimerQueue->ScheduleTimer(this, NULL, CAWTimeValue(), 1);
            if (rv == CAW_ERROR_FOUND)
            rv = CAW_OK;
        }

        if (CAW_FAILED(rv)) {
            CAW_ERROR_TRACE("CAWTimerDeleteT::Launch, ScheduleTimer() failde! rv=" << rv);
        }
        return rv;
    }

    virtual void OnTimeout(const CAWTimeValue &, LPVOID aArg)
    {
        CAW_ASSERTE(m_bHaveLaunched);
        CAW_UNUSED_ARG(aArg);

        delete m_pDeleteType;
    }

private:
    DeleteType *m_pDeleteType;
    BOOL m_bHaveLaunched;
};

template <class MutexType>
class CAW_OS_EXPORT CAWReferenceControlTimerDeleteT
    : public CAWReferenceControlT<MutexType>
{
public:
    CAWReferenceControlTimerDeleteT()
        : m_Delete(this)
    {
    }

    virtual ~CAWReferenceControlTimerDeleteT() { }

protected:
    virtual void OnReferenceDestory()
    {
#ifdef CAW_DEBUG
        CAWResult rv = 
#endif // CAW_DEBUG
        m_Delete.Launch();

        CAW_ASSERTE(CAW_SUCCEEDED(rv) || rv == CAW_ERROR_NOT_INITIALIZED);
    }

private:
    CAWTimerDeleteT<CAWReferenceControlTimerDeleteT> m_Delete;
    friend class CAWTimerDeleteT<CAWReferenceControlTimerDeleteT>;
};

typedef CAWReferenceControlTimerDeleteT<CAWMutexNullSingleThread> CAWReferenceControlSingleThreadTimerDelete;
typedef CAWReferenceControlTimerDeleteT<CAWMutexThread> CAWReferenceControlMutilThreadTimerDelete;

#endif // !CAWUTILTEMPLATES_H


