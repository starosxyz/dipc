#ifndef CAWTRACE_H
#define CAWTRACE_H
#include "CAWDefines.h"

CAW_OS_EXPORT void STrace(const char * format, ...);


#endif//


