/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef __ISTAR_CRYPTO_H__
#define __ISTAR_CRYPTO_H__

#include "CAWReferenceControl.h"

class CAW_OS_EXPORT CSCrypto: public IAWReferenceControl
{
public:
    enum SCryptoType
    {
        Key_Exchange_Mode_RSA       = 0x100,
        Key_Exchange_Mode_PKCS7,
        Data_Encrypt_Mode_AES       = 0x200
    };

    virtual CAWResult Init(const char* cafile, 
                    const char* cakeyfile,
                    const char* passwd) = 0;

    virtual CAWResult Init(const char* cacert,
                const char* clientcert,
                const char* clientPriveky,
                const char* passwd) = 0;

    virtual void Destroy() = 0;

    virtual CAWResult SetMode(SCryptoType nType) = 0;

    virtual CAWResult CreateReqPrivatePair(const char* username,
                                        const char* passwd,
                                        char*& req,
                                        char*& privKey) = 0;

    virtual CAWResult CreateCert(const char* req,
                                DWORD dwSerial,
                                char*& cert) = 0;

    virtual BOOL VefityPrivateKey(const char* strPriKey,
                                const char* strPasswd) = 0;

    virtual CAWResult CreateSessionKey(int iKeyLen,
                                        LPBYTE& lpKey) = 0;

    virtual CAWResult EncryptSessionKey(const LPBYTE lpKey,
                                int iKeyLen,
                                const char* strRecvCert,
                                LPBYTE& lpEKey,
                                int& iEKeyLength) = 0;

    virtual CAWResult DecryptSessionKey(const LPBYTE lpEKey,
                                int iEKeyLength,
                                LPBYTE& lpKey,
                                int& iKeyLength) = 0;

    virtual CAWResult CryptoData(const LPBYTE lpInData,
                                int iInDataLength,
                                const LPBYTE lpKey,
                                int iKeyLenght,
                                BOOL bEncrypt,
                                LPBYTE& lpOutData,
                                int& iOutDataLength,
                                BOOL bStream) = 0;

    static CAWResult SaveToFile(const LPBYTE lpData,
                                int iDataLength,
                                const char* strFileName);

    static CAWResult ReadFromFile(const char* strFileName,
                                LPBYTE& lpData,
                                int& iDataLength);


    static CAWResult MD5(const LPBYTE lpInData, 
                                DWORD dwInLen,
                                LPBYTE& lpOutData);

    static CAWResult Base64(const LPBYTE lpInData,
                                DWORD dwInLen,
                                BOOL bEncode,
                                LPBYTE& lpOutData,
                                DWORD& dwOutLen);
    static CAWResult CryptoDataEx(const LPBYTE lpInData,
                                int iInDataLength,
                                const LPBYTE lpKey,
                                int iKeyLenght,
                                BOOL bEncrypt,
                                LPBYTE& lpOutData,
                                int& iOutDataLength,
                                BOOL bStream,
                                SCryptoType = Data_Encrypt_Mode_AES);

    static void Free(void* p);
};

extern "C"
{
    CAW_OS_EXPORT CSCrypto* CreateSCrypto();
}


#endif

