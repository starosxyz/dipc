/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef IAWPSEUDOTCPMANAGER_H
#define IAWPSEUDOTCPMANAGER_H

#include "CAWACEWrapper.h"


class IAWPseudoTCPAcceptorConnectorSink;
class IAWPseudoTCPTransportSink;
class IAWReferenceControl;
  class IAWPseudoTCPTransport;
  class IAWPseudoTCPAcceptorConnectorId;
    class IAWPseudoTCPConnector;
    class IAWPseudoTCPAcceptor;




class CAW_OS_EXPORT IAWPseudoTCPManager
{
public:
    static IAWPseudoTCPManager &Instance();
    virtual ~IAWPseudoTCPManager(){}
    /** \brief 创建PTCP客户端
    * @param aClient  输出客户端对象
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult CreatePseudoTCPConnector(CAWAutoPtr<IAWPseudoTCPConnector> &aClient) = 0;   
    /** \brief 创建PTCP服务器端
    * @param aClient  输出服务器对象
    * @return  CAWResult--   CAW_OK is success
    */
    virtual CAWResult CreatePseudoTCPAcceptor(CAWAutoPtr<IAWPseudoTCPAcceptor> &aAcceptor) = 0;
};

class CAW_OS_EXPORT CAWPseudoTCPTransportParameter
{
public:
    CAWPseudoTCPTransportParameter()
        : m_dwHaveSent(0)
    {
    }

    DWORD m_dwHaveSent;
};


class CAW_OS_EXPORT IAWPseudoTCPAcceptorConnectorSink
{
public:
    /** \brief 当连接成功或者服务器端又连接到来，回调执行函数
    * @param aReason    连接建立是否成功
    * @param aTrpt      连接建立传输对象
    * @param aTrpt      其他对象
    * @return  void--   无返回值
    */
    virtual void OnPseudoTCPConnectIndication(        CAWResult aReason,
            IAWPseudoTCPTransport *aTrpt,
            IAWPseudoTCPAcceptorConnectorId *aRequestId) = 0;

protected:
    virtual ~IAWPseudoTCPAcceptorConnectorSink() { }
};

class CAW_OS_EXPORT IAWPseudoTCPTransportSink 
{
public:
    /** \brief 当连接成功或者服务器端又连接到来，回调执行函数
    * @param aReason    连接建立是否成功
    * @param aTrpt      连接建立传输对象
    * @param aTrpt      其他对象
    * @return  void--   无返回值
    */
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWPseudoTCPTransport *aTrptId,
        CAWPseudoTCPTransportParameter *aPara = NULL) = 0;

    virtual void OnSend(
        IAWPseudoTCPTransport *aTrptId,
        CAWPseudoTCPTransportParameter *aPara = NULL) = 0;

    virtual void OnDisconnect(
    CAWResult aReason,
    IAWPseudoTCPTransport *aTrptId) = 0;

protected:
    virtual ~IAWPseudoTCPTransportSink() {}
};

class CAW_OS_EXPORT IAWPseudoTCPTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWPseudoTCPTransportSink *aSink) = 0;

    virtual IAWPseudoTCPTransportSink* GetSink() = 0;
    virtual CAWResult SendData(CAWMessageBlock &aData, CAWPseudoTCPTransportParameter *aPara = NULL) = 0;
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;

    virtual CAWResult Disconnect(CAWResult aReason) = 0;


protected:
    virtual ~IAWPseudoTCPTransport() {}
};


class CAW_OS_EXPORT IAWPseudoTCPAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWPseudoTCPAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWPseudoTCPConnector : public IAWPseudoTCPAcceptorConnectorId
{
public:
    virtual void AsycConnect(       
        IAWPseudoTCPAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrPeer,
        CAWTimeValue *aTimeout = NULL,
        CAWInetAddr *aAddrLocal = NULL) = 0;

    virtual void CancelConnect() = 0;

protected:
    virtual ~IAWPseudoTCPConnector() {}

};


class CAW_OS_EXPORT IAWPseudoTCPAcceptor : public IAWPseudoTCPAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IAWPseudoTCPAcceptorConnectorSink *aSink,
        const CAWInetAddr &aAddrListen) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;

protected:
    virtual ~IAWPseudoTCPAcceptor() {}
};

class CAW_OS_EXPORT IAWPseudoTCPConnectorInternal
{
public:
    virtual int Connect(const CAWInetAddr &aAddr, CAWInetAddr *aAddrLocal = NULL) = 0;
    virtual int Close() = 0;
    virtual ~IAWPseudoTCPConnectorInternal() { }
};


#endif // IAWPSEUDOTCPMANAGER_H

